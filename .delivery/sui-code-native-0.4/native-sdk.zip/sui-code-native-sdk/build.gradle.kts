plugins {
    kotlin("jvm") version "2.2.20"
    application
}
repositories { mavenCentral() }
kotlin { jvmToolchain(21) }
sourceSets.main { kotlin.srcDir("core/native-packages/src/main/java") }
dependencies { implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.8.0") }
application { mainClass.set("dev.suicode.packages.PackageTool") }
