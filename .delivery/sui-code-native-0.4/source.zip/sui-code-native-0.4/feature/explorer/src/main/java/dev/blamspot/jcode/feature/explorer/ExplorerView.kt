package dev.blamspot.jcode.feature.explorer
import dev.blamspot.jcode.design.FileTypeIcon
import dev.blamspot.jcode.design.JCodeIcon
import dev.blamspot.jcode.design.Space
import dev.blamspot.jcode.design.jcIcon

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import dev.blamspot.jcode.design.AlertDialog
import dev.blamspot.jcode.design.CompactDestructiveButton
import dev.blamspot.jcode.design.CompactFilledButton
import dev.blamspot.jcode.design.CompactOutlinedButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.blamspot.jcode.design.CompactContextMenu
import dev.blamspot.jcode.design.ContextAction
import dev.blamspot.jcode.design.JCodeTheme
import dev.blamspot.jcode.design.JcTooltip
import dev.blamspot.jcode.design.LocalTrashSettings
import dev.blamspot.jcode.design.trashRetentionLabel
import dev.blamspot.jcode.design.DenseRow
import dev.blamspot.jcode.design.IconSize
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.currentStateAsState
import dev.blamspot.jcode.fs.Fs
import dev.blamspot.jcode.fs.FsKind
import dev.blamspot.jcode.fs.FsNode
import dev.blamspot.jcode.fs.FsPath
import dev.blamspot.jcode.fs.Project
import dev.blamspot.jcode.fs.Workspace
import dev.blamspot.jcode.fs.copyFileOrDir
import dev.blamspot.jcode.fs.copyLocalTreeToDocumentTree
import dev.blamspot.jcode.fs.createFile
import dev.blamspot.jcode.fs.createDirectory
import dev.blamspot.jcode.fs.deletePermanently
import dev.blamspot.jcode.fs.exportFileToUri
import dev.blamspot.jcode.fs.importContentUris
import dev.blamspot.jcode.fs.renameFile
import dev.blamspot.jcode.fs.TrashSource
import dev.blamspot.jcode.fs.WorkspaceServiceLocator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Main explorer composable with tree/list toggle, breadcrumb, and file operations.
 *
 * @param workspace current workspace
 * @param project the project to explore
 * @param fs filesystem implementation for the project
 * @param context android context for SAF operations
 * @param onFileSelected callback when a file is tapped
 * @param onSnackbar callback for showing user messages
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ExplorerView(
    workspace: Workspace?,
    project: Project,
    fs: Fs,
    context: Context,
    modifier: Modifier = Modifier,
    viewMode: ExplorerViewMode = ExplorerViewMode.Tree,
    hiddenPatterns: List<String> = emptyList(),
    greyOutExcluded: Boolean = true,
    /** Auto-refresh the tree from filesystem events while the Explorer is actually on-screen. Gated
     *  by the caller (drawer open / sidebar visible) so watchers stop the moment it's hidden. */
    autoRefreshEnabled: Boolean = true,
    onFileSelected: ((FsNode) -> Unit)? = null,
    onSnackbar: ((String) -> Unit)? = null,
) {
    // Key only on project + fs (not the workspace object, which gets a new identity on every
    // roster mutation). Otherwise the view model is rebuilt but LaunchedEffect(project) — keyed on
    // the data-equal project — doesn't re-fire, leaving the tree stuck on "No files yet".
    val viewModel = remember(project, fs) {
        TreeViewModel(workspace, fs, initialViewMode = viewMode)
    }
    val scope = rememberCoroutineScope()

    val treeRows by viewModel.treeRows.collectAsStateWithLifecycle()
    val listRows by viewModel.listRows.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val breadcrumb by viewModel.breadcrumb.collectAsStateWithLifecycle()
    val currentPath by viewModel.currentPath.collectAsStateWithLifecycle()
    // The configured [viewMode] is pushed into the view model below; [activeViewMode] reflects the
    // shape the view model has actually materialized, so the UI never renders an empty mismatched flow.
    val activeViewMode by viewModel.viewMode.collectAsStateWithLifecycle()
    val selectionState = viewModel.selectionState
    val selectedIds by selectionState.selected.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf<CreateTarget?>(null) }
    var showRenameDialog by remember { mutableStateOf<RenameTarget?>(null) }
    var showDeleteConfirm by remember { mutableStateOf<TreeRow?>(null) }

    // Clipboard for copy/cut operations
    var clipboard by remember { mutableStateOf<ClipboardEntry?>(null) }

    // The bin. Its button stays on the toolbar while there is anything in it even after the setting
    // is turned off — opting out should stop deletes going there, not strand what already has.
    val trashSettings = LocalTrashSettings.current
    val trash = remember(context) { WorkspaceServiceLocator.trash(context) }
    var trashHasItems by remember { mutableStateOf(false) }
    var trashRevision by remember { mutableStateOf(0) }
    // Re-checked whenever the Explorer comes back on screen as well as after a delete: the bin is
    // emptied on its own page, so this cannot be the only thing that knows what is in it.
    LaunchedEffect(trashRevision, autoRefreshEnabled) { trashHasItems = !trash.isEmpty() }

    // Load project root on first composition
    LaunchedEffect(project) {
        viewModel.loadProjectRoot(project)
    }

    // The view mode is an app preference (Settings); react when it changes.
    LaunchedEffect(viewMode) {
        viewModel.setViewMode(viewMode)
    }

    // The project-root exclude-list + grey-out-vs-hide effect (Settings); re-apply when either changes
    // without remounting the tree.
    LaunchedEffect(hiddenPatterns, greyOutExcluded) {
        viewModel.setHiddenPatterns(hiddenPatterns, greyOutExcluded)
    }

    // VCS decorations pushed by the shell; re-badge rows when the extension reports new status (also
    // keyed on the view model so a recreated one is fed the current maps, not just future changes).
    val scmUi = LocalExplorerScmUi.current
    LaunchedEffect(viewModel, scmUi.status, scmUi.submodules) {
        viewModel.setScmDecorations(scmUi.status, scmUi.submodules)
    }

    // Live-update: while the Explorer is on-screen, watch the directories whose contents are actually
    // shown — the project root plus every expanded folder (Tree) or the current folder (List) — and
    // repaint on filesystem changes. Only visible dirs are watched (never the whole recursive tree),
    // so a large repo costs a handful of inotify watches, not thousands. The watch key is the *set* of
    // shown dirs, so a change inside an already-watched dir doesn't re-subscribe — only expand/collapse
    // re-targets. The whole watch tears down the instant [autoRefreshEnabled] goes false.
    val watchDirs = remember(treeRows, listRows, activeViewMode, currentPath) {
        when (activeViewMode) {
            ExplorerViewMode.Tree -> treeRows.asSequence()
                .filter { it.isExpanded && it.node.kind == FsKind.Directory }
                .map { it.node.path }
                .distinctBy { it.stableId }
                .toList()
            ExplorerViewMode.List -> listOfNotNull(currentPath)
        }
    }
    // NUL separator so it can't collide with anything inside a path; written as an escape because a
    // raw NUL byte in the source makes grep treat this whole file as binary and skip it.
    val watchKey = remember(watchDirs) { watchDirs.map { it.stableId }.sorted().joinToString("\u0000") }
    // Reopening the drawer does one catch-up refresh for changes missed while it was hidden.
    LaunchedEffect(autoRefreshEnabled) {
        if (autoRefreshEnabled) viewModel.refresh()
    }
    LaunchedEffect(autoRefreshEnabled, watchKey) {
        if (!autoRefreshEnabled || watchDirs.isEmpty()) return@LaunchedEffect
        merge(*watchDirs.map { dir -> fs.watch(dir).catch { } }.toTypedArray())
            .collectLatest {
                // Debounce: a fresh event cancels this wait, folding a burst into a single refresh.
                delay(300)
                viewModel.refresh()
                scmUi.onFsActivity?.invoke()
            }
    }

    // A watch alone is not enough to bound how stale the tree can get. inotify drops events when its
    // queue overflows — exactly what a build or a git checkout in the guest produces — it is only
    // registered on the directories currently shown, and not every backing filesystem raises it (a
    // SAF folder has no inotify at all; [SafFs.watch] is itself a poll). Device-checked: a guest
    // write through proot into an app-private project DOES reach this process's inotify, so the poll
    // is the backstop rather than the only path — but it is what makes "what is on screen is what is
    // on disk" true within a bounded time instead of hopefully.
    //
    // Poll on the same terms Source Control takes: only while the Explorer is the open tool (this
    // composable is composed for no other) and the app is actually in front of the user.
    // A pass lists the root plus every expanded directory, and [TreeRow]/[FsNode] compare by value,
    // so a tick that finds nothing new publishes an equal list — the StateFlow drops it and nothing
    // recomposes. It does not raise onFsActivity: Source Control runs its own poll when it is open,
    // and a `git status` per tick for a panel nobody is looking at is what that gate exists to stop.
    val pollLifecycle = LocalLifecycleOwner.current
    val lifecycleState by pollLifecycle.lifecycle.currentStateAsState()
    val pollActive = autoRefreshEnabled && lifecycleState.isAtLeast(Lifecycle.State.RESUMED)
    LaunchedEffect(pollActive, viewModel) {
        if (!pollActive) return@LaunchedEffect
        while (true) {
            // Delay first: opening the panel already refreshes through the effect above.
            delay(EXPLORER_VISIBLE_REFRESH_MS)
            viewModel.refresh()
        }
    }

    // SAF import/export: import streams device-storage picks into a target dir (row menu or toolbar);
    // export saves a file via a create-document picker or copies a local folder into a picked tree.
    // Pending targets are saveable tokens (a process death behind the system picker would drop plain
    // remember state and silently ignore the pick), and the copies run in their own supervisor scope:
    // leaving the Explorer must not cancel a tree copy midway.
    val fileOpScope = remember { CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate) }
    var importTarget by rememberSaveable { mutableStateOf<String?>(null) }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments(),
    ) { uris ->
        val target = importTarget?.let(::fsPathFromToken)
        importTarget = null
        if (target != null && uris.isNotEmpty()) fileOpScope.launch {
            val result = runCatching { importContentUris(fs, context, uris, target) }
            // Refresh either way: a partial failure may have landed some files already.
            viewModel.refresh()
            scmUi.onFsActivity?.invoke()
            result.onSuccess { names -> onSnackbar?.invoke("Imported ${names.size} file(s)") }
                .onFailure { onSnackbar?.invoke("Import failed: ${it.message}") }
        }
    }
    var exportFileSource by rememberSaveable { mutableStateOf<String?>(null) }
    val exportFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { uri ->
        val source = exportFileSource?.let(::fsPathFromToken)
        exportFileSource = null
        if (source != null && uri != null) fileOpScope.launch {
            runCatching { exportFileToUri(context, source, uri) }
                .onSuccess { onSnackbar?.invoke("Exported file") }
                .onFailure { onSnackbar?.invoke("Export failed: ${it.message}") }
        }
    }
    var exportDirSource by rememberSaveable { mutableStateOf<String?>(null) }
    val exportDirLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree(),
    ) { uri ->
        val source = exportDirSource?.let(::File)
        exportDirSource = null
        if (source != null && uri != null) fileOpScope.launch {
            runCatching { copyLocalTreeToDocumentTree(context, source, uri, source.name) }
                .onSuccess { n -> onSnackbar?.invoke("Exported $n file(s) from '${source.name}'") }
                .onFailure { onSnackbar?.invoke("Export failed: ${it.message}") }
        }
    }

    // Where toolbar create/paste should land: the viewed dir in List mode; the selected dir (or the
    // selected file's parent) in Tree mode, falling back to the project root.
    fun resolveCreateParent(): FsPath {
        if (activeViewMode == ExplorerViewMode.List) return currentPath ?: project.fsPath
        val selected = treeRows.firstOrNull { it.id in selectedIds && !it.isPlaceholder }
            ?: return project.fsPath
        return when (selected.node.kind) {
            FsKind.Directory -> selected.node.path
            else -> parentPathOf(selected.node.path) ?: project.fsPath
        }
    }

    val protectedProjects = LocalProtectedProjectRoots.current
    fun isProtectedPath(path: FsPath): Boolean = path.stableId == project.fsPath.stableId ||
        (path as? FsPath.Local)?.let { dev.blamspot.jcode.fs.InternalFiles.protectsProject(it.file, protectedProjects) } == true
    fun runRowAction(row: TreeRow, action: RowAction) {
        if (isProtectedPath(row.node.path) && action in setOf(RowAction.Rename, RowAction.Cut, RowAction.Delete)) {
            onSnackbar?.invoke("The root folder is permanent. Manage project names through Project management.")
            return
        }
        when (action) {
            RowAction.Open -> onFileSelected?.invoke(row.node)
            RowAction.NewFile -> showCreateDialog = CreateTarget(row.node.path, isDirectory = false)
            RowAction.NewFolder -> showCreateDialog = CreateTarget(row.node.path, isDirectory = true)
            RowAction.Rename -> showRenameDialog = RenameTarget(row.node.path, row.node.name)
            RowAction.Copy -> {
                clipboard = ClipboardEntry(row.node.path, row.node.name, isCut = false)
                onSnackbar?.invoke("Copied '${row.node.name}'")
            }
            RowAction.Cut -> {
                clipboard = ClipboardEntry(row.node.path, row.node.name, isCut = true)
                onSnackbar?.invoke("Cut '${row.node.name}'")
            }
            RowAction.Delete -> showDeleteConfirm = row
            RowAction.ImportHere -> {
                importTarget = fsPathToken(row.node.path)
                importLauncher.launch(arrayOf("*/*"))
            }
            RowAction.Export -> {
                val path = row.node.path
                when {
                    row.node.kind != FsKind.Directory -> {
                        exportFileSource = fsPathToken(path)
                        exportFileLauncher.launch(row.node.name)
                    }
                    path is FsPath.Local -> {
                        exportDirSource = path.file.absolutePath
                        exportDirLauncher.launch(null)
                    }
                    else -> onSnackbar?.invoke("Folder export supports local folders only")
                }
            }
        }
    }

    CompositionLocalProvider(LocalProjectRootId provides project.fsPath.stableId) {
    Column(modifier = modifier.fillMaxSize()) {
        // Compact action toolbar (always visible) with create/refresh/paste. The Tree|List view mode
        // is set in Settings, not here.
        ExplorerToolbar(
            viewMode = activeViewMode,
            onCreateFile = { showCreateDialog = CreateTarget(resolveCreateParent(), isDirectory = false) },
            onCreateFolder = { showCreateDialog = CreateTarget(resolveCreateParent(), isDirectory = true) },
            onImport = {
                importTarget = fsPathToken(resolveCreateParent())
                importLauncher.launch(arrayOf("*/*"))
            },
            onCollapseAll = { scope.launch { viewModel.collapseAll() } },
            onRefresh = {
                scope.launch { viewModel.refresh() }
                scmUi.onFsActivity?.invoke()
            },
            onPaste = {
                clipboard?.let { entry ->
                    scope.launch {
                        runCatching {
                            if (entry.isCut) check(!isProtectedPath(entry.sourcePath)) { "Manage registered project folders through Project management" }
                            val targetParent = resolveCreateParent()
                            copyFileOrDir(fs, context, entry.sourcePath, targetParent)
                            viewModel.refresh()
                            onSnackbar?.invoke("Pasted '${entry.name}'")
                            if (entry.isCut) {
                                deletePermanently(fs, context, entry.sourcePath)
                                viewModel.refresh()
                            }
                            clipboard = null
                            scmUi.onFsActivity?.invoke()
                        }.onFailure { onSnackbar?.invoke("Paste failed: ${it.message}") }
                    }
                }
            },
            canPaste = clipboard != null,
            showTrash = trashSettings.enabled || trashHasItems,
            onOpenTrash = trashSettings.onOpen,
        )

        // Content. Tree shows the hierarchy from the root (no breadcrumb); List is a flat
        // file-manager for one directory, navigated via the breadcrumb + up button. The scrollable
        // body must take the *remaining* height (weight) so its LazyColumn is bounded and scrolls;
        // a bare fillMaxSize would overflow under the toolbar and hide the last rows.
        when (activeViewMode) {
            ExplorerViewMode.Tree -> Box(modifier = Modifier.weight(1f)) {
                TreeViewContent(
                    rows = treeRows,
                    isLoading = isLoading,
                    selectedIds = selectedIds,
                    selectionState = selectionState,
                    onToggleExpand = { row -> scope.launch { viewModel.toggleExpand(row) } },
                    onRowClick = { row ->
                        if (row.node.kind == FsKind.Directory) {
                            scope.launch { viewModel.toggleExpand(row) }
                        } else {
                            onFileSelected?.invoke(row.node)
                        }
                    },
                    onAction = { row, action -> runRowAction(row, action) },
                )
            }

            ExplorerViewMode.List -> {
                ExplorerBreadcrumb(
                    entries = breadcrumb,
                    onNavigate = { entry -> scope.launch { viewModel.navigateTo(entry.path, entry.label) } },
                    onNavigateUp = { scope.launch { viewModel.navigateUp() } },
                )
                Box(modifier = Modifier.weight(1f)) {
                    ListViewContent(
                        rows = listRows,
                        isLoading = isLoading,
                        selectedIds = selectedIds,
                        selectionState = selectionState,
                        onRowClick = { row ->
                            if (row.node.kind == FsKind.Directory) {
                                scope.launch { viewModel.navigateTo(row.node.path, row.node.name) }
                            } else {
                                onFileSelected?.invoke(row.node)
                            }
                        },
                        onAction = { row, action -> runRowAction(row, action) },
                    )
                }
            }
        }
    }
    }

    // Create dialog
    showCreateDialog?.let { target ->
        CreateRenameDialog(
            title = if (target.isDirectory) "New Folder" else "New File",
            initialName = if (target.isDirectory) "new-folder" else "new-file.txt",
            onDismiss = { showCreateDialog = null },
            onConfirm = { name ->
                scope.launch {
                    runCatching {
                        if (target.isDirectory) {
                            createDirectory(fs, context, target.parentPath, name)
                        } else {
                            createFile(fs, context, target.parentPath, name)
                        }
                        viewModel.refresh()
                        scmUi.onFsActivity?.invoke()
                        onSnackbar?.invoke("Created '$name'")
                    }.onFailure {
                        onSnackbar?.invoke("Create failed: ${it.message}")
                    }
                }
                showCreateDialog = null
            },
        )
    }

    // Rename dialog
    showRenameDialog?.let { target ->
        CreateRenameDialog(
            title = "Rename",
            initialName = target.currentName,
            onDismiss = { showRenameDialog = null },
            onConfirm = { newName ->
                scope.launch {
                    runCatching {
                        check(!isProtectedPath(target.path)) { "Manage registered project folders through Project management" }
                        renameFile(fs, context, target.path, newName)
                        viewModel.refresh()
                        scmUi.onFsActivity?.invoke()
                        onSnackbar?.invoke("Renamed to '$newName'")
                    }.onFailure {
                        onSnackbar?.invoke("Rename failed: ${it.message}")
                    }
                }
                showRenameDialog = null
            },
        )
    }

    // Delete confirmation. With the Trash on this is a move and says so; with it off the delete is
    // final, and the wording has to be the one the button will actually honour.
    showDeleteConfirm?.let { target ->
        val isDir = target.node.kind == FsKind.Directory
        val subject = if (isDir) "The folder, with everything in it," else "The file"
        val what = if (isDir) "folder and everything in it" else "file"
        val toTrash = trashSettings.enabled
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = null },
            title = { Text("Delete '${target.node.name}'?") },
            text = {
                Text(
                    if (toTrash) {
                        "$subject moves to the Trash, where it is kept for " +
                            trashRetentionLabel(trashSettings.retentionDays).lowercase() +
                            " and can be restored."
                    } else {
                        "This permanently deletes the $what. " +
                            "If the project is under git, you can restore it there."
                    },
                )
            },
            // Emphasis follows the consequence: a move to the Trash is recoverable and gets the
            // ordinary filled button, while a real delete is drawn destructive.
            confirmButton = {
                val confirmAction: () -> Unit = {
                    val node = target.node
                    showDeleteConfirm = null
                    scope.launch {
                        runCatching {
                            check(!isProtectedPath(node.path)) { "Manage registered project folders through Project management" }
                            if (toTrash) {
                                trash.put(
                                    context = context,
                                    path = node.path,
                                    projectName = project.name,
                                    projectRoot = (project.fsPath as? FsPath.Local)?.file?.absolutePath,
                                    source = TrashSource.Explorer,
                                )
                                trashRevision++
                            } else {
                                deletePermanently(fs, context, node.path)
                            }
                            viewModel.refresh()
                            scmUi.onFsActivity?.invoke()
                            onSnackbar?.invoke(
                                if (toTrash) "Moved '${node.name}' to Trash" else "Deleted '${node.name}'",
                            )
                        }.onFailure { onSnackbar?.invoke("Delete failed: ${it.message}") }
                    }
                }
                if (toTrash) {
                    CompactFilledButton(text = "Move to Trash", onClick = confirmAction)
                } else {
                    CompactDestructiveButton(text = "Delete", onClick = confirmAction)
                }
            },
            dismissButton = {
                CompactOutlinedButton(text = "Cancel", onClick = { showDeleteConfirm = null })
            },
        )
    }
}

data class CreateTarget(val parentPath: FsPath, val isDirectory: Boolean)
data class RenameTarget(val path: FsPath, val currentName: String)

/** Represents a file/directory in the clipboard for copy/cut operations. */
data class ClipboardEntry(
    val sourcePath: FsPath,
    val name: String,
    val isCut: Boolean, // true if cut, false if copy
)

/** Per-row actions surfaced via the visible overflow (⋮) menu. */
enum class RowAction { Open, NewFile, NewFolder, Rename, Copy, Cut, Delete, ImportHere, Export }

/** Parent of a path, or null when there is no addressable parent (SAF tree URIs). */
private fun parentPathOf(path: FsPath): FsPath? = when (path) {
    is FsPath.Local -> path.file.parentFile?.let { FsPath.Local(it) }
    is FsPath.Saf -> null
}

// FsPath as a saveable string, for pending SAF-picker targets that must survive process death.
private fun fsPathToken(path: FsPath): String = when (path) {
    is FsPath.Local -> "local:" + path.file.absolutePath
    is FsPath.Saf -> "saf:" + path.uri
}

private fun fsPathFromToken(token: String): FsPath? = when {
    token.startsWith("local:") -> FsPath.Local(File(token.removePrefix("local:")))
    token.startsWith("saf:") -> FsPath.Saf(Uri.parse(token.removePrefix("saf:")))
    else -> null
}

// --- Row overflow menu (visible ⋮ on every row) ---

@Composable
private fun RowOverflowMenu(
    row: TreeRow,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    onAction: (TreeRow, RowAction) -> Unit,
) {
    val isDir = row.node.kind == FsKind.Directory
    val scmUi = LocalExplorerScmUi.current
    // The project root must not be moved or deleted from the tree, so Cut/Delete are hidden on it.
    val protectedProjects = LocalProtectedProjectRoots.current
    val isProjectRoot = LocalProjectRootId.current == row.node.path.stableId || (row.node.path as? FsPath.Local)?.let { dev.blamspot.jcode.fs.InternalFiles.protectsProject(it.file, protectedProjects) } == true
    Box {
        JcTooltip("More actions") {
            IconButton(
                onClick = { onExpandedChange(true) },
                modifier = Modifier.size(28.dp),
            ) {
                Icon(
                    painter = jcIcon(JCodeIcon.MoreVert),
                    contentDescription = "More actions",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(IconSize.md),
                )
            }
        }
        CompactContextMenu(
            expanded = expanded,
            onDismissRequest = { onExpandedChange(false) },
            quickActions = buildList {
                add(ContextAction(JCodeIcon.Copy, "Copy") { onAction(row, RowAction.Copy) })
                if (!isProjectRoot) add(ContextAction(JCodeIcon.Cut, "Cut") { onAction(row, RowAction.Cut) })
                if (!isProjectRoot) add(ContextAction(JCodeIcon.Rename, "Rename") { onAction(row, RowAction.Rename) })
                if (!isProjectRoot) {
                    add(ContextAction(JCodeIcon.Delete, "Delete", destructive = true) { onAction(row, RowAction.Delete) })
                }
            },
            listActions = buildList {
                if (!isDir) add(ContextAction(JCodeIcon.Open, "Open") { onAction(row, RowAction.Open) })
                if (isDir) {
                    add(ContextAction(JCodeIcon.NewFile, "New file") { onAction(row, RowAction.NewFile) })
                    add(ContextAction(JCodeIcon.NewFolder, "New folder") { onAction(row, RowAction.NewFolder) })
                    add(ContextAction(JCodeIcon.Add, "Import files…") { onAction(row, RowAction.ImportHere) })
                }
                add(ContextAction(JCodeIcon.Save, "Export…") { onAction(row, RowAction.Export) })
                // Extension-contributed actions (e.g. "Add to .gitignore") target a path inside the
                // repo — the project root isn't a valid target, so omit them there.
                if (!isProjectRoot) {
                    scmUi.onContextAction?.let { dispatch ->
                        scmUi.contextActions
                            .filter { explorerActionAppliesTo(it, row.node.name, isDir) }
                            .forEach { a -> add(ContextAction(a.icon, a.label) { dispatch(a, row.node) }) }
                    }
                }
            },
        )
    }
}

// --- Breadcrumb ---

@Composable
private fun ExplorerBreadcrumb(
    entries: List<TreeViewModel.BreadcrumbEntry>,
    onNavigate: (TreeViewModel.BreadcrumbEntry) -> Unit,
    onNavigateUp: () -> Unit,
) {
    val scrollState = rememberScrollState()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(scrollState)
            .padding(horizontal = Space.sm, vertical = Space.xs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (entries.size > 1) {
            JcTooltip("Up one level") {
                IconButton(onClick = onNavigateUp, modifier = Modifier.size(28.dp)) {
                    Icon(
                        painter = jcIcon(JCodeIcon.ArrowUp),
                        contentDescription = "Up one level",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(IconSize.md),
                    )
                }
            }
            Spacer(modifier = Modifier.width(4.dp))
        }
        entries.forEachIndexed { index, entry ->
            if (index > 0) {
                Text(
                    text = "›",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = Space.xxs),
                )
            }
            Text(
                text = entry.label,
                style = MaterialTheme.typography.labelSmall,
                color = if (index == entries.lastIndex) {
                    MaterialTheme.colorScheme.onSurface
                } else {
                    MaterialTheme.colorScheme.primary
                },
                modifier = Modifier
                    .clickable { onNavigate(entry) }
                    .padding(vertical = Space.xxs),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// --- Tree View ---

@Composable
private fun TreeViewContent(
    rows: List<TreeRow>,
    isLoading: Boolean,
    selectedIds: Set<String>,
    selectionState: ExplorerSelectionState,
    onToggleExpand: (TreeRow) -> Unit,
    onRowClick: (TreeRow) -> Unit,
    onAction: (TreeRow, RowAction) -> Unit,
) {
    if (isLoading && rows.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(modifier = Modifier.padding(Space.lg))
        }
        return
    }
    if (rows.isEmpty()) {
        EmptyExplorerHint()
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(rows, key = { it.id }) { row ->
            TreeRowItem(
                row = row,
                isSelected = row.id in selectedIds,
                onToggleExpand = onToggleExpand,
                onClick = {
                    selectionState.selectSingle(row.id)
                    onRowClick(row)
                },
                onAction = onAction,
            )
        }
    }
}

@Composable
private fun EmptyExplorerHint() {
    Box(modifier = Modifier.fillMaxSize().padding(Space.xxl), contentAlignment = Alignment.Center) {
        Text(
            text = "No files yet.\nUse the New File / New Folder buttons above.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** Width reserved for the disclosure chevron so files (no chevron) align under folders. */
private val ChevronSlot = 28.dp

/** Opacity of a project-root entry that is excluded under the "grey out" effect. */
private const val EXCLUDED_ROW_ALPHA = 0.4f

/** How often the tree re-reads its shown directories while the panel is open and focused. Faster
 *  than Source Control's tick because a pass is a handful of local directory listings rather than a
 *  `git status` in the guest, and slow enough that a large expanded tree isn't re-listed constantly. */
private const val EXPLORER_VISIBLE_REFRESH_MS = 2_000L

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TreeRowItem(
    row: TreeRow,
    isSelected: Boolean,
    onToggleExpand: (TreeRow) -> Unit,
    onClick: () -> Unit,
    onAction: (TreeRow, RowAction) -> Unit,
) {
    val iconSize = IconSize.md
    val indent = (row.depth * 16).dp

    if (row.isPlaceholder) {
        DenseRow(
            leading = { Spacer(modifier = Modifier.width(indent + ChevronSlot + iconSize)) },
            content = {
                Text(
                    text = row.node.name,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                )
            },
        )
        return
    }

    var menuExpanded by remember { mutableStateOf(false) }
    val isDir = row.node.kind == FsKind.Directory

    DenseRow(
        modifier = Modifier
            .combinedClickable(
                onClick = onClick,
                onLongClick = { menuExpanded = true },
            )
            .then(
                if (isSelected) {
                    Modifier.background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
                } else {
                    Modifier
                }
            )
            // Excluded (grey-out effect): kept in the tree but dimmed so it reads as de-emphasized.
            .then(if (row.isExcluded) Modifier.alpha(EXCLUDED_ROW_ALPHA) else Modifier),
        leading = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Spacer(modifier = Modifier.width(indent))
                if (isDir) {
                    Box(
                        modifier = Modifier
                            .size(ChevronSlot)
                            .clickable { onToggleExpand(row) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter = if (row.isExpanded) jcIcon(JCodeIcon.ChevronDown) else jcIcon(JCodeIcon.ChevronRight),
                            contentDescription = if (row.isExpanded) "Collapse" else "Expand",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(iconSize),
                        )
                    }
                    FileTypeIcon(
                        name = row.node.name,
                        isDirectory = true,
                        isExpanded = row.isExpanded,
                        size = iconSize,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                } else {
                    Spacer(modifier = Modifier.width(ChevronSlot))
                    FileTypeIcon(
                        name = row.node.name,
                        isDirectory = false,
                        size = iconSize,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        content = {
            Text(
                text = row.node.name,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium,
                color = row.vcsStatus?.let { vcsStatusColor(it) } ?: Color.Unspecified,
            )
        },
        trailing = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RowVcsBadges(row)
                RowOverflowMenu(
                    row = row,
                    expanded = menuExpanded,
                    onExpandedChange = { menuExpanded = it },
                    onAction = onAction,
                )
            }
        },
    )
}

// --- List View ---

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ListViewContent(
    rows: List<TreeRow>,
    isLoading: Boolean,
    selectedIds: Set<String>,
    selectionState: ExplorerSelectionState,
    onRowClick: (TreeRow) -> Unit,
    onAction: (TreeRow, RowAction) -> Unit,
) {
    if (isLoading && rows.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(modifier = Modifier.padding(Space.lg))
        }
        return
    }
    if (rows.isEmpty()) {
        EmptyExplorerHint()
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(rows, key = { it.id }) { row ->
            var menuExpanded by remember { mutableStateOf(false) }
            val iconSize = IconSize.md
            DenseRow(
                modifier = Modifier
                    .combinedClickable(
                        onClick = {
                            selectionState.selectSingle(row.id)
                            onRowClick(row)
                        },
                        onLongClick = { menuExpanded = true },
                    )
                    .then(
                        if (row.id in selectedIds) {
                            Modifier.background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
                        } else {
                            Modifier
                        }
                    )
                    .then(if (row.isExcluded) Modifier.alpha(EXCLUDED_ROW_ALPHA) else Modifier),
                leading = {
                    val isDirectory = row.node.kind == FsKind.Directory
                    FileTypeIcon(
                        name = row.node.name,
                        isDirectory = isDirectory,
                        size = iconSize,
                        tint = if (isDirectory) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                    )
                },
                content = {
                    Column {
                        Text(
                            text = row.node.name,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodyMedium,
                            color = row.vcsStatus?.let { vcsStatusColor(it) } ?: Color.Unspecified,
                        )
                        if (row.node.kind == FsKind.File) {
                            Text(
                                text = "${formatSize(row.node.sizeBytes)} · ${formatModified(row.node.modifiedAtMillis)}",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            )
                        }
                    }
                },
                trailing = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RowVcsBadges(row)
                        RowOverflowMenu(
                            row = row,
                            expanded = menuExpanded,
                            onExpandedChange = { menuExpanded = it },
                            onAction = onAction,
                        )
                    }
                },
            )
        }
    }
}

private fun formatSize(bytes: Long): String {
    return when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        bytes < 1024 * 1024 * 1024 -> "${bytes / (1024 * 1024)} MB"
        else -> "${bytes / (1024 * 1024 * 1024)} GB"
    }
}

private val listDateFormat = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())

private fun formatModified(millis: Long): String =
    if (millis <= 0L) "—" else listDateFormat.format(Date(millis))

// --- Toolbar ---

@Composable
private fun ExplorerToolbar(
    viewMode: ExplorerViewMode,
    onCreateFile: () -> Unit,
    onCreateFolder: () -> Unit,
    onImport: () -> Unit,
    onCollapseAll: () -> Unit,
    onRefresh: () -> Unit,
    onPaste: () -> Unit,
    canPaste: Boolean,
    showTrash: Boolean,
    onOpenTrash: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = Space.xs, vertical = Space.xxs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ToolbarIcon(jcIcon(JCodeIcon.NewFile), "New File", onCreateFile)
        ToolbarIcon(jcIcon(JCodeIcon.NewFolder), "New Folder", onCreateFolder)
        ToolbarIcon(jcIcon(JCodeIcon.Add), "Import files", onImport)
        ToolbarIcon(jcIcon(JCodeIcon.Paste), "Paste", onPaste, enabled = canPaste)
        ToolbarIcon(jcIcon(JCodeIcon.Refresh), "Refresh", onRefresh)
        if (viewMode == ExplorerViewMode.Tree) {
            ToolbarIcon(jcIcon(JCodeIcon.Collapse), "Collapse all", onCollapseAll)
        }
        // Away from the make-and-refresh cluster, at the end of the row: the bin is where deletes
        // are undone, not another thing to do to the tree.
        if (showTrash) {
            Spacer(modifier = Modifier.weight(1f))
            ToolbarIcon(jcIcon(JCodeIcon.Trash), "Trash", onOpenTrash)
        }
    }
}

@Composable
private fun ToolbarIcon(
    icon: Painter,
    description: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
) {
    JcTooltip(description) {
        IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(34.dp)) {
            Icon(
                painter = icon,
                contentDescription = description,
                modifier = Modifier.size(IconSize.md),
                tint = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            )
        }
    }
}

// --- Create/Rename Dialog ---

@Composable
private fun CreateRenameDialog(
    title: String,
    initialName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var textState by remember { mutableStateOf(TextFieldValue(initialName, TextRange(initialName.length))) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = textState,
                onValueChange = { textState = it },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    if (textState.text.isNotBlank()) {
                        onConfirm(textState.text)
                    }
                }),
                singleLine = true,
            )
        },
        confirmButton = {
            CompactFilledButton(
                text = "OK",
                onClick = {
                    if (textState.text.isNotBlank()) {
                        onConfirm(textState.text)
                    }
                },
                enabled = textState.text.isNotBlank(),
            )
        },
        dismissButton = {
            CompactOutlinedButton(text = "Cancel", onClick = onDismiss)
        },
    )
}

// --- VCS badges ---

/** Trailing VCS chips for a row: an "S" submodule marker and/or the status letter. */
@Composable
private fun RowVcsBadges(row: TreeRow) {
    if (row.isSubmodule) {
        JcTooltip("Git submodule") {
            Text(
                text = "S",
                color = MaterialTheme.colorScheme.tertiary,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(horizontal = Space.xxs),
            )
        }
    }
    row.vcsStatus?.let { status ->
        Text(
            text = status,
            color = vcsStatusColor(status),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = Space.xxs),
        )
    }
}

/** Shared status-letter → color mapping (badge and filename tint): modified amber, added/untracked
 *  green, deleted/conflicted red, renamed primary. */
@Composable
private fun vcsStatusColor(status: String): Color = when (status.firstOrNull()) {
    'M', DIR_CONTAINS_CHANGES.first() -> JCodeTheme.semanticColors.warning
    'A', '?' -> JCodeTheme.semanticColors.success
    'D', 'U' -> MaterialTheme.colorScheme.error
    'R', 'C' -> MaterialTheme.colorScheme.primary
    else -> MaterialTheme.colorScheme.onSurfaceVariant
}
