#include "vt_parser.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define VT_SCROLLBACK_CAP 2000

// Blank-cell prototype: whole-struct assignment vectorizes to one wide store per cell, where the
// old field-by-field clears (4 narrow stores skipping the color bytes) could not. Side effect:
// cleared cells zero their color payload bytes too — unobservable, the renderer keys off mode.
static const VtCell VT_BLANK = { .ch = ' ' };

static void clear_cells(VtCell* p, int count) {
    for (int i = 0; i < count; i++) p[i] = VT_BLANK;
}

// ---- Character cell width (wcwidth) ----------------------------------------------------------
// A wide (2-cell) character occupies its lead cell plus a continuation cell with ch == 0 carrying
// the same colors/attrs; renderers and text extractors skip ch == 0. Zero-width characters
// (combining marks, ZWJ, variation selectors) are dropped rather than folded — column geometry
// stays correct and the base character keeps its default presentation.

typedef struct { uint32_t first, last; } VtCpRange;

// East Asian Wide/Fullwidth plus the emoji blocks mainstream terminals render two cells wide
// (Unicode EastAsianWidth W/F, the same set musl's wcwidth uses). Sorted for binary search.
static const VtCpRange VT_WIDE_RANGES[] = {
    {0x1100, 0x115F},   {0x231A, 0x231B},   {0x2329, 0x232A},   {0x23E9, 0x23EC},
    {0x23F0, 0x23F0},   {0x23F3, 0x23F3},   {0x25FD, 0x25FE},   {0x2614, 0x2615},
    {0x2648, 0x2653},   {0x267F, 0x267F},   {0x2693, 0x2693},   {0x26A1, 0x26A1},
    {0x26AA, 0x26AB},   {0x26BD, 0x26BE},   {0x26C4, 0x26C5},   {0x26CE, 0x26CE},
    {0x26D4, 0x26D4},   {0x26EA, 0x26EA},   {0x26F2, 0x26F3},   {0x26F5, 0x26F5},
    {0x26FA, 0x26FA},   {0x26FD, 0x26FD},   {0x2705, 0x2705},   {0x270A, 0x270B},
    {0x2728, 0x2728},   {0x274C, 0x274C},   {0x274E, 0x274E},   {0x2753, 0x2755},
    {0x2757, 0x2757},   {0x2795, 0x2797},   {0x27B0, 0x27B0},   {0x27BF, 0x27BF},
    {0x2B1B, 0x2B1C},   {0x2B50, 0x2B50},   {0x2B55, 0x2B55},   {0x2E80, 0x2FFB},
    {0x3000, 0x303E},   {0x3041, 0x33FF},   {0x3400, 0x4DBF},   {0x4E00, 0x9FFF},
    {0xA000, 0xA4CF},   {0xA960, 0xA97F},   {0xAC00, 0xD7A3},   {0xF900, 0xFAFF},
    {0xFE10, 0xFE19},   {0xFE30, 0xFE52},   {0xFE54, 0xFE66},   {0xFE68, 0xFE6B},
    {0xFF00, 0xFF60},   {0xFFE0, 0xFFE6},   {0x16FE0, 0x16FE4}, {0x17000, 0x187F7},
    {0x18800, 0x18CD5}, {0x1B000, 0x1B2FB}, {0x1F004, 0x1F004}, {0x1F0CF, 0x1F0CF},
    {0x1F18E, 0x1F18E}, {0x1F191, 0x1F19A}, {0x1F200, 0x1F202}, {0x1F210, 0x1F23B},
    {0x1F240, 0x1F248}, {0x1F250, 0x1F251}, {0x1F260, 0x1F265}, {0x1F300, 0x1F320},
    {0x1F32D, 0x1F335}, {0x1F337, 0x1F37C}, {0x1F37E, 0x1F393}, {0x1F3A0, 0x1F3CA},
    {0x1F3CF, 0x1F3D3}, {0x1F3E0, 0x1F3F0}, {0x1F3F4, 0x1F3F4}, {0x1F3F8, 0x1F43E},
    {0x1F440, 0x1F440}, {0x1F442, 0x1F4FC}, {0x1F4FF, 0x1F53D}, {0x1F54B, 0x1F54E},
    {0x1F550, 0x1F567}, {0x1F57A, 0x1F57A}, {0x1F595, 0x1F596}, {0x1F5A4, 0x1F5A4},
    {0x1F5FB, 0x1F64F}, {0x1F680, 0x1F6C5}, {0x1F6CC, 0x1F6CC}, {0x1F6D0, 0x1F6D2},
    {0x1F6D5, 0x1F6D7}, {0x1F6DC, 0x1F6DF}, {0x1F6EB, 0x1F6EC}, {0x1F6F4, 0x1F6FC},
    {0x1F7E0, 0x1F7EB}, {0x1F7F0, 0x1F7F0}, {0x1F90C, 0x1F9FF}, {0x1FA70, 0x1FAFF},
    {0x20000, 0x2FFFD}, {0x30000, 0x3FFFD},
};

// Zero-width: format controls, joiners, variation selectors, and the common combining blocks.
// (The long tail of script-specific combining marks is omitted — those degrade to width 1,
// exactly the pre-wcwidth behavior, rather than mis-shifting columns.)
static const VtCpRange VT_ZERO_RANGES[] = {
    {0x0300, 0x036F},   {0x0483, 0x0489},   {0x0591, 0x05BD},   {0x05BF, 0x05BF},
    {0x05C1, 0x05C2},   {0x05C4, 0x05C5},   {0x05C7, 0x05C7},   {0x0610, 0x061A},
    {0x064B, 0x065F},   {0x0670, 0x0670},   {0x06D6, 0x06DC},   {0x06DF, 0x06E4},
    {0x06E7, 0x06E8},   {0x06EA, 0x06ED},   {0x1AB0, 0x1AFF},   {0x1DC0, 0x1DFF},
    {0x200B, 0x200F},   {0x202A, 0x202E},   {0x2060, 0x2064},   {0x20D0, 0x20FF},
    {0x302A, 0x302D},   {0x3099, 0x309A},   {0xFE00, 0xFE0F},   {0xFE20, 0xFE2F},
    {0xFEFF, 0xFEFF},   {0xE0100, 0xE01EF},
};

static bool cp_in_ranges(uint32_t cp, const VtCpRange* ranges, int count) {
    int lo = 0, hi = count - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        if (cp < ranges[mid].first) hi = mid - 1;
        else if (cp > ranges[mid].last) lo = mid + 1;
        else return true;
    }
    return false;
}

static int vt_wcwidth(uint32_t cp) {
    if (cp < 0x0300) return 1;  // ASCII + Latin-1/Extended: the overwhelmingly common case
    if (cp_in_ranges(cp, VT_ZERO_RANGES, (int)(sizeof(VT_ZERO_RANGES) / sizeof(VT_ZERO_RANGES[0])))) return 0;
    if (cp_in_ranges(cp, VT_WIDE_RANGES, (int)(sizeof(VT_WIDE_RANGES) / sizeof(VT_WIDE_RANGES[0])))) return 2;
    return 1;
}

// Helper to allocate screen
static VtScreen* screen_create(int rows, int cols) {
    VtScreen* screen = (VtScreen*)calloc(1, sizeof(VtScreen));
    if (!screen) return NULL;

    screen->rows = rows;
    screen->cols = cols;
    screen->cells = (VtCell*)calloc(rows * cols, sizeof(VtCell));
    if (!screen->cells) {
        free(screen);
        return NULL;
    }
    // One byte per row. A failure here is survivable — every row then reads as unwrapped — so it
    // does not fail the whole allocation.
    screen->row_flags = (uint8_t*)calloc((size_t)rows, 1);

    clear_cells(screen->cells, rows * cols);

    screen->cursor_row = 0;
    screen->cursor_col = 0;
    screen->cursor_visible = true;
    screen->scroll_top = 0;
    screen->scroll_bottom = rows - 1;
    
    return screen;
}

static void screen_destroy(VtScreen* screen) {
    if (screen) {
        free(screen->cells);
        free(screen->row_flags);
        free(screen);
    }
}

static void screen_clear(VtScreen* screen) {
    if (!screen) return;
    clear_cells(screen->cells, screen->rows * screen->cols);
    if (screen->row_flags) memset(screen->row_flags, 0, (size_t)screen->rows);
}

static inline VtCell* screen_cell_at(VtScreen* screen, int row, int col) {
    if (row < 0 || row >= screen->rows || col < 0 || col >= screen->cols) {
        return NULL;
    }
    return &screen->cells[row * screen->cols + col];
}

// --- per-row wrap flags -----------------------------------------------------
// All four tolerate a NULL row_flags (allocation failed) and an out-of-range row, so callers never
// have to guard. Reading an absent flag as "not wrapped" is what makes the degradation safe: resize
// then treats every row as its own logical line, which is exactly the pre-reflow behaviour.

static inline uint8_t row_flags_get(const VtScreen* s, int row) {
    if (!s || !s->row_flags || row < 0 || row >= s->rows) return 0;
    return s->row_flags[row];
}

static inline void row_flags_set(VtScreen* s, int row, uint8_t bits) {
    if (!s || !s->row_flags || row < 0 || row >= s->rows) return;
    s->row_flags[row] |= bits;
}

static inline void row_flags_clear(VtScreen* s, int row, uint8_t bits) {
    if (!s || !s->row_flags || row < 0 || row >= s->rows) return;
    s->row_flags[row] &= (uint8_t)~bits;
}

// Push a screen line into the scrollback ring buffer (oldest evicted when full). [flags] are the
// pushed row's VT_ROW_* bits, so a wrapped line stays joinable across the screen/scrollback seam.
static void scrollback_push(VtParser* parser, const VtCell* line, int line_cols, uint8_t flags) {
    if (!parser->scrollback || parser->scrollback_cap <= 0) return;
    int slot;
    if (parser->scrollback_count == parser->scrollback_cap) {
        slot = parser->scrollback_head;
        parser->scrollback_head = (parser->scrollback_head + 1) % parser->scrollback_cap;
    } else {
        slot = (parser->scrollback_head + parser->scrollback_count) % parser->scrollback_cap;
        parser->scrollback_count++;
    }
    VtCell* dst = &parser->scrollback[slot * parser->scrollback_cols];
    int n = line_cols < parser->scrollback_cols ? line_cols : parser->scrollback_cols;
    memcpy(dst, line, (size_t)n * sizeof(VtCell));
    clear_cells(dst + n, parser->scrollback_cols - n);
    if (parser->scrollback_flags) parser->scrollback_flags[slot] = flags;
    parser->scrollback_pushed++;
}

// Repair wide pairs a write to cells [start, end) of `row` is about to split: overwriting a
// continuation orphans its lead (blank it), overwriting a lead orphans its continuation.
static void blank_split_pairs(VtScreen* screen, int row, int start, int end) {
    VtCell* line = &screen->cells[row * screen->cols];
    if (start > 0 && start < screen->cols && line[start].ch == 0) line[start - 1] = VT_BLANK;
    if (end > 0 && end < screen->cols && line[end].ch == 0) line[end] = VT_BLANK;
}

// Re-validate wide pairs across a row after a horizontal shift (ICH/DCH): a continuation whose
// lead shifted away, or a lead whose continuation did, is blanked (xterm behavior). Iterating
// skips valid pairs, so any continuation actually visited is an orphan.
static void repair_row_pairs(VtScreen* screen, int row) {
    VtCell* line = &screen->cells[row * screen->cols];
    for (int col = 0; col < screen->cols; col++) {
        if (line[col].ch == 0) {
            line[col] = VT_BLANK;
        } else if (vt_wcwidth(line[col].ch) == 2) {
            if (col + 1 < screen->cols && line[col + 1].ch == 0) col++;
            else line[col] = VT_BLANK;
        }
    }
}

static void clear_row_range(VtScreen* screen, int row, int col_from, int col_to) {
    if (row < 0 || row >= screen->rows) return;
    if (col_from < 0) col_from = 0;
    if (col_to >= screen->cols) col_to = screen->cols - 1;
    if (col_from > col_to) return;
    blank_split_pairs(screen, row, col_from, col_to + 1);
    clear_cells(&screen->cells[row * screen->cols + col_from], col_to - col_from + 1);
    // C4, applying to every caller (ED 0/1, EL 0/1/2, ECH). Erasing from column 0 means this row no
    // longer holds wrapped-in content; erasing the LAST cell voids the relationship with the row
    // below, since autowrap can only have produced one by writing through that cell.
    if (col_from == 0) row_flags_clear(screen, row, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
    if (col_to >= screen->cols - 1) row_flags_clear(screen, row + 1, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
}

// Shift rows [top, bottom] up by n inside the screen (no scrollback capture — see screen_scroll_up).
// The rows are contiguous in one cells array, so the shift is a single overlapping memmove — the
// previous one-memmove-per-row loop issued (rows-1) small copies for every scrolled line.
//
// [keep_top_wrap] decides what happens to the wrap flag of the row that ends up at [top]. It used to
// continue row top-1, which is now gone: false clears the flag (the predecessor was deleted, e.g.
// DL), true keeps it (the predecessor was ARCHIVED into scrollback, so the join is still real and
// spans the screen/scrollback seam). Callers must say which; it cannot be inferred from top == 0.
static void region_shift_up(VtScreen* screen, int top, int bottom, int n, bool keep_top_wrap) {
    int move = bottom - top + 1 - n;
    if (move > 0) {
        memmove(&screen->cells[top * screen->cols],
                &screen->cells[(top + n) * screen->cols],
                (size_t)move * screen->cols * sizeof(VtCell));
    }
    clear_cells(&screen->cells[(bottom - n + 1) * screen->cols], n * screen->cols);
    if (screen->row_flags) {
        if (move > 0) memmove(&screen->row_flags[top], &screen->row_flags[top + n], (size_t)move);
        memset(&screen->row_flags[bottom - n + 1], 0, (size_t)n);
        if (!keep_top_wrap) row_flags_clear(screen, top, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
    }
}

// Shift rows [top, bottom] down by n inside the screen.
static void region_shift_down(VtScreen* screen, int top, int bottom, int n) {
    int move = bottom - top + 1 - n;
    if (move > 0) {
        memmove(&screen->cells[(top + n) * screen->cols],
                &screen->cells[top * screen->cols],
                (size_t)move * screen->cols * sizeof(VtCell));
    }
    clear_cells(&screen->cells[top * screen->cols], n * screen->cols);
    if (screen->row_flags) {
        if (move > 0) memmove(&screen->row_flags[top + n], &screen->row_flags[top], (size_t)move);
        memset(&screen->row_flags[top], 0, (size_t)n);
        // The row now at top+n used to follow top-1 and now follows a blank.
        row_flags_clear(screen, top + n, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
    }
}

// Scroll region up by n lines. Lines evicted from the top of the primary full-height region are
// captured into scrollback first so the user can scroll back through history.
static void screen_scroll_up(VtParser* parser, int n) {
    VtScreen* screen = parser->active;
    if (n <= 0) return;
    if (n > screen->scroll_bottom - screen->scroll_top + 1) {
        n = screen->scroll_bottom - screen->scroll_top + 1;
    }

    // Exactly the condition that archives the evicted rows, so it is also the condition under which
    // the row arriving at the top still continues something real.
    bool archived = (screen == &parser->primary && screen->scroll_top == 0);
    if (archived) {
        for (int k = 0; k < n; k++) {
            int row = screen->scroll_top + k;
            scrollback_push(parser, &screen->cells[row * screen->cols], screen->cols, row_flags_get(screen, row));
        }
    }

    region_shift_up(screen, screen->scroll_top, screen->scroll_bottom, n, archived);
}

// Scroll region down by n lines
static void screen_scroll_down(VtParser* parser, int n) {
    VtScreen* screen = parser->active;
    if (n <= 0) return;
    if (n > screen->scroll_bottom - screen->scroll_top + 1) {
        n = screen->scroll_bottom - screen->scroll_top + 1;
    }
    region_shift_down(screen, screen->scroll_top, screen->scroll_bottom, n);
}

// Write character at cursor position
static void screen_write_char(VtParser* parser, uint32_t ch) {
    // ch == 0 is the structural wide-continuation marker — never write it as content (the decoder
    // maps forged NULs to U+FFFD; this guard keeps the invariant even for future callers).
    if (ch == 0) return;
    int width = vt_wcwidth(ch);
    // Zero-width (combining marks, ZWJ, variation selectors): dropped — no cell, no cursor move.
    if (width == 0) return;
    VtScreen* screen = parser->active;
    if (width == 2 && screen->cols < 2) width = 1;
    // Set by the two autowrap sites below, and by nothing else in the parser. It is what tells the
    // clear rule at the bottom apart from a cursor that reached column 0 by CR/LF or a cursor move.
    bool wrapped_here = false;

    // Handle line wrap (deferred: the cursor parks past the last column until the next printable).
    // With autowrap off (DECRST ?7) the last column is overwritten in place instead.
    if (screen->cursor_col >= screen->cols) {
        if (!parser->decawm) {
            screen->cursor_col = screen->cols - 1;
        } else {
            screen->cursor_col = 0;
            screen->cursor_row++;

            if (screen->cursor_row > screen->scroll_bottom) {
                screen_scroll_up(parser, 1);
                screen->cursor_row = screen->scroll_bottom;
            }
            // AFTER the scroll: screen_scroll_up shifts the flag array, so the bit has to be written
            // at the post-shift index or it would land on the wrong row.
            row_flags_set(screen, screen->cursor_row, VT_ROW_WRAPPED);
            wrapped_here = true;
        }
    }
    // A wide char that doesn't fit in the last column: xterm blanks the column and wraps the
    // whole character (with autowrap off it is written against the right edge instead).
    if (width == 2 && screen->cursor_col == screen->cols - 1) {
        if (!parser->decawm) {
            screen->cursor_col = screen->cols - 2;
        } else {
            blank_split_pairs(screen, screen->cursor_row, screen->cursor_col, screen->cursor_col + 1);
            screen->cells[screen->cursor_row * screen->cols + screen->cursor_col] = VT_BLANK;
            screen->cursor_col = 0;
            screen->cursor_row++;
            if (screen->cursor_row > screen->scroll_bottom) {
                screen_scroll_up(parser, 1);
                screen->cursor_row = screen->scroll_bottom;
            }
            // WRAP_PAD too: the blank just written to the previous row's last cell is padding, not
            // content, so a rejoin must drop it instead of inserting a space before this character.
            row_flags_set(screen, screen->cursor_row, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
            wrapped_here = true;
        }
    }

    if (screen->cursor_row < 0 || screen->cursor_row >= screen->rows) return;
    // C1: a write landing at column 0 that did NOT come from a wrap starts a new logical line. The
    // clear belongs on the write rather than on CR, because a wrapped line almost always ends with
    // CR+LF and that CR lands on the block's own final continuation row — clearing there would
    // destroy the last join of every wrapped line in the terminal.
    if (screen->cursor_col == 0 && !wrapped_here) {
        row_flags_clear(screen, screen->cursor_row, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
    }
    blank_split_pairs(screen, screen->cursor_row, screen->cursor_col, screen->cursor_col + width);
    VtCell* cell = screen_cell_at(screen, screen->cursor_row, screen->cursor_col);
    if (cell) {
        cell->ch = ch;
        cell->fg = parser->fg;
        cell->bg = parser->bg;
        cell->attrs = parser->attrs;

        if (width == 2) {
            // Continuation cell: ch == 0 with the lead's colors, skipped by renderer/extractors.
            VtCell* cont = cell + 1;
            cont->ch = 0;
            cont->fg = parser->fg;
            cont->bg = parser->bg;
            cont->attrs = parser->attrs;
        }

    }

    screen->cursor_col += width;
}

// Newline
static void screen_newline(VtParser* parser) {
    VtScreen* screen = parser->active;
    screen->cursor_row++;

    if (screen->cursor_row > screen->scroll_bottom) {
        screen_scroll_up(parser, 1);
        screen->cursor_row = screen->scroll_bottom;
    }
    // C7: LF ends the logical line above, so the row arrived at starts a new one. Safe against the
    // wrap sites because those inline their own cursor_row++ and never route through here.
    row_flags_clear(screen, screen->cursor_row, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
}

// Carriage return
static void screen_carriage_return(VtParser* parser) {
    parser->active->cursor_col = 0;
}

// Parse SGR (Select Graphic Rendition) parameters
static void handle_sgr(VtParser* parser) {
    if (parser->param_count == 0) {
        // Reset all attributes
        parser->attrs = 0;
        parser->fg.mode = 0;
        parser->bg.mode = 0;
        return;
    }
    
    for (int i = 0; i < parser->param_count; i++) {
        int p = parser->params[i];
        
        if (p == 0) {
            // Reset
            parser->attrs = 0;
            parser->fg.mode = 0;
            parser->bg.mode = 0;
        } else if (p == 1) {
            parser->attrs |= VT_ATTR_BOLD;
        } else if (p == 2) {
            parser->attrs |= VT_ATTR_DIM;
        } else if (p == 3) {
            parser->attrs |= VT_ATTR_ITALIC;
        } else if (p == 4) {
            parser->attrs |= VT_ATTR_UNDERLINE;
        } else if (p == 5) {
            parser->attrs |= VT_ATTR_BLINK;
        } else if (p == 7) {
            parser->attrs |= VT_ATTR_INVERSE;
        } else if (p == 8) {
            parser->attrs |= VT_ATTR_HIDDEN;
        } else if (p == 9) {
            parser->attrs |= VT_ATTR_STRIKETHROUGH;
        } else if (p == 21) {
            // Doubly underlined; rendered as a plain underline.
            parser->attrs |= VT_ATTR_UNDERLINE;
        } else if (p == 22) {
            // Attribute-off codes: without these, chalk-style output (\e[1m…\e[22m) never turns
            // bold/dim off and the styling bleeds across the rest of the screen.
            parser->attrs &= ~(VT_ATTR_BOLD | VT_ATTR_DIM);
        } else if (p == 23) {
            parser->attrs &= ~VT_ATTR_ITALIC;
        } else if (p == 24) {
            parser->attrs &= ~VT_ATTR_UNDERLINE;
        } else if (p == 25) {
            parser->attrs &= ~VT_ATTR_BLINK;
        } else if (p == 27) {
            parser->attrs &= ~VT_ATTR_INVERSE;
        } else if (p == 28) {
            parser->attrs &= ~VT_ATTR_HIDDEN;
        } else if (p == 29) {
            parser->attrs &= ~VT_ATTR_STRIKETHROUGH;
        } else if (p >= 30 && p <= 37) {
            // Standard foreground colors
            parser->fg.mode = 1;
            parser->fg.index = p - 30;
        } else if (p == 38) {
            // Extended foreground color
            if (i + 1 < parser->param_count) {
                int mode = parser->params[++i];
                if (mode == 5 && i + 1 < parser->param_count) {
                    // 256-color mode
                    parser->fg.mode = 1;
                    parser->fg.index = parser->params[++i];
                } else if (mode == 2 && i + 3 < parser->param_count) {
                    // Truecolor mode
                    parser->fg.mode = 2;
                    parser->fg.r = parser->params[++i];
                    parser->fg.g = parser->params[++i];
                    parser->fg.b = parser->params[++i];
                }
            }
        } else if (p == 39) {
            // Default foreground
            parser->fg.mode = 0;
        } else if (p >= 40 && p <= 47) {
            // Standard background colors
            parser->bg.mode = 1;
            parser->bg.index = p - 40;
        } else if (p == 48) {
            // Extended background color
            if (i + 1 < parser->param_count) {
                int mode = parser->params[++i];
                if (mode == 5 && i + 1 < parser->param_count) {
                    // 256-color mode
                    parser->bg.mode = 1;
                    parser->bg.index = parser->params[++i];
                } else if (mode == 2 && i + 3 < parser->param_count) {
                    // Truecolor mode
                    parser->bg.mode = 2;
                    parser->bg.r = parser->params[++i];
                    parser->bg.g = parser->params[++i];
                    parser->bg.b = parser->params[++i];
                }
            }
        } else if (p == 49) {
            // Default background
            parser->bg.mode = 0;
        } else if (p >= 90 && p <= 97) {
            // Bright foreground colors
            parser->fg.mode = 1;
            parser->fg.index = p - 90 + 8;
        } else if (p >= 100 && p <= 107) {
            // Bright background colors
            parser->bg.mode = 1;
            parser->bg.index = p - 100 + 8;
        }
    }
}

// Queue answerback bytes for the host to drain to the PTY (dropped when the buffer is full).
static void response_append(VtParser* parser, const char* s) {
    int len = (int)strlen(s);
    if (len > VT_RESPONSE_CAP - parser->response_len) return;
    memcpy(parser->responses + parser->response_len, s, (size_t)len);
    parser->response_len += len;
}

// DECSC/DECRC bodies, shared by ESC 7/8, CSI s/u, and the 1049 alt-screen switch.
static void cursor_save(VtParser* parser, VtScreen* s) {
    s->saved_row = s->cursor_row;
    s->saved_col = s->cursor_col;
    s->saved_attrs = parser->attrs;
    s->saved_fg = parser->fg;
    s->saved_bg = parser->bg;
}

static void cursor_restore(VtParser* parser, VtScreen* s) {
    s->cursor_row = s->saved_row;
    s->cursor_col = s->saved_col;
    parser->attrs = s->saved_attrs;
    parser->fg = s->saved_fg;
    parser->bg = s->saved_bg;
}

static bool has_intermediate(const VtParser* parser, char ch) {
    for (int i = 0; i < parser->intermediate_count; i++) {
        if (parser->intermediates[i] == ch) return true;
    }
    return false;
}

// DECRQM status for `CSI ? Pd $ p`: 1 = set, 2 = reset, 0 = not recognized. Programs probe modes
// this way before relying on them (Claude Code probes ?2026 synchronized output at startup).
static int dec_mode_status(const VtParser* parser, int mode) {
    switch (mode) {
        case 1: return parser->decckm ? 1 : 2;
        case 7: return parser->decawm ? 1 : 2;
        case 25: return parser->active->cursor_visible ? 1 : 2;
        case 47:
        case 1047:
        case 1049: return parser->active == &parser->alternate ? 1 : 2;
        case 9: return parser->mouse_mode == VT_MOUSE_X10 ? 1 : 2;
        case 1000: return parser->mouse_mode == VT_MOUSE_NORMAL ? 1 : 2;
        case 1002: return parser->mouse_mode == VT_MOUSE_BUTTON ? 1 : 2;
        case 1003: return parser->mouse_mode == VT_MOUSE_ANY ? 1 : 2;
        case 1004: return parser->focus_events ? 1 : 2;
        case 1006: return parser->mouse_enc == VT_MOUSE_ENC_SGR ? 1 : 2;
        case 1015: return parser->mouse_enc == VT_MOUSE_ENC_URXVT ? 1 : 2;
        case 1007: return parser->alt_scroll ? 1 : 2;
        case 2004: return parser->bracketed_paste ? 1 : 2;
        case 2026: return parser->sync_output ? 1 : 2;
        default: return 0;
    }
}

// Apply one DEC private mode set/reset (the `CSI ? … h/l` handler loops over every parameter —
// `ESC[?1049;1006h` must apply both, not just the first).
static void apply_dec_mode(VtParser* parser, int mode, bool set) {
    switch (mode) {
        case 1: parser->decckm = set; break;
        case 7: parser->decawm = set; break;
        case 25: parser->active->cursor_visible = set; break;
        case 47:
        case 1047:
        case 1049:
            if (set) {
                // Save only when actually TRANSITIONING onto the alt screen: a re-issued 1049h
                // while already there must not clobber the saved primary cursor/SGR state
                // (xterm keeps a per-buffer save slot).
                if (mode == 1049 && parser->active != &parser->alternate) {
                    cursor_save(parser, &parser->primary);
                }
                parser->active = &parser->alternate;
                // xterm: only 1049 clears the alternate screen on entry; 1047 clears it on
                // exit (below) and plain 47 never clears.
                if (mode == 1049) screen_clear(&parser->alternate);
            } else {
                if (mode == 1047 && parser->active == &parser->alternate) {
                    screen_clear(&parser->alternate);
                }
                parser->active = &parser->primary;
                if (mode == 1049) cursor_restore(parser, &parser->primary);
            }
            break;
        // xterm turns tracking OFF on DECRST of ANY tracking mode (apps commonly clean up with
        // just ?1000l even if they enabled ?1003) — a matching-only reset left tracking latched,
        // swallowing every tap at the shell prompt afterwards.
        case 9: parser->mouse_mode = set ? VT_MOUSE_X10 : VT_MOUSE_OFF; break;
        case 1000: parser->mouse_mode = set ? VT_MOUSE_NORMAL : VT_MOUSE_OFF; break;
        case 1002: parser->mouse_mode = set ? VT_MOUSE_BUTTON : VT_MOUSE_OFF; break;
        case 1003: parser->mouse_mode = set ? VT_MOUSE_ANY : VT_MOUSE_OFF; break;
        // 1005 (UTF-8 coords) is deliberately NOT recognized: acknowledging it while emitting
        // X10 bytes would feed invalid UTF-8 to apps that trusted the ack. Unknown modes fall
        // through to default (ignored), and DECRQM reports 0 = not recognized.
        case 1006: if (set) parser->mouse_enc = VT_MOUSE_ENC_SGR; else if (parser->mouse_enc == VT_MOUSE_ENC_SGR) parser->mouse_enc = VT_MOUSE_ENC_X10; break;
        case 1015: if (set) parser->mouse_enc = VT_MOUSE_ENC_URXVT; else if (parser->mouse_enc == VT_MOUSE_ENC_URXVT) parser->mouse_enc = VT_MOUSE_ENC_X10; break;
        case 1004: parser->focus_events = set; break;
        case 1007: parser->alt_scroll = set; break;
        case 2004: parser->bracketed_paste = set; break;
        case 2026: parser->sync_output = set; break;
        default: break;
    }
}

// Handle CSI sequence
static void handle_csi(VtParser* parser, char final_char) {
    VtScreen* screen = parser->active;

    // CSI sequences with a <, =, or > parameter prefix are private terminal queries/reports
    // (XTVERSION `>q`, XTMODKEYS `>...m`, …). Secondary DA (`CSI > c`) gets an answer — programs
    // gate mouse/feature support on the reported version — everything else is consumed and ignored
    // so the final byte isn't mis-applied (e.g. `CSI > 4;1 m` must NOT be treated as SGR). DEC
    // private modes use `?` and fall through to the switch below.
    if (parser->intermediate_count > 0 &&
        (parser->intermediates[0] == '<' || parser->intermediates[0] == '=' ||
         parser->intermediates[0] == '>')) {
        if (parser->intermediates[0] == '>' && final_char == 'c' &&
            (parser->param_count == 0 || parser->params[0] == 0)) {
            // Secondary DA: report as xterm 285 (SGR mouse capable), matching what we implement.
            response_append(parser, "\x1b[>41;285;0c");
        }
        return;
    }

    switch (final_char) {
        case 'A': { // Cursor Up
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            screen->cursor_row -= n;
            if (screen->cursor_row < screen->scroll_top) {
                screen->cursor_row = screen->scroll_top;
            }
            break;
        }
        case 'B': { // Cursor Down
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            screen->cursor_row += n;
            if (screen->cursor_row > screen->scroll_bottom) {
                screen->cursor_row = screen->scroll_bottom;
            }
            break;
        }
        case 'C': { // Cursor Forward
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            screen->cursor_col += n;
            if (screen->cursor_col >= screen->cols) {
                screen->cursor_col = screen->cols - 1;
            }
            break;
        }
        case 'D': { // Cursor Back
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            screen->cursor_col -= n;
            if (screen->cursor_col < 0) {
                screen->cursor_col = 0;
            }
            break;
        }
        case 'E': { // Cursor Next Line (down n rows, column 0)
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            screen->cursor_row += n;
            if (screen->cursor_row > screen->scroll_bottom) {
                screen->cursor_row = screen->scroll_bottom;
            }
            screen->cursor_col = 0;
            break;
        }
        case 'F': { // Cursor Previous Line (up n rows, column 0). Used by the .NET build / MSBuild
                    // terminal logger to return to the top of its live progress block before redrawing
                    // in place — without this each tick's duration lands on a new line.
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            screen->cursor_row -= n;
            if (screen->cursor_row < screen->scroll_top) {
                screen->cursor_row = screen->scroll_top;
            }
            screen->cursor_col = 0;
            break;
        }
        case 'G': { // Cursor Horizontal Absolute (column; 1-based). Used by progress bars/spinners
                    // (Node readline.cursorTo) to return to col 0 before redrawing in place.
            int col = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] - 1 : 0;
            screen->cursor_col = col;
            if (screen->cursor_col < 0) screen->cursor_col = 0;
            if (screen->cursor_col >= screen->cols) screen->cursor_col = screen->cols - 1;
            break;
        }
        case 'd': { // Line Position Absolute (row; 1-based)
            int row = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] - 1 : 0;
            screen->cursor_row = row;
            if (screen->cursor_row < 0) screen->cursor_row = 0;
            if (screen->cursor_row >= screen->rows) screen->cursor_row = screen->rows - 1;
            break;
        }
        case 'H': // Cursor Position
        case 'f': {
            int row = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] - 1 : 0;
            int col = parser->param_count > 1 && parser->params[1] > 0 ? parser->params[1] - 1 : 0;
            screen->cursor_row = row;
            screen->cursor_col = col;
            if (screen->cursor_row >= screen->rows) screen->cursor_row = screen->rows - 1;
            if (screen->cursor_col >= screen->cols) screen->cursor_col = screen->cols - 1;
            break;
        }
        case 'J': { // Erase in Display
            int mode = parser->param_count > 0 ? parser->params[0] : 0;
            if (mode == 0) {
                // Clear from cursor to end: the cursor row's tail, then the contiguous rows below.
                clear_row_range(screen, screen->cursor_row, screen->cursor_col, screen->cols - 1);
                if (screen->cursor_row + 1 < screen->rows) {
                    clear_cells(&screen->cells[(screen->cursor_row + 1) * screen->cols],
                                (screen->rows - screen->cursor_row - 1) * screen->cols);
                    // C5: this bulk clear bypasses clear_row_range, so the flags need clearing here.
                    if (screen->row_flags) {
                        memset(&screen->row_flags[screen->cursor_row + 1], 0,
                               (size_t)(screen->rows - screen->cursor_row - 1));
                    }
                }
            } else if (mode == 1) {
                // Clear from beginning to cursor: the contiguous rows above, then the row head.
                clear_cells(screen->cells, screen->cursor_row * screen->cols);
                if (screen->row_flags) memset(screen->row_flags, 0, (size_t)screen->cursor_row);
                clear_row_range(screen, screen->cursor_row, 0, screen->cursor_col);
            } else if (mode == 2) {
                // Clear entire screen
                screen_clear(screen);
            } else if (mode == 3) {
                // xterm: clear scrollback (used by `clear` and Claude Code's /clear).
                parser->scrollback_count = 0;
                parser->scrollback_head = 0;
                // History is gone, so row 0 no longer continues anything across the seam.
                row_flags_clear(screen, 0, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
            }
            break;
        }
        case 'K': { // Erase in Line
            int mode = parser->param_count > 0 ? parser->params[0] : 0;
            if (mode == 0) {
                clear_row_range(screen, screen->cursor_row, screen->cursor_col, screen->cols - 1);
            } else if (mode == 1) {
                clear_row_range(screen, screen->cursor_row, 0, screen->cursor_col);
            } else if (mode == 2) {
                clear_row_range(screen, screen->cursor_row, 0, screen->cols - 1);
            }
            break;
        }
        case 'S': { // Scroll Up
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            screen_scroll_up(parser, n);
            break;
        }
        case 'T': { // Scroll Down
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            screen_scroll_down(parser, n);
            break;
        }
        case '@': { // ICH — insert n blank cells at the cursor, shifting the rest of the row right
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            int row = screen->cursor_row;
            int col = screen->cursor_col;
            if (col >= screen->cols) col = screen->cols - 1;
            if (n > screen->cols - col) n = screen->cols - col;
            VtCell* line = &screen->cells[row * screen->cols];
            memmove(&line[col + n], &line[col], (size_t)(screen->cols - col - n) * sizeof(VtCell));
            clear_cells(&line[col], n);
            repair_row_pairs(screen, row);
            // C6: the row is rewritten from `col` and its last cell is disturbed, so any join
            // into or out of it is void. Conservative on purpose — these are rare inside
            // wrapped output, and a redraw re-establishes the bits.
            if (col == 0) row_flags_clear(screen, row, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
            row_flags_clear(screen, row + 1, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
            break;
        }
        case 'P': { // DCH — delete n cells at the cursor, shifting the rest of the row left
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            int row = screen->cursor_row;
            int col = screen->cursor_col;
            if (col >= screen->cols) col = screen->cols - 1;
            if (n > screen->cols - col) n = screen->cols - col;
            VtCell* line = &screen->cells[row * screen->cols];
            memmove(&line[col], &line[col + n], (size_t)(screen->cols - col - n) * sizeof(VtCell));
            clear_cells(&line[screen->cols - n], n);
            repair_row_pairs(screen, row);
            // C6: the row is rewritten from `col` and its last cell is disturbed, so any join
            // into or out of it is void. Conservative on purpose — these are rare inside
            // wrapped output, and a redraw re-establishes the bits.
            if (col == 0) row_flags_clear(screen, row, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
            row_flags_clear(screen, row + 1, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
            break;
        }
        case 'X': { // ECH — erase n cells from the cursor (no shift)
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            int col = screen->cursor_col;
            if (col >= screen->cols) col = screen->cols - 1;
            if (n > screen->cols - col) n = screen->cols - col;
            clear_row_range(screen, screen->cursor_row, col, col + n - 1);
            break;
        }
        case 'L': { // IL — insert n blank lines at the cursor row (within the scroll region)
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            if (screen->cursor_row >= screen->scroll_top && screen->cursor_row <= screen->scroll_bottom) {
                int span = screen->scroll_bottom - screen->cursor_row + 1;
                if (n > span) n = span;
                region_shift_down(screen, screen->cursor_row, screen->scroll_bottom, n);
                screen->cursor_col = 0;
            }
            break;
        }
        case 'M': { // DL — delete n lines at the cursor row (within the scroll region)
            int n = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] : 1;
            if (screen->cursor_row >= screen->scroll_top && screen->cursor_row <= screen->scroll_bottom) {
                int span = screen->scroll_bottom - screen->cursor_row + 1;
                if (n > span) n = span;
                // false even at row 0: DL DELETES the predecessor rather than archiving it, so
                // whatever lands at the cursor row no longer continues anything.
                region_shift_up(screen, screen->cursor_row, screen->scroll_bottom, n, false);
                screen->cursor_col = 0;
            }
            break;
        }
        case 'c': { // Primary DA — identify as a VT420-class xterm (the feature list Termux reports)
            if (parser->param_count == 0 || parser->params[0] == 0) {
                response_append(parser, "\x1b[?64;1;2;6;9;15;18;21;22c");
            }
            break;
        }
        case 'n': { // DSR — status report (5) and cursor position report (6 / DECXCPR ?6)
            int req = parser->param_count > 0 ? parser->params[0] : 0;
            if (req == 5) {
                response_append(parser, "\x1b[0n");
            } else if (req == 6) {
                int row = screen->cursor_row + 1;
                int col = screen->cursor_col + 1;
                if (col > screen->cols) col = screen->cols;  // deferred-wrap: cursor parks past the edge
                if (row > screen->rows) row = screen->rows;
                char reply[32];
                bool dec = has_intermediate(parser, '?');
                snprintf(reply, sizeof(reply), dec ? "\x1b[?%d;%dR" : "\x1b[%d;%dR", row, col);
                response_append(parser, reply);
            }
            break;
        }
        case 't': { // XTWINOPS — answer the text-area-size report; ignore resize/icon requests
            if (parser->param_count > 0 && parser->params[0] == 18) {
                char reply[32];
                snprintf(reply, sizeof(reply), "\x1b[8;%d;%dt", screen->rows, screen->cols);
                response_append(parser, reply);
            }
            break;
        }
        case 'p': { // DECRQM (`CSI ? Pd $ p` / `CSI Pa $ p`) — report mode status
            if (has_intermediate(parser, '$')) {
                int mode = parser->param_count > 0 ? parser->params[0] : 0;
                char reply[32];
                if (has_intermediate(parser, '?')) {
                    snprintf(reply, sizeof(reply), "\x1b[?%d;%d$y", mode, dec_mode_status(parser, mode));
                } else {
                    snprintf(reply, sizeof(reply), "\x1b[%d;0$y", mode);
                }
                response_append(parser, reply);
            }
            break;
        }
        case 'm': { // SGR
            handle_sgr(parser);
            break;
        }
        case 'r': { // Set Scrolling Region (with `?` this is XTRESTORE mode-restore — not DECSTBM)
            if (parser->intermediate_count > 0) break;
            int top = parser->param_count > 0 && parser->params[0] > 0 ? parser->params[0] - 1 : 0;
            int bottom = parser->param_count > 1 && parser->params[1] > 0 ? parser->params[1] - 1 : screen->rows - 1;
            if (top >= 0 && bottom < screen->rows && top < bottom) {
                screen->scroll_top = top;
                screen->scroll_bottom = bottom;
                screen->cursor_row = 0;
                screen->cursor_col = 0;
            }
            break;
        }
        case 's': { // Save Cursor (with `?` this is XTSAVE mode-save — must not clobber the cursor)
            if (parser->intermediate_count > 0) break;
            cursor_save(parser, screen);
            break;
        }
        case 'u': { // Restore Cursor (with `?` this is a kitty-keyboard-protocol query — ignore)
            if (parser->intermediate_count > 0) break;
            cursor_restore(parser, screen);
            break;
        }
        case 'h':   // Mode set   (DEC private when prefixed with `?`)
        case 'l': { // Mode reset (DEC private when prefixed with `?`)
            if (parser->intermediate_count > 0 && parser->intermediates[0] == '?') {
                bool set = (final_char == 'h');
                for (int i = 0; i < parser->param_count; i++) {
                    apply_dec_mode(parser, parser->params[i], set);
                }
            }
            break;
        }
    }
}

// Grow the OSC accumulator so the next byte fits; false once the hard cap is reached.
static bool osc_grow(VtParser* parser) {
    if (parser->osc_length < parser->osc_cap - 1) return true;
    if (parser->osc_cap >= VT_OSC_BUFFER_MAX) return false;
    int new_cap = parser->osc_cap * 2;
    if (new_cap > VT_OSC_BUFFER_MAX) new_cap = VT_OSC_BUFFER_MAX;
    char* grown = (char*)realloc(parser->osc_buffer, (size_t)new_cap);
    if (!grown) return false;
    parser->osc_buffer = grown;
    parser->osc_cap = new_cap;
    return true;
}

// Queue a JCode shell-integration OSC event for the host to drain (bounded ring; oldest dropped).
static void osc_event_push(VtParser* parser, int code, const char* payload) {
    size_t len = strlen(payload);
    char* copy = (char*)malloc(len + 1);
    if (!copy) return;
    memcpy(copy, payload, len + 1);
    if (parser->osc_event_count == VT_OSC_EVENT_CAP) {
        free(parser->osc_events[parser->osc_event_head].payload);
        parser->osc_events[parser->osc_event_head].payload = NULL;
        parser->osc_event_head = (parser->osc_event_head + 1) % VT_OSC_EVENT_CAP;
        parser->osc_event_count--;
    }
    int slot = (parser->osc_event_head + parser->osc_event_count) % VT_OSC_EVENT_CAP;
    parser->osc_events[slot].code = code;
    parser->osc_events[slot].payload = copy;
    parser->osc_event_count++;
}

// Handle OSC (Operating System Command). `bel_terminated` records which terminator ended the
// sequence so query replies can mirror it (xterm behavior — some parsers only accept their own).
static void handle_osc(VtParser* parser, bool bel_terminated) {
    // Parse command number
    int cmd = 0;
    int i = 0;
    while (i < parser->osc_length && parser->osc_buffer[i] >= '0' && parser->osc_buffer[i] <= '9') {
        cmd = cmd * 10 + (parser->osc_buffer[i] - '0');
        if (cmd > 65535) cmd = 65535;
        i++;
    }

    // Skip semicolon
    if (i < parser->osc_length && parser->osc_buffer[i] == ';') {
        i++;
    }

    // Handle specific commands
    if (cmd == 0 || cmd == 2) {
        // Set window title
        char* title = &parser->osc_buffer[i];
        if (parser->on_title_change) {
            parser->on_title_change(parser->userdata, title);
        }
    } else if ((cmd == 10 || cmd == 11) && parser->osc_buffer[i] == '?') {
        // Default foreground/background color query — used for light/dark theme detection
        // (Claude Code derives its theme from the OSC 11 reply). The renderer draws white on black.
        char reply[48];
        snprintf(reply, sizeof(reply), "\x1b]%d;rgb:%s%s", cmd,
                 cmd == 10 ? "ffff/ffff/ffff" : "0000/0000/0000",
                 bel_terminated ? "\x07" : "\x1b\\");
        response_append(parser, reply);
    } else if (cmd == 52) {
        // Clipboard write (OSC 52 "c;<base64>") — forwarded to the host to set the Android
        // clipboard. Queries ("?") are filtered host-side; the clipboard is never reported back.
        // A payload that overflowed even the grown accumulator is dropped whole: a missing
        // clipboard write is recoverable, a silently truncated one is not.
        if (!parser->osc_truncated) {
            osc_event_push(parser, cmd, &parser->osc_buffer[i]);
        }
    } else if (cmd >= 7711 && cmd <= 7716) {
        // JCode shell-integration events (7711 open-file, 7712 tab title, 7713 task complete,
        // 7714 open-url, 7715 nested-shell open, 7716 task progress): queued for the host to drain
        // after each feed (see vt_parser_osc_event_at), replacing the Kotlin-side per-byte re-scan
        // of the same output. Widen this range when adding a code, or the host never sees it.
        osc_event_push(parser, cmd, &parser->osc_buffer[i]);
    }
}

// State machine transition
static void parser_transition(VtParser* parser, uint8_t ch) {
    switch (parser->state) {
        case VT_STATE_GROUND:
            // UTF-8 continuation: while mid multi-byte sequence, fold in continuation bytes
            // (10xxxxxx) and emit the decoded codepoint once complete. Without this, each byte of a
            // multi-byte character (e.g. U+2502 '|' = E2 94 82) is written as its own garbage cell.
            if (parser->utf8_left > 0) {
                if ((ch & 0xC0) == 0x80) {
                    parser->utf8_acc = (parser->utf8_acc << 6) | (uint32_t)(ch & 0x3F);
                    if (--parser->utf8_left == 0) {
                        uint32_t cp = parser->utf8_acc;
                        // Reject overlong encodings (C0 80 would decode to U+0000 and forge the
                        // ch == 0 continuation marker), surrogates, and beyond-Unicode sequences
                        // (a stored cp > 0x10FFFF crashes the renderer's Character.toChars).
                        if (cp < parser->utf8_min || cp > 0x10FFFF ||
                            (cp >= 0xD800 && cp <= 0xDFFF)) {
                            cp = 0xFFFD;
                        }
                        screen_write_char(parser, cp);
                    }
                    break;
                }
                // Malformed sequence: emit a replacement glyph and reprocess this byte below.
                screen_write_char(parser, 0xFFFD);
                parser->utf8_left = 0;
            }
            if (ch == 0x1B) {
                parser->state = VT_STATE_ESCAPE;
            } else if (ch == 0x07) {
                // Bell
                if (parser->on_bell) parser->on_bell(parser->userdata);
            } else if (ch == 0x08) {
                // Backspace
                if (parser->active->cursor_col > 0) {
                    parser->active->cursor_col--;
                }
            } else if (ch == 0x09) {
                // Tab
                parser->active->cursor_col = (parser->active->cursor_col + 8) & ~7;
                if (parser->active->cursor_col >= parser->active->cols) {
                    parser->active->cursor_col = parser->active->cols - 1;
                }
            } else if (ch == 0x0A || ch == 0x0B || ch == 0x0C) {
                // Line feed
                screen_newline(parser);
            } else if (ch == 0x0D) {
                // Carriage return
                screen_carriage_return(parser);
            } else if (ch < 0x80) {
                // Printable ASCII
                if (ch >= 0x20) {
                    screen_write_char(parser, ch);
                }
            } else {
                // UTF-8 lead byte: begin a multi-byte sequence.
                if ((ch & 0xE0) == 0xC0) {        // 110xxxxx -> 1 continuation byte
                    parser->utf8_acc = (uint32_t)(ch & 0x1F);
                    parser->utf8_left = 1;
                    parser->utf8_min = 0x80;
                } else if ((ch & 0xF0) == 0xE0) { // 1110xxxx -> 2 continuation bytes
                    parser->utf8_acc = (uint32_t)(ch & 0x0F);
                    parser->utf8_left = 2;
                    parser->utf8_min = 0x800;
                } else if ((ch & 0xF8) == 0xF0) { // 11110xxx -> 3 continuation bytes
                    parser->utf8_acc = (uint32_t)(ch & 0x07);
                    parser->utf8_left = 3;
                    parser->utf8_min = 0x10000;
                } else {
                    // Stray continuation byte or invalid lead -> replacement glyph.
                    screen_write_char(parser, 0xFFFD);
                }
            }
            break;
            
        case VT_STATE_ESCAPE:
            if (ch == '[') {
                parser->state = VT_STATE_CSI_ENTRY;
                parser->param_count = 0;
                parser->current_param = 0;
                parser->intermediate_count = 0;
            } else if (ch == ']') {
                parser->state = VT_STATE_OSC_STRING;
                parser->osc_length = 0;
                parser->osc_truncated = false;
            } else if (ch == 'P') {
                parser->state = VT_STATE_DCS_ENTRY;
            } else if (ch == 'X' || ch == '^' || ch == '_') {
                parser->state = VT_STATE_SOS_PM_APC_STRING;
            } else if (ch >= 0x20 && ch <= 0x2F) {
                // Intermediate byte of an nF escape: charset designation (ESC ( B, ESC ) 0, ESC * B,
                // ESC + B, ESC % G), DECALN (ESC # 8), etc. Collect it and swallow the final byte in
                // ESCAPE_INTERMEDIATE — otherwise the final (B/0/G/8/…) leaks into GROUND and is printed
                // to the grid as a stray glyph that accumulates on the alternate screen.
                parser->state = VT_STATE_ESCAPE_INTERMEDIATE;
            } else if (ch == '7') {
                // DECSC — save cursor + attributes (same as CSI s).
                VtScreen* s = parser->active;
                s->saved_row = s->cursor_row;
                s->saved_col = s->cursor_col;
                s->saved_attrs = parser->attrs;
                s->saved_fg = parser->fg;
                s->saved_bg = parser->bg;
                parser->state = VT_STATE_GROUND;
            } else if (ch == '8') {
                // DECRC — restore cursor + attributes (same as CSI u).
                VtScreen* s = parser->active;
                s->cursor_row = s->saved_row;
                s->cursor_col = s->saved_col;
                parser->attrs = s->saved_attrs;
                parser->fg = s->saved_fg;
                parser->bg = s->saved_bg;
                parser->state = VT_STATE_GROUND;
            } else if (ch == 'D') {
                // IND — index (move down one line, scroll at bottom of region).
                screen_newline(parser);
                parser->state = VT_STATE_GROUND;
            } else if (ch == 'M') {
                // RI — reverse index (move up one line, scroll down at top of region).
                if (parser->active->cursor_row <= parser->active->scroll_top) {
                    screen_scroll_down(parser, 1);
                } else {
                    parser->active->cursor_row--;
                }
                parser->state = VT_STATE_GROUND;
            } else if (ch == 'E') {
                // NEL — next line (CR + LF).
                screen_carriage_return(parser);
                screen_newline(parser);
                parser->state = VT_STATE_GROUND;
            } else if (ch == 'c') {
                // RIS — full terminal reset.
                vt_parser_reset(parser);
                parser->state = VT_STATE_GROUND;
            } else {
                // Any other single-byte ESC final (keypad mode ESC =/>, etc.): consume, don't print.
                parser->state = VT_STATE_GROUND;
            }
            break;
            
        case VT_STATE_CSI_ENTRY:
            if (ch >= '0' && ch <= '9') {
                parser->current_param = ch - '0';
                parser->state = VT_STATE_CSI_PARAM;
            } else if (ch == ';') {
                if (parser->param_count < VT_MAX_PARAMS) {
                    parser->params[parser->param_count++] = 0;
                }
                parser->state = VT_STATE_CSI_PARAM;
            } else if (ch >= 0x40 && ch <= 0x7E) {
                // Final character
                handle_csi(parser, ch);
                parser->state = VT_STATE_GROUND;
            } else if (ch >= 0x3C && ch <= 0x3F) {
                // Private parameter markers: < = > ?  (DEC private modes `?`, XTVERSION `>q`,
                // XTMODKEYS `>...m`, secondary DA `>c`, …). Store and keep parsing so the whole
                // sequence is consumed instead of leaking its tail (params + final) as text.
                if (parser->intermediate_count < 4) {
                    parser->intermediates[parser->intermediate_count++] = ch;
                }
                parser->state = VT_STATE_CSI_PARAM;
            } else {
                parser->state = VT_STATE_GROUND;
            }
            break;

        case VT_STATE_CSI_PARAM:
            if (ch >= '0' && ch <= '9') {
                // Cap at xterm's 65535 so a hostile digit run can't overflow the accumulator
                // (signed overflow is UB) before the handlers' own clamps run.
                parser->current_param = parser->current_param * 10 + (ch - '0');
                if (parser->current_param > 65535) parser->current_param = 65535;
            } else if (ch == ';') {
                if (parser->param_count < VT_MAX_PARAMS) {
                    parser->params[parser->param_count++] = parser->current_param;
                }
                parser->current_param = 0;
            } else if (ch >= 0x40 && ch <= 0x7E) {
                // Final character
                if (parser->param_count < VT_MAX_PARAMS) {
                    parser->params[parser->param_count++] = parser->current_param;
                }
                handle_csi(parser, ch);
                parser->state = VT_STATE_GROUND;
            } else if (ch >= 0x20 && ch <= 0x2F) {
                // Intermediate
                if (parser->intermediate_count < 4) {
                    parser->intermediates[parser->intermediate_count++] = ch;
                }
                parser->state = VT_STATE_CSI_INTERMEDIATE;
            } else {
                parser->state = VT_STATE_CSI_IGNORE;
            }
            break;
            
        case VT_STATE_CSI_INTERMEDIATE:
            if (ch >= 0x40 && ch <= 0x7E) {
                if (parser->param_count < VT_MAX_PARAMS) {
                    parser->params[parser->param_count++] = parser->current_param;
                }
                handle_csi(parser, ch);
                parser->state = VT_STATE_GROUND;
            } else if (ch >= 0x20 && ch <= 0x2F) {
                if (parser->intermediate_count < 4) {
                    parser->intermediates[parser->intermediate_count++] = ch;
                }
            } else {
                parser->state = VT_STATE_CSI_IGNORE;
            }
            break;
            
        case VT_STATE_CSI_IGNORE:
            if (ch >= 0x40 && ch <= 0x7E) {
                parser->state = VT_STATE_GROUND;
            }
            break;
            
        case VT_STATE_OSC_STRING:
            if (ch == 0x07 || ch == 0x1B) {
                // End of OSC
                parser->osc_buffer[parser->osc_length] = '\0';
                handle_osc(parser, ch == 0x07);
                parser->state = (ch == 0x1B) ? VT_STATE_ESCAPE : VT_STATE_GROUND;
            } else if (osc_grow(parser)) {
                parser->osc_buffer[parser->osc_length++] = ch;
            } else {
                parser->osc_truncated = true;
            }
            break;
            
        case VT_STATE_DCS_ENTRY:
        case VT_STATE_DCS_PARAM:
        case VT_STATE_DCS_INTERMEDIATE:
        case VT_STATE_DCS_PASSTHROUGH:
        case VT_STATE_DCS_IGNORE:
            // DCS sequences - consume until ST
            if (ch == 0x1B) {
                parser->state = VT_STATE_ESCAPE;
            } else if (ch == 0x07) {
                parser->state = VT_STATE_GROUND;
            }
            break;
            
        case VT_STATE_SOS_PM_APC_STRING:
            // Consume until ST
            if (ch == 0x1B) {
                parser->state = VT_STATE_ESCAPE;
            } else if (ch == 0x07) {
                parser->state = VT_STATE_GROUND;
            }
            break;
            
        case VT_STATE_ESCAPE_INTERMEDIATE:
            // Keep collecting intermediate bytes; the final (0x30-0x7E) ends the escape. Charset
            // designations and similar nF escapes aren't rendered, so consume the final without printing.
            if (ch < 0x20 || ch > 0x2F) {
                parser->state = VT_STATE_GROUND;
            }
            break;
    }
}

// Public API implementation

VtParser* vt_parser_create(int rows, int cols) {
    VtParser* parser = (VtParser*)calloc(1, sizeof(VtParser));
    if (!parser) return NULL;
    
    parser->state = VT_STATE_GROUND;
    
    // Create screens
    parser->primary.cells = NULL;
    parser->alternate.cells = NULL;
    
    VtScreen* primary = screen_create(rows, cols);
    VtScreen* alternate = screen_create(rows, cols);
    
    if (!primary || !alternate) {
        screen_destroy(primary);
        screen_destroy(alternate);
        free(parser);
        return NULL;
    }
    
    parser->primary = *primary;
    parser->alternate = *alternate;
    free(primary);
    free(alternate);
    
    parser->active = &parser->primary;

    // OSC accumulator (grows on demand — see osc_grow). Failure paths free the embedded screens'
    // cells directly — screen_destroy would free() the embedded structs themselves, which are not
    // heap pointers.
    parser->osc_cap = VT_OSC_BUFFER_CAP;
    parser->osc_buffer = (char*)malloc((size_t)parser->osc_cap);
    if (!parser->osc_buffer) {
        free(parser->primary.cells);
        free(parser->primary.row_flags);
        free(parser->alternate.cells);
        free(parser->alternate.row_flags);
        free(parser);
        return NULL;
    }

    // Allocate scrollback ring buffer (non-fatal if it fails; scrollback just stays empty).
    parser->scrollback_cap = VT_SCROLLBACK_CAP;
    parser->scrollback_cols = cols;
    parser->scrollback_count = 0;
    parser->scrollback_head = 0;
    parser->scrollback = (VtCell*)calloc((size_t)parser->scrollback_cap * (size_t)cols, sizeof(VtCell));
    parser->scrollback_flags = (uint8_t*)calloc((size_t)parser->scrollback_cap, 1);
    if (!parser->scrollback || !parser->scrollback_flags) {
        free(parser->scrollback);
        free(parser->scrollback_flags);
        parser->scrollback = NULL;
        parser->scrollback_flags = NULL;
        parser->scrollback_cap = 0;
    }

    // Initialize default colors
    parser->fg.mode = 0;
    parser->bg.mode = 0;
    parser->attrs = 0;

    // calloc zeroed every mode flag; autowrap and alternate-scroll (xterm-style wheel->arrows
    // on the alt screen, resettable via DECRST ?1007) default on.
    parser->decawm = true;
    parser->alt_scroll = true;

    return parser;
}

void vt_parser_destroy(VtParser* parser) {
    if (!parser) return;

    vt_parser_osc_clear(parser);
    free(parser->osc_buffer);
    free(parser->primary.cells);
    free(parser->primary.row_flags);
    free(parser->alternate.cells);
    free(parser->alternate.row_flags);
    free(parser->scrollback);
    free(parser->scrollback_flags);
    free(parser);
}

int vt_parser_osc_event_count(const VtParser* parser) {
    return parser ? parser->osc_event_count : 0;
}

bool vt_parser_osc_event_at(const VtParser* parser, int index, int* code, const char** payload) {
    if (!parser || index < 0 || index >= parser->osc_event_count) return false;
    int idx = (parser->osc_event_head + index) % VT_OSC_EVENT_CAP;
    if (code) *code = parser->osc_events[idx].code;
    if (payload) *payload = parser->osc_events[idx].payload;
    return true;
}

void vt_parser_osc_clear(VtParser* parser) {
    if (!parser) return;
    for (int k = 0; k < parser->osc_event_count; k++) {
        int idx = (parser->osc_event_head + k) % VT_OSC_EVENT_CAP;
        free(parser->osc_events[idx].payload);
        parser->osc_events[idx].payload = NULL;
    }
    parser->osc_event_count = 0;
    parser->osc_event_head = 0;
}

int vt_parser_take_responses(VtParser* parser, uint8_t* out, int cap) {
    if (!parser || !out || cap <= 0) return 0;
    int n = parser->response_len < cap ? parser->response_len : cap;
    memcpy(out, parser->responses, (size_t)n);
    if (n < parser->response_len) {
        memmove(parser->responses, parser->responses + n, (size_t)(parser->response_len - n));
    }
    parser->response_len -= n;
    return n;
}

int vt_parser_input_modes(const VtParser* parser) {
    if (!parser) return 0;
    int modes = 0;
    if (parser->decckm) modes |= VT_MODE_APP_CURSOR_KEYS;
    if (parser->bracketed_paste) modes |= VT_MODE_BRACKETED_PASTE;
    if (parser->focus_events) modes |= VT_MODE_FOCUS_EVENTS;
    if (parser->alt_scroll) modes |= VT_MODE_ALT_SCROLL;
    if (parser->sync_output) modes |= VT_MODE_SYNC_OUTPUT;
    if (parser->active == &parser->alternate) modes |= VT_MODE_ALT_SCREEN;
    modes |= ((int)parser->mouse_mode & 0x7) << VT_MODE_MOUSE_SHIFT;
    modes |= ((int)parser->mouse_enc & 0x3) << VT_MODE_MOUSE_ENC_SHIFT;
    return modes;
}

int vt_parser_scrollback_count(const VtParser* parser) {
    if (!parser) return 0;
    // The alternate screen (vim/htop/less) manages its own buffer; no scrollback there.
    if (parser->active == &parser->alternate) return 0;
    return parser->scrollback_count;
}

const VtCell* vt_parser_row_ptr(const VtParser* parser, int row) {
    if (!parser) return NULL;
    const VtScreen* screen = parser->active;
    if (row >= 0) {
        if (row >= screen->rows) return NULL;
        return &screen->cells[row * screen->cols];
    }
    // Negative row -> scrollback. row == -1 is the most recently scrolled-off line.
    int sb_count = vt_parser_scrollback_count(parser);
    int line = sb_count + row;
    if (line < 0 || line >= sb_count) return NULL;
    int idx = (parser->scrollback_head + line) % parser->scrollback_cap;
    return &parser->scrollback[idx * parser->scrollback_cols];
}

int vt_parser_row_cols(const VtParser* parser, int row) {
    if (!parser) return 0;
    return row >= 0 ? parser->active->cols : parser->scrollback_cols;
}

const VtCell* vt_parser_cell_at(const VtParser* parser, int row, int col) {
    if (!parser) return NULL;
    if (col < 0 || col >= parser->active->cols) return NULL;
    if (row < 0 && col >= parser->scrollback_cols) return NULL;
    const VtCell* base = vt_parser_row_ptr(parser, row);
    return base ? base + col : NULL;
}

void vt_parser_feed(VtParser* parser, const uint8_t* data, size_t len) {
    if (!parser || !data) return;

    for (size_t i = 0; i < len; i++) {
        // Fast path: in GROUND state, a run of printable ASCII (the dominant byte class in
        // streamed output) is written directly into the row — one bounds check per run instead
        // of per-byte state dispatch + per-cell checks. The run stops at
        // the row edge, leaving the same parked-cursor state the slow path's deferred wrap
        // produces; 0x7F is included because the slow path prints every byte in [0x20, 0x7F].
        if (parser->state == VT_STATE_GROUND && parser->utf8_left == 0 &&
            data[i] >= 0x20 && data[i] < 0x80) {
            VtScreen* s = parser->active;
            if (s->cursor_col < s->cols && s->cursor_row >= 0 && s->cursor_row < s->rows) {
                size_t max_run = (size_t)(s->cols - s->cursor_col);
                if (max_run > len - i) max_run = len - i;
                VtCell* cell = &s->cells[s->cursor_row * s->cols + s->cursor_col];
                bool start_was_cont = cell[0].ch == 0;
                size_t run = 0;
                while (run < max_run && data[i + run] >= 0x20 && data[i + run] < 0x80) {
                    cell[run].ch = data[i + run];
                    cell[run].fg = parser->fg;
                    cell[run].bg = parser->bg;
                    cell[run].attrs = parser->attrs;
                    run++;
                }
                if (run > 0) {
                    // Repair wide pairs the run split: overwriting a continuation orphans the
                    // lead before the run; overwriting a lead orphans the continuation after it.
                    if (start_was_cont && s->cursor_col > 0) cell[-1] = VT_BLANK;
                    if (s->cursor_col + (int)run < s->cols && cell[run].ch == 0) cell[run] = VT_BLANK;
                    // C1b, the fast path's half of C1. A run starting at column 0 cannot follow a
                    // wrap: both wrap sites leave the cursor at column `width` (1 or 2), never 0, so
                    // the cursor got here by CR/LF/CUP and this row starts a new logical line.
                    if (s->cursor_col == 0) row_flags_clear(s, s->cursor_row, VT_ROW_WRAPPED | VT_ROW_WRAP_PAD);
                    s->cursor_col += (int)run;
                    i += run - 1;
                    continue;
                }
            }
        }
        parser_transition(parser, data[i]);
    }
}

// Copy a row (col-limited) from src cells to dst cells.
static void copy_row_cells(VtCell* dst, int dst_cols, const VtCell* src, int src_cols) {
    int n = dst_cols < src_cols ? dst_cols : src_cols;
    for (int c = 0; c < n; c++) dst[c] = src[c];
}

// --- column rewrap ----------------------------------------------------------
//
// Resize re-splits long lines at the new width instead of truncating or padding them.
//
// The two halves are deliberately asymmetric, and that asymmetry is what keeps applications working:
//
//   JOIN happens only across VT_ROW_WRAPPED, which is set at the two DECAWM sites and nowhere else.
//   Rows an application laid out itself, ended by CR/LF, are never merged — merging them would fuse
//   unrelated lines and smear them on the next split.
//
//   SPLIT happens for any logical line longer than the new width, wrapped or not. Restricting it to
//   previously-wrapped rows was tried and is wrong in the common case: output that fit the old width
//   was never wrapped, so narrowing would silently truncate every line of it.
//
// A row SHORTER than the new width is therefore never touched at all, which is the property a TUI
// relies on — its frame keeps its exact geometry. A row longer than the new width can only belong to
// content that has already overflowed, and the application is about to repaint it on SIGWINCH
// anyway. This is also what xterm.js does, which is what these CLIs already run against elsewhere.

// How many leading cells of a row are content rather than trailing padding. A space counts as
// padding only when it carries no attributes and no background, so a coloured bar or an underlined
// run is content; ch == 0 is a wide continuation and stops the scan immediately.
static int row_content_len(const VtCell* row, int cols) {
    int n = cols;
    while (n > 0) {
        const VtCell* c = &row[n - 1];
        if (c->ch != ' ' || c->attrs != 0 || c->bg.mode != 0) break;
        n--;
    }
    return n;
}

// A position being carried through the reflow: the live cursor and the DECSC save slot. Recording
// where each one's own character lands is what keeps the cursor on its content rather than merely
// on its row number.
typedef struct {
    int src_index;      // index into the source row sequence
    int src_col;
    int64_t out_row;    // absolute emitted row
    int out_col;
    bool placed;
} VtTrackPoint;

// Source row [i] of the reflow sequence: scrollback lines oldest-first, then the live screen's rows.
static void reflow_src(const VtParser* parser, const VtScreen* screen, int sb_count, int i,
                       const VtCell** cells, int* cols, uint8_t* flags) {
    if (i < sb_count) {
        int idx = (parser->scrollback_head + i) % parser->scrollback_cap;
        *cells = &parser->scrollback[idx * parser->scrollback_cols];
        *cols = parser->scrollback_cols;
        *flags = parser->scrollback_flags ? parser->scrollback_flags[idx] : 0;
    } else {
        int r = i - sb_count;
        *cells = &screen->cells[r * screen->cols];
        *cols = screen->cols;
        *flags = row_flags_get(screen, r);
    }
}

// Rebuild the primary screen and scrollback at [cols], rejoining and re-splitting wrapped runs.
// Returns false without touching anything if it cannot proceed, so the caller falls back to the
// clamp/copy path.
static bool reflow_primary(VtParser* parser, int rows, int cols) {
    VtScreen* old = &parser->primary;
    const int old_cols = old->cols;
    const int cap = parser->scrollback_cap;
    if (!parser->scrollback || cap <= rows) return false;

    // Rows below the content are blank filler and are regenerated as blanks, so widening frees rows
    // at the bottom rather than pushing content down.
    int content_end = 0;
    for (int r = 0; r < old->rows; r++) {
        if (row_content_len(&old->cells[r * old_cols], old_cols) > 0) content_end = r + 1;
    }
    if (old->cursor_row + 1 > content_end) content_end = old->cursor_row + 1;
    if (content_end > old->rows) content_end = old->rows;

    const int sb_count = parser->scrollback_count;
    const int src_count = sb_count + content_end;

    VtCell* ring = (VtCell*)calloc((size_t)cap * (size_t)cols, sizeof(VtCell));
    uint8_t* ring_flags = (uint8_t*)calloc((size_t)cap, 1);
    VtScreen* nw = screen_create(rows, cols);
    if (!ring || !ring_flags || !nw) {
        free(ring);
        free(ring_flags);
        if (nw) screen_destroy(nw);
        return false;
    }

    VtTrackPoint pts[2] = {
        { sb_count + old->cursor_row, old->cursor_col, 0, 0, false },
        { sb_count + old->saved_row,  old->saved_col,  0, 0, false },
    };

    int64_t total = 0;
    int fill = 0;
    VtCell* dst = &ring[0];
    clear_cells(dst, cols);
    ring_flags[0] = 0;

    for (int i = 0; i < src_count; ) {
        // A run is a row without the wrapped bit plus every consecutive row that has it.
        int j = i + 1;
        while (j < src_count) {
            const VtCell* c; int cc; uint8_t f;
            reflow_src(parser, old, sb_count, j, &c, &cc, &f);
            if (!(f & VT_ROW_WRAPPED)) break;
            j++;
        }

        // Start this run on a fresh emitted row.
        int slot = (int)(total % cap);
        dst = &ring[slot * cols];
        clear_cells(dst, cols);
        ring_flags[slot] = 0;
        fill = 0;

        for (int k = i; k < j; k++) {
            const VtCell* src; int scols; uint8_t sflags;
            reflow_src(parser, old, sb_count, k, &src, &scols, &sflags);

            // The final segment is trimmed of trailing padding; an interior segment ran to the edge
            // by construction, minus the wide-char pad cell the next row records.
            int len;
            if (k == j - 1) {
                len = row_content_len(src, scols);
            } else {
                const VtCell* nc; int ncc; uint8_t nf;
                reflow_src(parser, old, sb_count, k + 1, &nc, &ncc, &nf);
                len = scols - ((nf & VT_ROW_WRAP_PAD) ? 1 : 0);
            }
            if (len > scols) len = scols;

            int c = 0;
            while (c < len) {
                if (src[c].ch == 0) { c++; continue; }  // orphaned continuation: drop
                int span = (vt_wcwidth(src[c].ch) == 2 && c + 1 < scols && src[c + 1].ch == 0) ? 2 : 1;
                if (fill + span > cols) {
                    // A wide character that will not fit gets the same pad-and-wrap xterm applies at
                    // write time, recorded so a later rejoin drops the pad instead of keeping a space.
                    uint8_t nf = VT_ROW_WRAPPED;
                    if (span == 2 && fill == cols - 1) { dst[fill] = VT_BLANK; nf |= VT_ROW_WRAP_PAD; }
                    total++;
                    slot = (int)(total % cap);
                    dst = &ring[slot * cols];
                    clear_cells(dst, cols);
                    ring_flags[slot] = nf;
                    fill = 0;
                }
                for (int p = 0; p < 2; p++) {
                    if (!pts[p].placed && pts[p].src_index == k && pts[p].src_col >= c && pts[p].src_col < c + span) {
                        pts[p].out_row = total;
                        pts[p].out_col = fill;
                        pts[p].placed = true;
                    }
                }
                for (int t = 0; t < span; t++) dst[fill + t] = src[c + t];
                fill += span;
                c += span;
            }

            // A point at or past this row's content end — the parked cursor is the common case —
            // lands where the row finished. Because the row is flushed lazily, a run whose length is
            // an exact multiple of cols leaves fill == cols, so the cursor stays PARKED rather than
            // moving to column 0 of a new row.
            for (int p = 0; p < 2; p++) {
                if (!pts[p].placed && pts[p].src_index == k) {
                    int over = pts[p].src_col - len;
                    if (over < 0) over = 0;
                    int oc = fill + over;
                    pts[p].out_row = total;
                    pts[p].out_col = oc > cols ? cols : oc;
                    pts[p].placed = true;
                }
            }
        }

        total++;  // flush the run's last row
        i = j;
    }

    // Anything that never matched a source row (a saved cursor below the content) keeps its offset
    // from the end of what was emitted.
    for (int p = 0; p < 2; p++) {
        if (!pts[p].placed) {
            pts[p].out_row = total + (pts[p].src_index - src_count);
            pts[p].out_col = pts[p].src_col;
        }
    }

    // The tail becomes the screen; everything before it is history. With less than a screenful the
    // content stays top-anchored, which is what keeps a short session free of a blank gap above the
    // prompt (and free of the duplicate prompt that anchoring the other way used to produce).
    int64_t visible = total < rows ? total : rows;
    int64_t top = total - visible;
    for (int64_t r = 0; r < visible; r++) {
        int slot = (int)((top + r) % cap);
        memcpy(&nw->cells[(size_t)r * cols], &ring[(size_t)slot * cols], (size_t)cols * sizeof(VtCell));
        if (nw->row_flags) nw->row_flags[r] = ring_flags[slot];
    }

    int64_t avail = cap - visible;                       // ring slots the visible tail did not take
    int new_count = (int)(top < avail ? top : avail);
    int old_count = parser->scrollback_count;

    for (int p = 0; p < 2; p++) {
        int64_t r = pts[p].out_row - top;
        if (r < 0) r = 0;
        if (r >= rows) r = rows - 1;
        int c = pts[p].out_col;
        if (c < 0) c = 0;
        // cols (not cols-1) is legal: it is the deferred-wrap parked position.
        if (c > cols) c = cols;
        if (p == 0) { nw->cursor_row = (int)r; nw->cursor_col = c; }
        else        { nw->saved_row  = (int)r; nw->saved_col  = c; }
    }
    nw->cursor_visible = old->cursor_visible;
    nw->saved_attrs = old->saved_attrs;
    nw->saved_fg = old->saved_fg;
    nw->saved_bg = old->saved_bg;
    nw->scroll_top = 0;
    nw->scroll_bottom = rows - 1;

    free(parser->scrollback);
    free(parser->scrollback_flags);
    parser->scrollback = ring;
    parser->scrollback_flags = ring_flags;
    parser->scrollback_cols = cols;
    parser->scrollback_count = new_count;
    parser->scrollback_head = (int)((top - new_count) % cap);
    // Monotonic by contract: a resize re-partitions existing lines, so only a net gain counts.
    if (new_count > old_count) parser->scrollback_pushed += (int64_t)(new_count - old_count);

    free(old->cells);
    free(old->row_flags);
    parser->primary = *nw;
    free(nw);
    return true;
}

// Carry the DECSC/DECRC save slot across a resize. [row_shift] is the same displacement the live
// cursor took, so the saved position keeps pointing at the content it was saved on. The SGR fields
// are not positional and copy verbatim. Resize replaces the screen struct wholesale, so without
// this the slot silently reverts to screen_create's zeroed state.
static void screen_carry_saved(VtScreen* nw, const VtScreen* old, int row_shift, int rows, int cols) {
    int r = old->saved_row + row_shift;
    if (r < 0) r = 0;
    if (r >= rows) r = rows - 1;
    int c = old->saved_col;
    if (c < 0) c = 0;
    if (c >= cols) c = cols - 1;
    nw->saved_row = r;
    nw->saved_col = c;
    nw->saved_attrs = old->saved_attrs;
    nw->saved_fg = old->saved_fg;
    nw->saved_bg = old->saved_bg;
}

void vt_parser_resize(VtParser* parser, int rows, int cols) {
    if (!parser) return;
    if (rows <= 0 || cols <= 0) return;
    int old_rows = parser->primary.rows;
    int old_cols = parser->primary.cols;
    if (old_rows == rows && old_cols == cols) return;

    bool on_primary = (parser->active == &parser->primary);

    // 0) A width change re-splits wrapped lines (see reflow_primary). A height-only change — every
    //    keyboard open and close — skips all of it and takes the cheap row reflow below, unchanged.
    bool rewrapped = (cols != old_cols) && reflow_primary(parser, rows, cols);

    // 1) Reallocate scrollback to the new column count first (preserve stored lines; no width reflow),
    //    re-basing the ring so logical line L lives at index ((head + L) % cap).
    if (!rewrapped && parser->scrollback && parser->scrollback_cap > 0 && cols != parser->scrollback_cols) {
        VtCell* new_sb = (VtCell*)calloc((size_t)parser->scrollback_cap * (size_t)cols, sizeof(VtCell));
        if (new_sb) {
            for (int i = 0; i < parser->scrollback_cap * cols; i++) new_sb[i].ch = ' ';
            int ccols = cols < parser->scrollback_cols ? cols : parser->scrollback_cols;
            for (int l = 0; l < parser->scrollback_count; l++) {
                int src = (parser->scrollback_head + l) % parser->scrollback_cap;
                for (int c = 0; c < ccols; c++) new_sb[l * cols + c] = parser->scrollback[src * parser->scrollback_cols + c];
            }
            // The ring is re-based to head 0, so the parallel flag ring must be re-based with it or
            // every stored line's wrap bit would end up describing a different line.
            if (parser->scrollback_flags) {
                uint8_t* new_fl = (uint8_t*)calloc((size_t)parser->scrollback_cap, 1);
                if (new_fl) {
                    for (int l = 0; l < parser->scrollback_count; l++) {
                        new_fl[l] = parser->scrollback_flags[(parser->scrollback_head + l) % parser->scrollback_cap];
                    }
                    free(parser->scrollback_flags);
                    parser->scrollback_flags = new_fl;
                }
            }
            free(parser->scrollback);
            parser->scrollback = new_sb;
            parser->scrollback_cols = cols;
            parser->scrollback_head = 0;
        }
    }

    // 2) Resize the PRIMARY screen, anchoring content to the bottom and reflowing through scrollback so
    //    nothing is lost or duplicated. Growing pulls recent scrollback lines back into the top; shrinking
    //    pushes the top lines into scrollback. The cursor moves with the content (NOT reset to 0,0 — that
    //    was the bug that let post-resize redraws corrupt existing rows).
    if (!rewrapped) {
        VtScreen* old = &parser->primary;
        VtScreen* nw = screen_create(rows, cols);
        if (!nw) return;
        int saved_shift = 0;

        if (rows >= old_rows) {
            int delta = rows - old_rows;
            // Backfill the new height from scrollback, but only as far as history actually exists.
            // Old content shifts DOWN by `from_sb`; any remaining new rows are appended at the BOTTOM
            // (blank). With no history this keeps content top-anchored (no blank gap above the prompt).
            int from_sb = parser->scrollback_count < delta ? parser->scrollback_count : delta;
            for (int r = 0; r < old_rows; r++) {
                copy_row_cells(&nw->cells[(r + from_sb) * cols], cols, &old->cells[r * old_cols], old_cols);
                row_flags_set(nw, r + from_sb, row_flags_get(old, r));
            }
            for (int k = 0; k < from_sb; k++) {
                int sb_line = parser->scrollback_count - from_sb + k;
                int src = (parser->scrollback_head + sb_line) % parser->scrollback_cap;
                copy_row_cells(&nw->cells[k * cols], cols,
                               &parser->scrollback[src * parser->scrollback_cols], parser->scrollback_cols);
                if (parser->scrollback_flags) row_flags_set(nw, k, parser->scrollback_flags[src]);
            }
            parser->scrollback_count -= from_sb;
            nw->cursor_row = old->cursor_row + from_sb;
            saved_shift = from_sb;
        } else {
            int delta = old_rows - rows;
            // Cursor-anchored: scroll off only as many TOP rows as needed to keep the cursor on the
            // last visible row. If the cursor already fits in the new height (screen mostly empty),
            // scroll == 0 and we simply drop blank rows from the bottom — the prompt is NOT pushed
            // into scrollback (which previously caused a duplicate prompt when growing back).
            int scroll = old->cursor_row - (rows - 1);
            if (scroll < 0) scroll = 0;
            if (scroll > delta) scroll = delta;
            for (int r = 0; r < scroll; r++) {
                scrollback_push(parser, &old->cells[r * old_cols], old_cols, row_flags_get(old, r));
            }
            for (int r = 0; r < rows; r++) {
                copy_row_cells(&nw->cells[r * cols], cols, &old->cells[(r + scroll) * old_cols], old_cols);
                row_flags_set(nw, r, row_flags_get(old, r + scroll));
            }
            nw->cursor_row = old->cursor_row - scroll;
            saved_shift = -scroll;
        }
        nw->cursor_col = old->cursor_col;
        if (nw->cursor_row < 0) nw->cursor_row = 0;
        if (nw->cursor_row >= rows) nw->cursor_row = rows - 1;
        if (nw->cursor_col < 0) nw->cursor_col = 0;
        if (nw->cursor_col >= cols) nw->cursor_col = cols - 1;
        // The SAVED cursor is a position in the old grid too, so it takes the same row shift the
        // live cursor just took. Without this it was silently reset to 0,0 by screen_create's calloc
        // — and since ESC 7 / CSI s / the ?1049 alt-screen switch all restore through it, a resize
        // while a full-screen app was running sent the shell's prompt back to the top of the screen
        // on exit, redrawing over existing rows.
        screen_carry_saved(nw, old, saved_shift, rows, cols);
        nw->cursor_visible = old->cursor_visible;
        nw->scroll_top = 0;
        nw->scroll_bottom = rows - 1;
        free(old->cells);
        free(old->row_flags);
        parser->primary = *nw;
        free(nw);
    }

    // 3) Resize the ALTERNATE screen with a simple clamp/copy. Full-screen apps (vim, htop, less) repaint
    //    themselves on SIGWINCH, and the alternate screen has no scrollback.
    {
        VtScreen* old = &parser->alternate;
        VtScreen* nw = screen_create(rows, cols);
        if (!nw) return;
        int crows = rows < old_rows ? rows : old_rows;
        for (int r = 0; r < crows; r++) {
            copy_row_cells(&nw->cells[r * cols], cols, &old->cells[r * old_cols], old_cols);
        }
        nw->cursor_row = old->cursor_row < rows ? old->cursor_row : rows - 1;
        nw->cursor_col = old->cursor_col < cols ? old->cursor_col : cols - 1;
        // No row shift here — the alternate screen is clamped in place, not reflowed.
        screen_carry_saved(nw, old, 0, rows, cols);
        nw->cursor_visible = old->cursor_visible;
        nw->scroll_top = 0;
        nw->scroll_bottom = rows - 1;
        free(old->cells);
        free(old->row_flags);
        parser->alternate = *nw;
        free(nw);
    }

    parser->active = on_primary ? &parser->primary : &parser->alternate;
}

const VtScreen* vt_parser_get_screen(const VtParser* parser) {
    return parser ? parser->active : NULL;
}

bool vt_parser_is_alternate_screen(const VtParser* parser) {
    return parser && parser->active == &parser->alternate;
}

void vt_parser_reset(VtParser* parser) {
    if (!parser) return;
    
    parser->state = VT_STATE_GROUND;
    parser->param_count = 0;
    parser->current_param = 0;
    parser->intermediate_count = 0;
    parser->osc_length = 0;
    parser->osc_truncated = false;
    vt_parser_osc_clear(parser);
    parser->response_len = 0;
    parser->utf8_acc = 0;
    parser->utf8_min = 0;
    parser->utf8_left = 0;
    parser->attrs = 0;
    parser->fg.mode = 0;
    parser->bg.mode = 0;

    parser->decckm = false;
    parser->decawm = true;
    parser->bracketed_paste = false;
    parser->focus_events = false;
    parser->alt_scroll = true;
    parser->sync_output = false;
    parser->mouse_mode = VT_MOUSE_OFF;
    parser->mouse_enc = VT_MOUSE_ENC_X10;
    
    screen_clear(&parser->primary);
    screen_clear(&parser->alternate);
    parser->active = &parser->primary;

    parser->scrollback_count = 0;
    parser->scrollback_head = 0;
    
    parser->primary.cursor_row = 0;
    parser->primary.cursor_col = 0;
    parser->alternate.cursor_row = 0;
    parser->alternate.cursor_col = 0;
    
}
