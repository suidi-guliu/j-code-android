package dev.blamspot.jcode

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.isSpecified
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.blamspot.jcode.core.debug.DebugState
import dev.blamspot.jcode.design.IconSize
import dev.blamspot.jcode.design.JCodeIcon
import dev.blamspot.jcode.design.JcTooltip
import dev.blamspot.jcode.design.Radius
import dev.blamspot.jcode.design.Space
import dev.blamspot.jcode.design.jcIcon
import dev.blamspot.jcode.workbench.DebugSessionUi

/** Whether a session is up: there is something to step, inspect and stop. Three places asked this
 *  question and each spelled the answer out again. */
internal val DebugSessionUi.active: Boolean
    get() = state != DebugState.DISCONNECTED && state != DebugState.TERMINATED

/**
 * A running debug session: transport toolbar, call stack and variables.
 *
 * Only shown while a session is up. That is the one state where this is something no other control
 * does, and where a heading, a surface and a state chip are carrying their weight. The idle
 * fallback is [DebugLaunchRow], which the caller places on its own.
 *
 * Reads its state from [dev.blamspot.jcode.workbench.LocalDebugSession]; the caller passes the
 * resolved [ui].
 */
@Composable
internal fun DebugSessionPanel(ui: DebugSessionUi, modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(Space.s)) {
        Row(
            modifier = Modifier.padding(start = Space.xxs),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(Space.sm),
        ) {
            Icon(jcIcon(JCodeIcon.Debug), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            // "Debug session", not "Debug": beside a row of run configs each carrying their own Debug
            // button, a section called Debug reads as a second, different Debug command.
            Text("Debug session", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            DebugStateChip(ui.state)
        }
        DebugToolbar(ui)
        if (ui.callStack.isNotEmpty()) CallStackList(ui)
        if (ui.variables.isNotEmpty()) VariablesList(ui)
        // Console output lives in the right-drawer "Debug" tab (alongside Terminal/Output), not here.
    }
}

/**
 * Start a session on the file in the editor — the way in for a project with no run config to start
 * one from.
 *
 * The caller places this only when there is a target, so there is no "open a source file" state: a
 * project with nothing to debug has already been told it has no run config, and a second line
 * saying there is nothing to debug either was the panel repeating itself.
 */
@Composable
internal fun DebugLaunchRow(ui: DebugSessionUi) {
    val target = ui.debugTargetName
    when {
        target != null && ui.canDebug -> {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.12f),
                shape = RoundedCornerShape(Radius.lg),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = Space.ms, end = Space.xxs, top = Space.xxs, bottom = Space.xxs),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(Space.xs),
                ) {
                    Text(
                        text = "Debug $target",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    JcTooltip("Start debugging") {
                        IconButton(onClick = ui.onDebug) {
                            Icon(
                                painter = jcIcon(JCodeIcon.Debug),
                                contentDescription = "Start debugging",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                    }
                }
            }
        }
        // Kept, because it is a diagnosis rather than an empty state: it names the engine that is
        // missing and where to install it.
        target != null -> Text(
            "No debug engine installed for $target. Install one in Debug Engines (DBG).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun DebugToolbar(ui: DebugSessionUi) {
    val stopped = ui.state == DebugState.STOPPED
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = Space.xxs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Space.xxs),
    ) {
        DebugAction(JCodeIcon.Continue, "Continue", enabled = stopped, tint = MaterialTheme.colorScheme.primary, onClick = ui.onContinue)
        DebugAction(JCodeIcon.StepOver, "Step over", enabled = stopped, onClick = ui.onStepOver)
        DebugAction(JCodeIcon.StepInto, "Step into", enabled = stopped, onClick = ui.onStepInto)
        DebugAction(JCodeIcon.StepOut, "Step out", enabled = stopped, onClick = ui.onStepOut)
        Spacer(Modifier.weight(1f))
        DebugAction(JCodeIcon.Stop, "Stop", enabled = true, tint = MaterialTheme.colorScheme.error, onClick = ui.onStop)
    }
}

@Composable
private fun DebugAction(icon: JCodeIcon, label: String, enabled: Boolean, tint: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurfaceVariant, onClick: () -> Unit) {
    JcTooltip(label) {
        IconButton(onClick = onClick, enabled = enabled) {
            Icon(
                painter = jcIcon(icon),
                contentDescription = label,
                tint = if (enabled) tint else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                modifier = Modifier.size(IconSize.lg),
            )
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = Space.xs, top = Space.xxs),
    )
}

@Composable
private fun CallStackList(ui: DebugSessionUi) {
    SectionLabel("Call stack")
    Column(
        modifier = Modifier.fillMaxWidth().heightIn(max = 140.dp).verticalScroll(rememberScrollState()),
    ) {
        ui.callStack.forEach { frame ->
            val where = frame.sourcePath?.substringAfterLast('/')?.let { "$it:${frame.line}" } ?: ""
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = Space.xs, vertical = Space.xxs),
                horizontalArrangement = Arrangement.spacedBy(Space.sm),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = frame.name,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (where.isNotEmpty()) {
                    Text(
                        text = where,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}

@Composable
private fun VariablesList(ui: DebugSessionUi) {
    SectionLabel("Variables")
    Column(
        modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp).verticalScroll(rememberScrollState()),
    ) {
        ui.variables.forEach { row ->
            if (row.depth == 0) {
                Text(
                    text = row.name,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = Space.xs, top = Space.xs, bottom = Space.hairline),
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = Space.lg, end = Space.xs, top = Space.hairline, bottom = Space.hairline),
                    horizontalArrangement = Arrangement.spacedBy(Space.s),
                ) {
                    Text(
                        text = row.name,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(0.4f, fill = false),
                    )
                    Text(
                        text = row.value,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

/** Scrolling monospace console lines — shared by the Debug side-panel and the right-drawer tab. */
@Composable
internal fun DebugConsoleLines(
    lines: List<String>,
    maxHeight: androidx.compose.ui.unit.Dp = androidx.compose.ui.unit.Dp.Unspecified,
    modifier: Modifier = Modifier,
) {
    val heightModifier = if (maxHeight.isSpecified) Modifier.heightIn(max = maxHeight) else Modifier
    Column(
        modifier = modifier
            .fillMaxWidth()
            .then(heightModifier)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Space.sm, vertical = Space.s),
    ) {
        lines.takeLast(200).forEach { line ->
            Text(
                text = line,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                modifier = Modifier.horizontalScroll(rememberScrollState()),
            )
        }
    }
}

/**
 * The right-drawer "Debug" tab: live session state + transport controls + the full-height console.
 * Reads [dev.blamspot.jcode.workbench.LocalDebugSession] so it mirrors the Run/Debug side panel's session.
 */
@Composable
internal fun DebugConsoleSidebarContent(modifier: Modifier = Modifier) {
    val ui = dev.blamspot.jcode.workbench.LocalDebugSession.current
    val active = ui.active
    Column(modifier = modifier.fillMaxSize().padding(horizontal = Space.sm, vertical = Space.s)) {
        if (!active && ui.output.isEmpty()) {
            Text(
                "Start a debug session to see its console output here.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(Space.s),
            )
            return@Column
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
            Text(
                text = ui.debugTargetName?.let { "Debug: $it" } ?: "Debug",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
            DebugStateChip(ui.state)
        }
        if (active) DebugToolbar(ui)
        DebugConsoleLines(ui.output, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun DebugStateChip(state: DebugState) {
    val (label, active) = when (state) {
        DebugState.STARTING, DebugState.INITIALIZING -> "Starting…" to false
        DebugState.RUNNING -> "Running" to true
        DebugState.STOPPED -> "Paused" to true
        DebugState.ERROR -> "Error" to false
        else -> state.name.lowercase() to false
    }
    Surface(
        color = if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
        else MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
        shape = RoundedCornerShape(Radius.md),
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = Space.sm, vertical = Space.xs),
            style = MaterialTheme.typography.labelSmall,
            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
        )
    }
}
