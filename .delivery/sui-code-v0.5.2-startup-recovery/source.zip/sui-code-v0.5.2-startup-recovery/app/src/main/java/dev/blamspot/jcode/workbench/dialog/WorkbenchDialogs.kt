package dev.blamspot.jcode.workbench.dialog

import android.content.res.Configuration
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import dev.blamspot.jcode.design.AlertDialog
import dev.blamspot.jcode.design.CompactFilledButton
import dev.blamspot.jcode.design.CompactOutlinedButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.blamspot.jcode.ImportPhase
import dev.blamspot.jcode.ImportProgress
import dev.blamspot.jcode.MainViewModel
import dev.blamspot.jcode.design.Radius
import dev.blamspot.jcode.design.SettingsDropdownRow
import dev.blamspot.jcode.design.SettingsTextFieldRow
import dev.blamspot.jcode.design.Space
import dev.blamspot.jcode.feature.marketplace.ProjectTemplate
import dev.blamspot.jcode.feature.marketplace.TemplateInput
import kotlinx.coroutines.flow.StateFlow

@Composable
internal fun OpenFolderTypeDialog(
    folderName: String,
    onDismiss: () -> Unit,
    onConfirm: (isWorkspace: Boolean) -> Unit,
) {
    AlertDialog(onDismissRequest=onDismiss,title={Text("Open folder as Project?")},
        text={Text("$folderName\nFiles remain accessible through Internal Files without a Project. Opening as a Project adds optional tools and context.")},
        confirmButton={CompactFilledButton(text="Open Project",onClick={onConfirm(false)})},
        dismissButton={CompactOutlinedButton(text="Cancel",onClick=onDismiss)})
}

/**
 * Collects [progress] and renders [ImportProgressDialog] in its own small scope, so the per-file
 * progress ticks recompose only this host — not the large JCodeApp body that would otherwise read
 * the flow.
 */
@Composable
internal fun ImportProgressHost(progress: StateFlow<ImportProgress?>) {
    val current by progress.collectAsStateWithLifecycle()
    current?.let { ImportProgressDialog(it) }
}

/**
 * Non-dismissable modal shown while an off-ext4 folder is scanned then copied into /sources. The scan
 * phase has no known total (indeterminate bar); the copy phase reports done/total files.
 */
@Composable
internal fun ImportProgressDialog(progress: ImportProgress) {
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
    ) {
        Surface(
            shape = RoundedCornerShape(Radius.xxxl),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
        ) {
            Column(
                modifier = Modifier.widthIn(min = 280.dp, max = 360.dp).padding(Space.xl),
                verticalArrangement = Arrangement.spacedBy(Space.md),
            ) {
                Text(
                    text = if (progress.phase == ImportPhase.Scanning) "Scanning folder" else "Importing folder",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = "\"${progress.label}\"",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (progress.phase == ImportPhase.Copying && progress.total > 0) {
                    val fraction = (progress.done.toFloat() / progress.total).coerceIn(0f, 1f)
                    LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
                    Text(
                        text = "${progress.done} / ${progress.total} files",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(
                        text = "Reading contents…",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

/**
 * After cloning while a User Workspace is open: open the cloned folder as the active project, or keep it
 * added to the workspace's project list to open later.
 */
@Composable
internal fun PostCloneDialog(
    projectName: String,
    onOpen: () -> Unit,
    onAdd: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onAdd,
        title = { Text("Cloned '$projectName'") },
        text = {
            Text(
                "It was added to this workspace. Open it now, or keep it in the workspace to open later?",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        },
        confirmButton = { CompactFilledButton(text = "Open folder", onClick = onOpen) },
        dismissButton = { CompactOutlinedButton(text = "Add to workspace", onClick = onAdd) },
    )
}

@Composable
internal fun NewItemDialog(
    templates: List<ProjectTemplate>,
    installedToolchains: Set<String>,
    onDismiss: () -> Unit,
    onConfirm: (MainViewModel.NewItemRequest) -> Unit,
    /**
     * Hands the rest of the wizard to an extension's own view: (extension id, view, project name).
     *
     * For a template that declares a [ProjectTemplate.gallery] — one with variants to look at rather
     * than fields to fill — this dialog gets the name and then steps aside.
     */
    onOpenGallery: (String, String, String) -> Unit = { _, _, _ -> },
    resolveDynamicOptions: suspend (String) -> List<String> = { emptyList() },
) {
    var name by rememberSaveable { mutableStateOf("") }
    var selectedTemplateId by rememberSaveable(templates) {
        mutableStateOf(templates.firstOrNull()?.id)
    }
    // 0 = pick folder type / name / template; 1 = configure the template's inputs.
    var step by rememberSaveable { mutableStateOf(0) }

    val selectedTemplate = templates.firstOrNull { it.id == selectedTemplateId }
    val hasInputs = selectedTemplate?.inputs?.isNotEmpty() == true
    // Live values for the selected template's inputs, seeded from each input's default.
    val inputValues = remember(selectedTemplateId) {
        mutableStateMapOf<String, String>().apply {
            selectedTemplate?.inputs?.forEach { put(it.id, it.defaultValue) }
        }
    }
    // Inputs with an optionsCommand get their dropdown filled live from the runtime (e.g. installed
    // .NET SDKs); resolved async and merged over the static options, which stay the offline fallback.
    val dynamicOptions = remember(selectedTemplateId) { mutableStateMapOf<String, List<String>>() }
    LaunchedEffect(selectedTemplateId) {
        val template = selectedTemplate ?: return@LaunchedEffect
        for (input in template.inputs) {
            if (input.optionsCommand.isBlank()) continue
            val resolved = resolveDynamicOptions(input.optionsCommand)
            if (resolved.isNotEmpty()) {
                dynamicOptions[input.id] = resolved
                // Re-seed the value when the static default isn't among the live options.
                if ((inputValues[input.id] ?: "") !in resolved) inputValues[input.id] = resolved.first()
            }
        }
    }
    if (!hasInputs && step != 0) step = 0

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    // Left column: folder type + name. Right column (Project): template list; (Workspace): a hint.
    val primarySection: @Composable () -> Unit = {
        SettingsTextFieldRow(
            label = "Name",
            value = name,
            onValueChange = { name = it },
            placeholder = "Project name",
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        )
    }
    val detailSection: @Composable () -> Unit = {
        run {
            Text("Template", style = MaterialTheme.typography.labelLarge)
            templates.forEach { template ->
                TemplateOption(
                    template = template,
                    selected = template.id == selectedTemplateId,
                    installedToolchains = installedToolchains,
                    onSelect = { selectedTemplateId = template.id },
                )
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when {
                    step == 1 && selectedTemplate != null -> selectedTemplate.name
                    else -> "New Project"
                },
            )
        },
        text = {
            if (step == 1 && selectedTemplate != null) {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(Space.lg),
                ) {
                    Text(
                        "Configure this project, then create it.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    selectedTemplate.inputs.forEach { input ->
                        TemplateInputField(
                            input = input,
                            options = dynamicOptions[input.id] ?: input.options,
                            value = inputValues[input.id] ?: input.defaultValue,
                            onValue = { inputValues[input.id] = it },
                        )
                    }
                }
            } else if (isLandscape) {
                // Two columns side by side so the (tall) template list doesn't overflow the short
                // landscape dialog height.
                Row(horizontalArrangement = Arrangement.spacedBy(Space.xl)) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(Space.md),
                    ) {
                        primarySection()
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(max = 260.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(Space.sm),
                    ) {
                        detailSection()
                    }
                }
            } else {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(Space.md),
                ) {
                    primarySection()
                    detailSection()
                }
            }
        },
        confirmButton = {
            val gallery = selectedTemplate?.gallery.orEmpty()
            val handsOff = gallery.isNotBlank() && selectedTemplate?.extensionId?.isNotBlank() == true
            CompactFilledButton(
                text = if (handsOff || (step == 0 && hasInputs)) "Next" else "Create",
                onClick = {
                    if (handsOff) {
                        // The extension takes it from here: it draws the variants, asks whatever it
                        // needs and scaffolds. The name travels with the view, so nobody types it
                        // twice.
                        onOpenGallery(selectedTemplate!!.extensionId, gallery, name.trim())
                        onDismiss()
                    } else if (step == 0 && hasInputs) {
                        step = 1
                    } else {
                        onConfirm(
                            MainViewModel.NewItemRequest(
                                name = name,
                                isWorkspace = false,
                                templateId = selectedTemplateId,
                                inputs = if (hasInputs) inputValues.toMap() else emptyMap(),
                            ),
                        )
                    }
                },
                enabled = name.isNotBlank(),
            )
        },
        dismissButton = {
            CompactOutlinedButton(
                text = if (step == 1) "Back" else "Cancel",
                onClick = { if (step == 1) step = 0 else onDismiss() },
            )
        },
    )
}

@Composable
private fun TemplateInputField(
    input: TemplateInput,
    options: List<String>,
    value: String,
    onValue: (String) -> Unit,
) {
    // The settings rows rather than raw Material controls: this dialog was a filled TextField for
    // the name, an OutlinedTextField for text inputs and an OutlinedButton pretending to be a
    // dropdown, so three fields in one modal had three different shapes and none of them matched
    // the fields in Settings.
    if (input.type == "select" && options.isNotEmpty()) {
        SettingsDropdownRow(
            label = input.label,
            options = options,
            selected = value,
            onSelect = onValue,
        )
    } else {
        SettingsTextFieldRow(label = input.label, value = value, onValueChange = onValue)
    }
}

@Composable
private fun TypeOption(
    label: String,
    selected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(Radius.xl))
            .clickable(onClick = onSelect),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onSelect)
        Text(label)
    }
}

@Composable
private fun TemplateOption(
    template: ProjectTemplate,
    selected: Boolean,
    installedToolchains: Set<String>,
    onSelect: () -> Unit,
) {
    val missing = template.requires.filter { it !in installedToolchains }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Radius.xl))
            .clickable(onClick = onSelect)
            .padding(end = Space.xs),
        verticalAlignment = Alignment.Top,
    ) {
        RadioButton(selected = selected, onClick = onSelect)
        Column(modifier = Modifier.padding(top = Space.md)) {
            Text(template.name, style = MaterialTheme.typography.bodyLarge)
            if (template.description.isNotBlank()) {
                Text(
                    template.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (template.requires.isNotEmpty()) {
                val requires = "Requires: ${template.requires.joinToString(", ")}"
                Text(
                    if (missing.isEmpty()) requires
                    else "$requires — ${missing.joinToString(", ")} will be installed during setup",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (missing.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.tertiary,
                )
            }
        }
    }
}

