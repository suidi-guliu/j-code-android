package dev.blamspot.jcode.fs

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.os.FileObserver
import androidx.documentfile.provider.DocumentFile
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

@Singleton
class PosixFs @Inject constructor() : Fs {
    override suspend fun list(path: FsPath): List<FsNode> = withContext(Dispatchers.IO) {
        val file = path.requireLocal()
        // File.listFiles() returns null on a transient I/O error too — not only for a non-directory.
        // Under heavy concurrent filesystem activity (a build, a git checkout, proot teardown) a
        // perfectly readable directory can momentarily fail to list; a few short retries keep the
        // Explorer's live-refresh from mistaking that for an empty folder and blanking the tree.
        var entries = file.listFiles()
        var attempt = 0
        while (entries == null && attempt < 4 && file.isDirectory) {
            delay(50)
            entries = file.listFiles()
            attempt++
        }
        entries.orEmpty()
            .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
            .map { child ->
                FsNode(
                    path = FsPath.Local(child),
                    name = child.name,
                    kind = if (child.isDirectory && !java.nio.file.Files.isSymbolicLink(child.toPath())) FsKind.Directory else FsKind.File,
                    sizeBytes = if (child.isFile) child.length() else 0L,
                    modifiedAtMillis = child.lastModified(),
                )
            }
    }

    override suspend fun read(path: FsPath): ByteArray = withContext(Dispatchers.IO) {
        path.requireLocal().readBytes()
    }

    override suspend fun write(path: FsPath, bytes: ByteArray) = withContext(Dispatchers.IO) {
        val file = path.requireLocal()
        SafeLocalFiles.write(file, bytes)
    }

    override fun watch(path: FsPath): Flow<FsWatchEvent> = callbackFlow {
        val root = path.requireLocal()
        val observed = if (root.isDirectory) root else root.parentFile ?: root
        val observer = object : FileObserver(observed, WATCH_MASK) {
            override fun onEvent(event: Int, relativePath: String?) {
                val type = when {
                    event and (CREATE or MOVED_TO) != 0 -> FsWatchEventType.Created
                    event and (DELETE or DELETE_SELF or MOVED_FROM) != 0 -> FsWatchEventType.Deleted
                    event and (MODIFY or CLOSE_WRITE or ATTRIB) != 0 -> FsWatchEventType.Modified
                    else -> FsWatchEventType.FullRescan
                }
                trySend(FsWatchEvent(FsPath.Local(observed), relativePath, type))
            }
        }

        observer.startWatching()
        awaitClose { observer.stopWatching() }
    }.flowOn(Dispatchers.IO)

    private companion object {
        /**
         * Only the events [watch]'s `when` maps to a real change, plus `MOVE_SELF` for the watched
         * directory being renamed (the `FullRescan` fallback).
         *
         * Deliberately NOT `ALL_EVENTS`: that also delivers `ACCESS`, `OPEN` and `CLOSE_NOWRITE`,
         * which only say something was *read*, and the `when` above resolved them to `FullRescan`.
         * inotify raises all three on the watched directory itself when it is opened and read — which
         * is exactly what `File.listFiles()` does — so the Explorer's live tree fed itself: a refresh
         * listed every expanded directory, each listing raised OPEN/ACCESS/CLOSE_NOWRITE on that
         * directory, the collector's 300ms debounce fired another refresh, and round it went, roughly
         * three times a second for as long as the tree was on screen, on a tree nothing had touched.
         * Each cycle also raised `filesChanged`, which is one `evaluateJavascript` per live extension
         * host and a `git status` in the SCM extension.
         *
         * Verified against the kernel with both masks: under `ALL_EVENTS` a directory listing yields
         * OPEN|ISDIR, ACCESS|ISDIR, CLOSE_NOWRITE|ISDIR for the directory itself; under this mask it
         * yields nothing, while create still yields CREATE/MODIFY/CLOSE_WRITE, a write yields
         * MODIFY/CLOSE_WRITE and a delete yields DELETE. The bits dropped are exactly `ACCESS`,
         * `OPEN` and `CLOSE_NOWRITE` (0xFFF - 0xFCE = 0x31); no change signal is lost.
         */
        private const val WATCH_MASK = FileObserver.CREATE or FileObserver.DELETE or
            FileObserver.DELETE_SELF or FileObserver.MOVED_FROM or FileObserver.MOVED_TO or
            FileObserver.MOVE_SELF or FileObserver.MODIFY or FileObserver.CLOSE_WRITE or
            FileObserver.ATTRIB
    }
}

@Singleton
class SafFs @Inject constructor(
    @ApplicationContext private val context: Context,
) : Fs {
    override suspend fun list(path: FsPath): List<FsNode> = withContext(Dispatchers.IO) {
        val root = path.requireSafDocument(context)
        root.listFiles()
            .sortedWith(compareBy<DocumentFile>({ !it.isDirectory }, { it.name?.lowercase().orEmpty() }))
            .map { child ->
                FsNode(
                    path = FsPath.Saf(child.uri),
                    name = child.name ?: child.uri.toString(),
                    kind = if (child.isDirectory) FsKind.Directory else FsKind.File,
                    sizeBytes = child.length(),
                    modifiedAtMillis = child.lastModified(),
                )
            }
    }

    override suspend fun read(path: FsPath): ByteArray = withContext(Dispatchers.IO) {
        context.contentResolver.openInputStream(path.requireSafUri())?.use { it.readBytes() }
            ?: error("Unable to read $path")
    }

    override suspend fun write(path: FsPath, bytes: ByteArray) = withContext(Dispatchers.IO) {
        context.contentResolver.openOutputStream(path.requireSafUri(), "wt")?.use { stream ->
            stream.write(bytes)
        } ?: error("Unable to write $path")
    }

    override fun watch(path: FsPath): Flow<FsWatchEvent> = flow {
        val rootUri = path.requireSafUri()
        var previous = snapshotDirectory(rootUri)
        emit(FsWatchEvent(FsPath.Saf(rootUri), null, FsWatchEventType.FullRescan))

        while (currentCoroutineContext().isActive) {
            delay(2_000)
            val current = snapshotDirectory(rootUri)
            if (current != previous) {
                emit(FsWatchEvent(FsPath.Saf(rootUri), null, FsWatchEventType.FullRescan))
                previous = current
            }
        }
    }.flowOn(Dispatchers.IO)

    private fun snapshotDirectory(uri: Uri): List<String> {
        val root = uri.requireSafDocument(context)
        // Fast path: ONE ContentResolver query returns every child with its name/mtime/size. The old
        // DocumentFile.listFiles() + per-child .name/.lastModified()/.length() issued N+1 SAF queries,
        // and this runs on every 2s poll — an O(N) IPC storm while a SAF folder is watched. Falls back
        // to the per-child path if a provider rejects the batched query (keeps the exact snapshot shape).
        val childrenUri = runCatching {
            DocumentsContract.buildChildDocumentsUriUsingTree(
                root.uri,
                DocumentsContract.getDocumentId(root.uri),
            )
        }.getOrNull()
        if (childrenUri != null) {
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                DocumentsContract.Document.COLUMN_SIZE,
            )
            val batched = runCatching {
                buildList {
                    context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
                        while (c.moveToNext()) {
                            val name = if (c.isNull(0)) "" else c.getString(0)
                            val modified = if (c.isNull(1)) 0L else c.getLong(1)
                            val size = if (c.isNull(2)) 0L else c.getLong(2)
                            add("$name#$modified#$size")
                        }
                    }
                }
            }.getOrNull()
            if (batched != null) return batched.sorted()
        }
        return root.listFiles().map { file ->
            buildString {
                append(file.name ?: file.uri.toString())
                append('#')
                append(file.lastModified())
                append('#')
                append(file.length())
            }
        }.sorted()
    }
}

private fun FsPath.requireLocal(): File = when (this) {
    is FsPath.Local -> file
    is FsPath.Saf -> error("Expected local path but was SAF: $uri")
}

private fun FsPath.requireSafUri(): Uri = when (this) {
    is FsPath.Local -> error("Expected SAF path but was local: ${file.path}")
    is FsPath.Saf -> uri
}

private fun FsPath.requireSafDocument(context: Context): DocumentFile = requireSafUri().requireSafDocument(context)

private fun Uri.requireSafDocument(context: Context): DocumentFile {
    return DocumentFile.fromTreeUri(context, this)
        ?: DocumentFile.fromSingleUri(context, this)
        ?: error("Unable to resolve document for $this")
}
