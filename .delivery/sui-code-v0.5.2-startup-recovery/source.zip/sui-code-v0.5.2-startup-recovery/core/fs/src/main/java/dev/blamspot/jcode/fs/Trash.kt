package dev.blamspot.jcode.fs

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.documentfile.provider.DocumentFile
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

/** What put a thing in the bin, so the list can say where it came from. */
enum class TrashSource { Explorer, SourceControl }

/**
 * One thing in the bin, and everything needed to put it back.
 *
 * [parentPath] is kept as well as [originalPath] because a restore needs the *container*, and after
 * a delete the entry's own path no longer resolves to anything — for a SAF document it is not even
 * addressable, since the document id died with the document.
 */
@Immutable
data class TrashEntry(
    val id: String,
    val name: String,
    /** Where it was, for the user to read. */
    val originalPath: String,
    /** Where it goes back to: a directory path, or a SAF tree/document uri. */
    val parentPath: String,
    /** True when [parentPath] is a SAF uri rather than a local path. */
    val saf: Boolean,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val deletedAtMillis: Long,
    /** Project name plus the folder inside it, as a label — "scmtest/src". */
    val location: String,
    val source: TrashSource,
)

/** One file inside a trashed folder. */
@Immutable
data class TrashChild(val path: String, val sizeBytes: Long)

/** What a trashed folder holds, and how much of it the listing could name. */
@Immutable
data class TrashListing(val children: List<TrashChild> = emptyList(), val total: Int = 0) {
    val truncated: Boolean get() = total > children.size
}

/**
 * The app's bin: deleted files kept aside for a while instead of destroyed.
 *
 * **App-private, and one bin for every project.** Not a folder inside the project, which is the
 * other obvious place to put it: a bin under the project root is untracked content in the middle of
 * a git repository, so `git clean` — which is half of what "Discard all changes" runs — would delete
 * the very copies it had just made, and a trashed build directory would arrive in `git status` as
 * thousands of new files. Out of the tree, none of that can happen.
 *
 * Each entry is a directory of its own so that nothing has to be rewritten when one is added or
 * removed, and a half-finished delete can only ever damage its own entry:
 *
 * ```
 * <filesDir>/trash/<id>/entry.json   what it was, and where it came from
 * <filesDir>/trash/<id>/data/<name>  the thing itself
 * ```
 */
class Trash(private val root: File,private val beforeMetadataWrite: ((TrashEntry)->Unit)? = null) {

    /** Everything in the bin, newest first. Entries that lost their payload are dropped as they surface. */
    suspend fun list(): List<TrashEntry> = withContext(Dispatchers.IO) {
        root.listFiles().orEmpty()
            .filter { it.isDirectory }
            .mapNotNull { dir -> readEntry(dir) }
            .sortedByDescending { it.deletedAtMillis }
    }

    /**
     * The files inside a trashed folder, as paths relative to it.
     *
     * Capped: a trashed `node_modules` holds tens of thousands of files, and a preview that tried to
     * name all of them would spend longer listing than the delete took.
     */
    suspend fun listInside(entry: TrashEntry, limit: Int = 2_000): TrashListing =
        withContext(Dispatchers.IO) {
            val payload = payloadOf(File(root, entry.id)) ?: return@withContext TrashListing()
            if (!payload.isDirectory) return@withContext TrashListing()
            val all = payload.walkTopDown().filter { it.isFile }.iterator()
            val children = ArrayList<TrashChild>(limit.coerceAtMost(256))
            var total = 0
            while (all.hasNext()) {
                val file = all.next()
                total++
                if (children.size < limit) {
                    children += TrashChild(file.relativeTo(payload).invariantPath(), file.length())
                }
            }
            TrashListing(
                children = children.sortedBy { it.path.lowercase() },
                total = total,
            )
        }

    /**
     * The bytes of a trashed file — the entry itself, or [inside] it when the entry is a folder.
     *
     * Bounded by [maxBytes] because this exists to show someone what they are about to restore, and
     * a preview does not need the whole of a file that a phone cannot hold in one string anyway.
     */
    suspend fun read(entry: TrashEntry, inside: String? = null, maxBytes: Int = 512 * 1024): ByteArray? =
        withContext(Dispatchers.IO) {
            val payload = payloadOf(File(root, entry.id)) ?: return@withContext null
            val file = if (inside.isNullOrEmpty()) payload else File(payload, inside)
            // Refuse a path that climbs out of the entry; `inside` comes from a listing, but a
            // preview must not be the one place a "../.." would be honoured.
            if (!file.canonicalPath.startsWith(payload.canonicalPath)) return@withContext null
            if (!file.isFile) return@withContext null
            file.inputStream().use { input ->
                val buffer = ByteArray(maxBytes)
                var read = 0
                while (read < maxBytes) {
                    val n = input.read(buffer, read, maxBytes - read)
                    if (n <= 0) break
                    read += n
                }
                buffer.copyOf(read)
            }
        }

    /** Whether there is anything in the bin, without reading what. */
    suspend fun isEmpty(): Boolean = withContext(Dispatchers.IO) {
        root.listFiles().orEmpty().none { it.isDirectory }
    }

    /** What the bin is costing in storage, so the user can decide whether to care. */
    suspend fun totalBytes(): Long = withContext(Dispatchers.IO) {
        root.listFiles().orEmpty().sumOf { sizeOf(it) }
    }

    /**
     * Move something into the bin.
     *
     * [projectRoot] only shapes the label: it turns an absolute path nobody reads into the project
     * and folder the user recognises.
     */
    suspend fun put(
        context: Context?,
        path: FsPath,
        projectName: String,
        projectRoot: String?,
        source: TrashSource,
    ): TrashEntry = withContext(Dispatchers.IO) { FileMutations.mutex.withLock {
        val id = newId()
        val dir = File(root, id)
        val data = File(dir, DATA).apply { mkdirs() }
        val planned=when(path) {
            is FsPath.Local -> Taken(path.file.name,path.file.absolutePath,path.file.parentFile?.absolutePath.orEmpty(),path.file.isDirectory)
            is FsPath.Saf -> {
                val ctx=context ?: error("SAF operations require Context")
                val doc=DocumentFile.fromTreeUri(ctx,path.uri) ?: DocumentFile.fromSingleUri(ctx,path.uri) ?: error("Document is unavailable")
                Taken(doc.name ?: error("Document has no name"),path.uri.toString(),doc.parentFile?.uri?.toString() ?: error("Document has no restorable parent"),doc.isDirectory)
            }
        }
        val intent=TrashEntry(id,planned.name,planned.original,planned.parent,path is FsPath.Saf,planned.isDirectory,0,System.currentTimeMillis(),label(projectName,projectRoot,planned.parent),source)
        // Persist a complete recovery journal BEFORE the original path is changed.
        write(dir,intent)
        when(path) {
            is FsPath.Local -> takeLocal(path.file,data)
            is FsPath.Saf -> takeSaf(context ?: error("SAF operations require Context"),path.uri,data)
        }
        val entry=intent.copy(sizeBytes=sizeOf(data))
        // If the disk fills after the move, the durable intent still locates/restores the payload.
        try { write(dir,entry) } catch(_: java.io.IOException) { /* Keep valid intent and payload. */ }

        FileMutations.removed(path)
        entry
    } }

    /**
     * Put one back where it came from, and return where that turned out to be.
     *
     * A name already taken is not a reason to refuse or to overwrite — the point of a bin is that
     * nothing in it is destroyed — so the restore lands beside the occupant under a numbered name
     * and the caller says so.
     */
    suspend fun restore(context: Context, entry: TrashEntry): String = withContext(Dispatchers.IO) {
        val payload = payloadOf(File(root, entry.id)) ?: error("'${entry.name}' is no longer in the Trash")
        val landed =
            if (entry.saf) restoreSaf(context, entry, payload) else restoreLocal(entry, payload)
        SafeLocalFiles.remove(File(root, entry.id))
        if(!entry.saf) FileMutations.restored(FsPath.Local(File(entry.originalPath)),FsPath.Local(File(landed)))
        landed
    }

    /** Destroy one entry for good. */
    suspend fun purge(id: String) = withContext(Dispatchers.IO) {
        SafeLocalFiles.remove(File(root, id))
        Unit
    }

    suspend fun empty() = withContext(Dispatchers.IO) {
        root.listFiles().orEmpty().forEach { SafeLocalFiles.remove(it) }
        Unit
    }

    /**
     * Drop whatever has been in the bin longer than the user chose to keep it.
     *
     * [retentionDays] of 0 means keep everything: a bin that quietly destroys things is worse than
     * no bin, so "forever" has to be sayable.
     */
    suspend fun sweep(retentionDays: Int): Int = withContext(Dispatchers.IO) {
        if (retentionDays <= 0) return@withContext 0
        val cutoff = System.currentTimeMillis() - retentionDays * DAY_MS
        var dropped = 0
        root.listFiles().orEmpty().filter { it.isDirectory }.forEach { dir ->
            val entry = readEntry(dir)
            // Never purge an unreadable recovery journal while it still owns user payload.
            if ((entry==null && payloadOf(dir)==null) || (entry!=null && entry.deletedAtMillis<cutoff)) {
                SafeLocalFiles.remove(dir)
                dropped++
            }
        }
        dropped
    }

    // --- taking things in --------------------------------------------------------------------

    private class Taken(
        val name: String,
        val original: String,
        val parent: String,
        val isDirectory: Boolean,
    )

    private fun takeLocal(file: File, data: File): Taken {
        require(file.exists()) { "'${file.name}' no longer exists" }
        val taken = Taken(
            name = file.name,
            original = file.absolutePath,
            parent = file.parentFile?.absolutePath.orEmpty(),
            isDirectory = file.isDirectory,
        )
        val target = File(data, file.name)
        // A rename when the bin and the project share a volume, which is the normal case — projects
        // live under filesDir and so does this. It costs nothing whatever the folder weighs; the
        // copy below is the fallback for a project still on the legacy shared storage.
        if (file.renameTo(target)) return taken
        SafeLocalFiles.copy(file, data, file.name)
        SafeLocalFiles.remove(file)
        return taken
    }

    private fun takeSaf(context: Context, uri: android.net.Uri, data: File): Taken {
        val doc = DocumentFile.fromTreeUri(context, uri)
            ?: DocumentFile.fromSingleUri(context, uri)
            ?: error("Unable to resolve $uri")
        val name = doc.name ?: uri.lastPathSegment ?: "item"
        val parent = doc.parentFile?.uri?.toString().orEmpty()
        require(parent.isNotEmpty()) { "'$name' has no parent folder to restore into" }
        copySafInto(context, doc, File(data, name))
        check(doc.delete()) { "Could not remove '$name' after copying it to the Trash" }
        return Taken(name = name, original = uri.toString(), parent = parent, isDirectory = doc.isDirectory)
    }

    private fun copySafInto(context: Context, doc: DocumentFile, target: File) {
        if (doc.isDirectory) {
            target.mkdirs()
            doc.listFiles().forEach { child ->
                copySafInto(context, child, File(target, child.name ?: child.uri.lastPathSegment ?: "item"))
            }
            return
        }
        target.parentFile?.mkdirs()
        context.contentResolver.openInputStream(doc.uri)?.use { input ->
            target.outputStream().use { input.copyTo(it) }
        } ?: error("Unable to read ${doc.name}")
    }

    // --- putting things back -----------------------------------------------------------------

    private fun restoreLocal(entry: TrashEntry, payload: File): String {
        val parent = File(entry.parentPath)
        parent.mkdirs()
        val target = freeName(parent, payload.name)
        if (!payload.renameTo(target)) {
            SafeLocalFiles.copy(payload, parent, target.name)
        }
        return target.absolutePath
    }

    private fun restoreSaf(context: Context, entry: TrashEntry, payload: File): String {
        val parentUri = android.net.Uri.parse(entry.parentPath)
        val parent = DocumentFile.fromTreeUri(context, parentUri)
            ?: DocumentFile.fromSingleUri(context, parentUri)
            ?: error("The folder '${entry.name}' came from is no longer available")
        val taken = parent.listFiles().mapNotNull { it.name }.toSet()
        val name = generateSequence(0) { it + 1 }
            .map { if (it == 0) payload.name else suffixed(payload.name, it) }
            .first { it !in taken }
        writeSaf(context, parent, payload, name)
        return parent.uri.toString() + "/" + name
    }

    private fun writeSaf(context: Context, parent: DocumentFile, payload: File, name: String) {
        if (payload.isDirectory) {
            val dir = parent.createDirectory(name) ?: error("Could not recreate the folder '$name'")
            payload.listFiles().orEmpty().forEach { child -> writeSaf(context, dir, child, child.name) }
            return
        }
        val file = parent.createFile("application/octet-stream", name)
            ?: error("Could not recreate the file '$name'")
        context.contentResolver.openOutputStream(file.uri)?.use { out ->
            payload.inputStream().use { it.copyTo(out) }
        } ?: error("Could not write '$name'")
    }

    /** [name] in [parent], or the first numbered variant of it that nothing else answers to. */
    private fun freeName(parent: File, name: String): File =
        generateSequence(0) { it + 1 }
            .map { File(parent, if (it == 0) name else suffixed(name, it)) }
            .first { !it.exists() }

    /** "notes.txt" at 2 is "notes (2).txt" — the number goes before the extension, not after it. */
    private fun suffixed(name: String, n: Int): String {
        val dot = name.lastIndexOf('.')
        return if (dot <= 0) "$name ($n)" else name.substring(0, dot) + " ($n)" + name.substring(dot)
    }

    // --- the entry file ------------------------------------------------------------------------

    private fun readEntry(dir: File): TrashEntry? {
        val json = runCatching { JSONObject(File(dir, ENTRY).readText()) }.getOrNull() ?: return null
        val name = json.optString("name").ifBlank { return null }
        if (payloadOf(dir) == null) return null
        return TrashEntry(
            id = dir.name,
            name = name,
            originalPath = json.optString("originalPath"),
            parentPath = json.optString("parentPath"),
            saf = json.optBoolean("saf"),
            isDirectory = json.optBoolean("isDirectory"),
            sizeBytes = json.optLong("sizeBytes"),
            deletedAtMillis = json.optLong("deletedAtMillis"),
            location = json.optString("location"),
            source = runCatching { TrashSource.valueOf(json.optString("source")) }
                .getOrDefault(TrashSource.Explorer),
        )
    }

    private fun write(dir: File, entry: TrashEntry) {
        beforeMetadataWrite?.invoke(entry)
        SafeLocalFiles.write(File(dir,ENTRY),(
            JSONObject()
                .put("name", entry.name)
                .put("originalPath", entry.originalPath)
                .put("parentPath", entry.parentPath)
                .put("saf", entry.saf)
                .put("isDirectory", entry.isDirectory)
                .put("sizeBytes", entry.sizeBytes)
                .put("deletedAtMillis", entry.deletedAtMillis)
                .put("location", entry.location)
                .put("source", entry.source.name)
                .toString()).toByteArray(Charsets.UTF_8),
        )
    }

    /** The single child of an entry's `data/` — the thing that was deleted. */
    private fun payloadOf(dir: File): File? = File(dir, DATA).listFiles()?.firstOrNull()

    private fun sizeOf(file: File): Long {
        var bytes=0L
        java.nio.file.Files.walkFileTree(file.toPath(),object: java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
            override fun visitFile(path: java.nio.file.Path,attrs: java.nio.file.attribute.BasicFileAttributes): java.nio.file.FileVisitResult {
                if(attrs.isRegularFile) bytes+=attrs.size()
                return java.nio.file.FileVisitResult.CONTINUE
            }
        })
        return bytes
    }

    private fun label(projectName: String, projectRoot: String?, parent: String): String {
        val root = projectRoot?.trimEnd('/').orEmpty()
        val inside = when {
            root.isEmpty() -> ""
            parent == root -> ""
            parent.startsWith("$root/") -> parent.removePrefix("$root/")
            // A device-storage folder addresses itself with a content uri, which is not something to
            // show anyone; the project name alone is the honest label.
            parent.contains("://") -> ""
            else -> return parent
        }
        return if (inside.isEmpty()) projectName else "$projectName/$inside"
    }

    /** A relative path spelled the one way, whatever the platform's separator is. */
    private fun File.invariantPath(): String = path.replace(File.separatorChar, '/')

    /** Sortable and unique: the moment it was binned, plus enough randomness for the same millisecond. */
    private fun newId(): String =
        System.currentTimeMillis().toString() + "-" + java.util.UUID.randomUUID().toString().take(8)

    private companion object {
        const val ENTRY = "entry.json"
        const val DATA = "data"
        const val DAY_MS = 24L * 60 * 60 * 1000
    }
}
