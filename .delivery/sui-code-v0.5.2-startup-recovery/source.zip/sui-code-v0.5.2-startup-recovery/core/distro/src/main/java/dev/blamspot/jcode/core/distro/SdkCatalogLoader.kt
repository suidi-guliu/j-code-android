package dev.blamspot.jcode.core.distro

import android.content.Context
import java.io.InputStreamReader
import java.util.LinkedHashMap
import org.snakeyaml.engine.v2.api.Load
import org.snakeyaml.engine.v2.api.LoadSettings

internal class SdkCatalogLoader(
    context: Context,
) {
    private val appContext = context.applicationContext
    private val loader = Load(
        LoadSettings.builder()
            .setAllowDuplicateKeys(false)
            .build(),
    )

    fun load(): List<SdkCatalogEntry> {
        val document = appContext.assets.open(CATALOG_ASSET_PATH).use { stream ->
            InputStreamReader(stream).use { reader ->
                val loaded = loader.loadFromReader(reader) ?: emptyMap<String, Any?>()
                require(loaded is Map<*, *>) { "SDK catalog must start with a YAML mapping." }
                loaded.toStringKeyMap()
            }
        }

        return listOf(SdkCatalogEntry(
            id = "sui-java-ga", category = SdkCatalogCategory.Languages,
            name = "Java (latest GA · Temurin)",
            description = "Native Java environment manager. Review a verified Linux ARM64 JDK before installing alongside existing JDKs.",
            installScript = "echo 'Open the Java GA detail page to review and confirm installation.'; exit 1",
            verifyScript = "test -f /opt/sui-code/java.env && . /opt/sui-code/java.env && test -x \"\$JAVA_HOME/bin/javac\"",
            uninstallScript = "echo 'Managed JDK removal is not available in v0.1.'; exit 1",
            supportedArches = listOf("arm64"),
        )) + NativeEnvironment.entries.filter { it != NativeEnvironment.C }.map { language -> SdkCatalogEntry(
            id = language.catalogId, category = SdkCatalogCategory.Languages,
            name = "${language.title} · Native QuickRun",
            description = "Reviewed Ubuntu packages, verified runtime, safe cancellation and persistent installation logs.",
            installScript = "echo 'Open the native environment detail page to review and confirm.'; exit 1",
            verifyScript = "if [ -r /opt/sui-code/${language.key}.env ]; then . /opt/sui-code/${language.key}.env && test -x \"\${${language.variable}:-}\"; else test -x /usr/bin/${language.tool}; fi",
            uninstallScript = "echo 'Removing shared Ubuntu runtimes is intentionally unavailable here.'; exit 1",
        ) } + document.list("entries").mapIndexedNotNull { index, rawEntry ->
            val entry = (rawEntry as? Map<*, *>)?.toStringKeyMap() ?: return@mapIndexedNotNull null
            val id = entry.string("id") ?: return@mapIndexedNotNull null
            val category = SdkCatalogCategory.fromSerialized(entry.string("category"))
                ?: error("Entry '$id' has an unknown category at index $index.")
            val name = entry.string("name") ?: error("Entry '$id' is missing a name.")
            val description = entry.string("description") ?: ""
            val installScript = entry.string("installScript") ?: error("Entry '$id' is missing installScript.")
            val verifyScript = entry.string("verifyScript") ?: error("Entry '$id' is missing verifyScript.")
            val uninstallScript = entry.string("uninstallScript") ?: error("Entry '$id' is missing uninstallScript.")
            val updateCheckScript = entry.string("updateCheckScript")?.trim().orEmpty()
            SdkCatalogEntry(
                id = id,
                category = category,
                name = name,
                description = description,
                installScript = installScript.trim(),
                verifyScript = verifyScript.trim(),
                uninstallScript = uninstallScript.trim(),
                updateCheckScript = updateCheckScript,
                multiVersion = entry.bool("multiVersion") ?: false,
                versionsScript = entry.string("versionsScript")?.trim().orEmpty(),
                installedVersionsScript = entry.string("installedVersionsScript")?.trim().orEmpty(),
                useVersionScript = entry.string("useVersionScript")?.trim().orEmpty(),
                supportedDistros = entry.stringList("supportedDistros"),
                supportedArches = entry.stringList("supportedArches"),
                requiredSdks = entry.stringList("requiredSdks"),
                minInstallTimeoutMinutes = entry.int("minInstallTimeoutMinutes") ?: 0,
            )
        }
    }

    private fun Map<*, *>.toStringKeyMap(): Map<String, Any?> {
        val result = LinkedHashMap<String, Any?>()
        for ((key, value) in this) {
            result[key?.toString() ?: continue] = value
        }
        return result
    }

    private fun Map<String, Any?>.string(key: String): String? {
        return when (val value = this[key]) {
            null -> null
            is String -> value.takeIf { it.isNotBlank() }
            else -> value.toString().takeIf { it.isNotBlank() }
        }
    }

    private fun Map<String, Any?>.bool(key: String): Boolean? {
        return when (val value = this[key]) {
            null -> null
            is Boolean -> value
            is String -> value.trim().lowercase().let { if (it == "true") true else if (it == "false") false else null }
            else -> null
        }
    }

    private fun Map<String, Any?>.int(key: String): Int? = when (val value = this[key]) {
        null -> null
        is Number -> value.toInt()
        is String -> value.trim().toIntOrNull()
        else -> null
    }

    private fun Map<String, Any?>.list(key: String): List<Any?> {
        return this[key] as? List<Any?> ?: emptyList()
    }

    private fun Map<String, Any?>.stringList(key: String): List<String> {
        return when (val value = this[key]) {
            null -> emptyList()
            is List<*> -> value.mapNotNull { it?.toString()?.trim()?.takeIf(String::isNotEmpty) }
            is String -> value.split(',').mapNotNull { it.trim().takeIf(String::isNotEmpty) }
            else -> emptyList()
        }
    }

    private companion object {
        private const val CATALOG_ASSET_PATH = "distro/catalog.yaml"
    }
}
