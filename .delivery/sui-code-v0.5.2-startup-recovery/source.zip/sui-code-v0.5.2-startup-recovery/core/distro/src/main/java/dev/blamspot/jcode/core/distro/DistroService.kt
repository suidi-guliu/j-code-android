package dev.blamspot.jcode.core.distro

import android.content.Context
import android.os.StatFs
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStoreFile
import dev.blamspot.jcode.core.config.EffectiveDistroConfig
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** SharedPreferences flag: the environment finished configuring at least once (used to skip the
 *  first-run setup screen instantly on launch — see [DistroService]'s seededConfigured). */
private const val KEY_ENV_CONFIGURED = "env_configured"
private const val KEY_SELECTED_DISTRO = "selected_distro"

/**
 * Manages the embedded Linux environment using bundled proot.
 * Replaces the old Termux-dependent implementation.
 */
class DistroService(
    private val context: Context,
) {
    private val appContext = context.applicationContext

    init {
        // Anchor host<->guest path translation on the ext4 projects root. DistroService is the common
        // module every terminal/LSP/debug path translator routes through, so this runs before any of
        // them use WorkspaceHostPaths.
        WorkspaceHostPaths.init(appContext.filesDir)
    }

    private val prootManager = ProotManager(appContext)
    private val rootfsManager = RootfsManager(
        appContext,
        RootfsDownloader(tmpDir = File(appContext.filesDir, "tmp")),
    )
    @Volatile var kitInstallationActive=false
    val nativeEnvironmentManager by lazy { NativeEnvironmentManager(this) }
    val javaEnvironmentManager by lazy { JavaEnvironmentManager(this) }

    /** Java installs require the visible PTY runner, without an in-process fallback. */
    @Volatile
    var interactiveJavaRunner: (suspend (String, String, Long, String) -> ExecResult?)? = null

    private val sdkCatalogLoader = SdkCatalogLoader(appContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()
    private val sdkCheckInProgress = AtomicBoolean(false)
    private val lspCheckInProgress = AtomicBoolean(false)
    private val debugCheckInProgress = AtomicBoolean(false)
    private val activityLogLock = Any()

    // Shared daemon pool that drains each exec'd process's stdout/stderr. Reused across execs instead of
    // spawning two bare Threads per call (the old approach churned threads on the toolchain/probe paths).
    private val drainPool = Executors.newCachedThreadPool { r ->
        Thread(r, "jcode-drain").apply { isDaemon = true }
    }
    private val dataStore = PreferenceDataStoreFactory.create {
        appContext.preferencesDataStoreFile("distro-environment.preferences_pb")
    }

    // Fast, synchronous "was the environment configured last time?" flag, read on the main thread at
    // construction. Lets the UI skip the first-run setup screen instantly on launch instead of flashing
    // it for the few seconds the async probe (network manifest fetch + proot user check, run on every
    // onResume) takes to set smokeTestPassed. The probe still runs and re-verifies / self-corrects this
    // optimistic seed, so a genuinely-broken environment falls back to setup.
    private val startupPrefs = appContext.getSharedPreferences("jcode-distro-startup", Context.MODE_PRIVATE)
    private val seededConfigured: Boolean? = if (startupPrefs.getBoolean(KEY_ENV_CONFIGURED, false)) true else null

    // Which environment was active last time, read synchronously alongside [seededConfigured]. The
    // persisted selection otherwise only arrives with the async probe, and until it does
    // `runtime.selectedDistro` is the catalog default — so a terminal opened in that window spawns
    // against the WRONG rootfs and stays there for life, while the status bar later corrects itself
    // to the real selection. That is how a shell ends up reporting a different distro than the app.
    private val seededDistro: DistroProfile? =
        startupPrefs.getString(KEY_SELECTED_DISTRO, null)?.let { DistroProfile.fromId(it) }

    private val _environmentState = MutableStateFlow(
        DistroEnvironmentState(
            // proot is seeded from the same flag: the status bar reads "not installed" off
            // `!prootInstalled`, so leaving it false defeated the flash this seed exists to prevent —
            // a configured device announced a broken environment for the second or two until the
            // probe answered. Optimistic like the other two, and self-corrected by the same probe.
            prootInstalled = seededConfigured == true,
            distroInstalled = seededConfigured,
            smokeTestPassed = seededConfigured,
            runtime = seededDistro?.let { DistroRuntimeConfig(selectedDistro = it) }
                ?: DistroRuntimeConfig(),
        ),
    )
    val environmentState: StateFlow<DistroEnvironmentState> = _environmentState.asStateFlow()

    private val _sdkCatalogState = MutableStateFlow(SdkCatalogState())
    val sdkCatalogState: StateFlow<SdkCatalogState> = _sdkCatalogState.asStateFlow()

    private val _lspCatalogState = MutableStateFlow(LspCatalogState())
    val lspCatalogState: StateFlow<LspCatalogState> = _lspCatalogState.asStateFlow()

    private val _debugCatalogState = MutableStateFlow(DebugEngineCatalogState())
    val debugCatalogState: StateFlow<DebugEngineCatalogState> = _debugCatalogState.asStateFlow()

    // apt-get update is shared across the three catalog update-checks (checkSdk/Lsp/DebugEngineStatuses).
    // Refresh the package lists at most once per short window so opening the Toolchains panel — which
    // fires all three checks — runs apt-get update once instead of three times, and results appear faster.
    @Volatile
    private var lastAptRefreshMs = 0L

    private fun refreshAptListsIfStale() {
        val now = System.currentTimeMillis()
        if (now - lastAptRefreshMs > 180_000L) {
            execInDistro("sudo apt-get update", timeoutMs = 300_000L)
            lastAptRefreshMs = now
        }
    }

    private val _autoSetupProgress = MutableSharedFlow<DistroWizardProgress>(extraBufferCapacity = 64)
    val autoSetupProgress: Flow<DistroWizardProgress> = _autoSetupProgress.asSharedFlow()

    /** Installed environments ("docker-style" images) with the active one flagged. */
    private val _environments = MutableStateFlow<List<EnvironmentInfo>>(emptyList())
    val environments: StateFlow<List<EnvironmentInfo>> = _environments.asStateFlow()

    init {
        scope.launch {
            refreshEnvironment()
            refreshSdkCatalog()
            refreshLspCatalog()
            refreshDebugEngineCatalog()
        }
    }

    fun updateRuntimeConfig(
        distroConfig: EffectiveDistroConfig,
        projectHostPath: String?,
        projectTargetPath: String?,
        projectBinds: List<Pair<String, String>> = emptyList(),
    ) {
        val availableDistros = _environmentState.value.availableDistros.ifEmpty { DistroProfile.defaults() }
        // Only a config that names a specific image retargets the app. The default id is the generic
        // "ubuntu", and resolving that through fromId falls back to whatever sits FIRST in the catalog
        // — so merely opening a project re-pointed everything at 24.04 while the active environment
        // was 26.04, which is what the startup splash was announcing.
        val pinned = availableDistros.any {
            it.id == distroConfig.id || it.installRecipe == distroConfig.id
        }
        val runtime = DistroRuntimeConfig(
            selectedDistro = if (pinned && !kitInstallationActive) {
                DistroProfile.fromId(distroConfig.id, availableDistros)
            } else {
                _environmentState.value.runtime.selectedDistro
            },
            user = distroConfig.user.ifBlank { DEFAULT_DISTRO_USER },
            binds = resolveBinds(
                distroBinds = distroConfig.bind,
                projectHostPath = projectHostPath,
                projectTargetPath = projectTargetPath,
                projectBinds = projectBinds,
            ),
        )
        _environmentState.value = _environmentState.value.copy(runtime = runtime)
        scope.launch {
            syncSdkCatalogSelection(runtime.selectedDistro.id)
            syncLspCatalogSelection(runtime.selectedDistro.id)
        }
    }

    fun setSelectedDistro(profile: DistroProfile) {
        if(!applySelectedDistro(profile)) return
        scope.launch { persistSelection(profile) }
    }

    /**
     * [setSelectedDistro], but the caller can await the write. A switch that restarts the process
     * must use this: the ordinary path persists on [scope], and `exit()` would take the process down
     * before that lands, bringing the app back on the environment the user just switched away from.
     */
    suspend fun setSelectedDistroAwaitingPersist(profile: DistroProfile) {
        if(!applySelectedDistro(profile)) return
        persistSelection(profile)
    }

    private fun applySelectedDistro(profile: DistroProfile): Boolean {
        if(kitInstallationActive) {
            _environmentState.value=_environmentState.value.copy(errorMessage="An IDE Kit is installing into this Ubuntu environment. Cancel safely or wait before switching images.")
            return false
        }
        _environmentState.value = _environmentState.value.copy(
            runtime = _environmentState.value.runtime.copy(selectedDistro = profile),
            completedSteps = _environmentState.value.completedSteps + WizardStepId.DistroSelected,
            errorMessage = null,
        )
        recomputeEnvironments()
        return true
    }

    private suspend fun persistSelection(profile: DistroProfile) {
        persistSelectedDistro(profile)
        persistCompletedSteps(_environmentState.value.completedSteps)
        syncSdkCatalogSelection(profile.id)
        syncLspCatalogSelection(profile.id)
    }

    suspend fun setFirstRunSetupDeferred(deferred: Boolean) {
        persistFirstRunSetupDeferred(deferred)
        _environmentState.value = _environmentState.value.copy(firstRunSetupDeferred = deferred)
    }

    // --- Multi-environment ("docker-style") management ---

    /**
     * Create a new environment by downloading + extracting a base image. Reuses the rootfs install
     * pipeline; foreign-arch images download fine without QEMU (emulation is only needed to *run* them).
     */
    fun createEnvironment(profile: DistroProfile): Flow<InstallProgress> = flow {
        rootfsManager.installDistro(profile).collect { progress ->
            emit(progress)
        }
        refreshEnvironment()
    }

    /** The active environment's profile (id/label), for the backup filename and UI. */
    fun selectedEnvironment(): DistroProfile = _environmentState.value.runtime.selectedDistro

    /** True when the active environment has an installed rootfs that can be backed up. */
    fun selectedEnvironmentInstalled(): Boolean =
        rootfsManager.isDistroInstalled(_environmentState.value.runtime.selectedDistro.id)

    /**
     * Stream the active environment's rootfs to [out] as tar.gz (the "Back up environment" action).
     * [onProgress] reports (files, uncompressed bytes) periodically. Runs on the IO dispatcher.
     */
    suspend fun packSelectedEnvironment(
        out: java.io.OutputStream,
        onProgress: ((files: Long, bytes: Long) -> Unit)? = null,
    ): Boolean = withContext(Dispatchers.IO) {
        val id = _environmentState.value.runtime.selectedDistro.id
        if (!rootfsManager.isDistroInstalled(id)) return@withContext false
        RootfsArchiver.pack(rootfsManager.getRootfsPath(id), out, onProgress)
    }

    /**
     * Restore a tar.gz backup into the active environment's rootfs, replacing it. Reuses
     * [RootfsManager.extractRootfs] (symlinks/hard-links/exec bits), then re-derives environment
     * state so terminals pick up the restored tree. Runs on the IO dispatcher.
     */
    suspend fun restoreSelectedEnvironment(tarball: java.io.File): Boolean = withContext(Dispatchers.IO) {
        val profile = _environmentState.value.runtime.selectedDistro
        val ok = rootfsManager.extractRootfs(tarball, rootfsManager.getRootfsPath(profile.id))
        if (ok) {
            rootfsManager.writeMetadata(profile)
            verifiedDistroUsers.keys.removeAll { it.startsWith("${profile.id}:") }
            refreshEnvironment()
        }
        ok
    }

    /**
     * Extract any tar.gz this app produced into [targetDir], replacing what is there.
     *
     * The rootfs unpacker, used for archives that are not a rootfs: the projects and extensions in a
     * migration bundle are packed by the same [RootfsArchiver], so they need the same reader — it is
     * the one that understands the symlinks, hard links and exec bits those trees carry.
     */
    suspend fun extractArchive(tarball: File, targetDir: File): Boolean =
        withContext(Dispatchers.IO) { rootfsManager.extractRootfs(tarball, targetDir, isRootfs = false) }

    /** Switch the active environment that terminals and [exec] target. */
    fun setActiveEnvironment(environmentId: String) {
        setSelectedDistro(profileFor(environmentId))
        scope.launch { refreshEnvironment() }
    }

    /** [setActiveEnvironment] for a caller that restarts afterwards — see
     *  [setSelectedDistroAwaitingPersist]. Skips the refresh: the new process derives it at startup. */
    suspend fun setActiveEnvironmentAwaitingPersist(environmentId: String) {
        setSelectedDistroAwaitingPersist(profileFor(environmentId))
    }

    private fun profileFor(environmentId: String): DistroProfile {
        val available = _environmentState.value.availableDistros
        return available.firstOrNull { it.id == environmentId }
            ?: DistroProfile.fromId(environmentId, available)
    }

    /**
     * Delete an installed environment. If it was active, the most-recently-installed remaining
     * environment becomes active (or the catalog default when none remain).
     */
    suspend fun deleteEnvironment(environmentId: String): Boolean {
        val removed = rootfsManager.removeDistro(environmentId)
        verifiedDistroUsers.keys.removeAll { it.startsWith("$environmentId:") }
        rootfsConfigured.remove(environmentId)
        dataStore.edit { prefs ->
            prefs.remove(installedEntriesKey(environmentId))
            prefs.remove(installedLspEntriesKey(environmentId))
            prefs.remove(installedDebugEntriesKey(environmentId))
        }
        if (_environmentState.value.runtime.selectedDistro.id == environmentId) {
            val available = _environmentState.value.availableDistros
            val next = rootfsManager.getInstalledDistros()
                .filter { it.id != environmentId }
                .maxByOrNull { it.installDate }
            val nextProfile = next?.let { inst -> available.firstOrNull { it.id == inst.id } }
                ?: available.firstOrNull()
                ?: DistroProfile.defaultProfile()
            setSelectedDistro(nextProfile)
        }
        refreshEnvironment()
        return removed
    }

    suspend fun refreshSdkCatalog() = withContext(Dispatchers.IO) {
        lock.withLock {
            val entries = runCatching { sdkCatalogLoader.load() }
                .getOrElse { error ->
                    _sdkCatalogState.value = _sdkCatalogState.value.copy(
                        entries = emptyList(),
                        installedEntryIds = emptySet(),
                        runningEntryId = null,
                        runningAction = null,
                        executionLabel = null,
                        selectedDistroId = _environmentState.value.runtime.selectedDistro.id,
                        errorMessage = "Failed to load SDK catalog: ${error.message ?: "Unknown error"}",
                    )
                    return@withContext
                }

            val distroId = _environmentState.value.runtime.selectedDistro.id
            _sdkCatalogState.value = _sdkCatalogState.value.copy(
                entries = entries,
                installedEntryIds = readInstalledCatalogEntries(distroId),
                runningEntryId = null,
                runningAction = null,
                selectedDistroId = distroId,
                errorMessage = null,
            )
        }
    }

    suspend fun runSdkCatalogAction(
        entryId: String,
        action: SdkCatalogAction,
        version: String? = null,
    ) {
        lock.withLock {
            val entry = _sdkCatalogState.value.entries.firstOrNull { it.id == entryId }
            if (entry == null) {
                _sdkCatalogState.value = _sdkCatalogState.value.copy(
                    errorMessage = "Unknown SDK catalog entry '$entryId'.",
                )
                return
            }

            if (_environmentState.value.distroInstalled != true || _environmentState.value.jcodeUserReady != true) {
                _sdkCatalogState.value = _sdkCatalogState.value.copy(
                    errorMessage = "Complete the environment setup before running SDK catalog actions.",
                )
                return
            }

            val selectedDistro = _environmentState.value.runtime.selectedDistro
            if (!entry.isSupportedOn(selectedDistro.id, selectedDistro.arch)) {
                _sdkCatalogState.value = _sdkCatalogState.value.copy(
                    errorMessage = "${entry.name} is not available on ${selectedDistro.label}.",
                )
                return
            }

            val distroId = selectedDistro.id
            _sdkCatalogState.value = _sdkCatalogState.value.copy(
                runningEntryId = entry.id,
                runningAction = action,
                executionLabel = "${action.label} ${entry.name}",
                selectedDistroId = distroId,
                errorMessage = null,
                logLines = appendCatalogLogLines(
                    existing = _sdkCatalogState.value.logLines,
                    lines = buildList {
                        val versionSuffix = version?.let { " [$it]" }.orEmpty()
                        add("== ${action.label} ${entry.name}$versionSuffix (${_environmentState.value.runtime.selectedDistro.label}) ==")
                        addAll(applyVersion(entry.scriptFor(action), version).lineSequence().map { line -> "$ $line" })
                    },
                ),
            )

            val actionResult = when (action) {
                SdkCatalogAction.Install -> execCatalogAction(
                    "${action.label} ${entry.name}",
                    applyVersion(entry.installScript, version),
                    timeoutMs = entry.installTimeoutMs(catalogInstallTimeoutMs),
                )
                SdkCatalogAction.Uninstall -> execCatalogAction("${action.label} ${entry.name}", applyVersion(entry.uninstallScript, version), timeoutMs = 900_000L)
                // Repointing a symlink or an alternatives entry — nothing to download.
                SdkCatalogAction.Use -> execCatalogAction("${action.label} ${entry.name}", applyVersion(entry.useVersionScript, version), timeoutMs = 120_000L)
            }
            // The install/uninstall script's own exit status is not trusted — the verify script is
            // what decides whether the tool is actually there afterwards.
            val verifyResult = execCatalogScript(entry.verifyScript, timeoutMs = 120_000L)

            invalidateCatalogProbes()
            val installedNow = verifyResult.succeeded
            val updatedInstalledEntries = readInstalledCatalogEntries(distroId).toMutableSet().apply {
                if (installedNow) {
                    add(entry.id)
                } else {
                    remove(entry.id)
                }
            }.toSet()
            persistInstalledCatalogEntries(distroId, updatedInstalledEntries)

            val versioned = entry.versionsScript.isNotBlank()
            val refreshed = if (versioned) readInstalledVersionsForEntry(entry) else null
            val refreshedInstalledVersions = if (refreshed != null) {
                _sdkCatalogState.value.installedVersions.toMutableMap()
                    .apply { put(entry.id, refreshed.versions) }
            } else {
                _sdkCatalogState.value.installedVersions
            }
            val refreshedActiveVersions = if (refreshed != null) {
                _sdkCatalogState.value.activeVersions.toMutableMap()
                    .apply { refreshed.active?.also { put(entry.id, it) } ?: remove(entry.id) }
            } else {
                _sdkCatalogState.value.activeVersions
            }

            val errorMessage = when {
                !actionResult.succeeded && !installedNow -> actionResult.internalError
                    ?: actionResult.stderr.lineSequence().firstOrNull { it.isNotBlank() }
                    ?: actionResult.stdout.lineSequence().firstOrNull { it.isNotBlank() }
                    ?: "${action.label} failed."

                action == SdkCatalogAction.Install && !installedNow ->
                    "Install finished, but verification did not detect ${entry.name}."

                action == SdkCatalogAction.Uninstall && installedNow ->
                    "Removal finished, but verification still detects ${entry.name}."

                else -> null
            }

            _sdkCatalogState.value = _sdkCatalogState.value.copy(
                installedEntryIds = updatedInstalledEntries,
                installedVersions = refreshedInstalledVersions,
                activeVersions = refreshedActiveVersions,
                runningEntryId = null,
                runningAction = null,
                executionLabel = "${action.label} ${entry.name}",
                selectedDistroId = distroId,
                errorMessage = errorMessage,
                logLines = appendCatalogLogLines(
                    existing = _sdkCatalogState.value.logLines,
                    lines = formatActionLogs(
                        entry = entry,
                        action = action,
                        actionResult = actionResult,
                        verifyResult = verifyResult,
                        installedNow = installedNow,
                    ),
                ),
            )
        }
    }

    /**
     * Populate [SdkCatalogState.availableVersions] / [SdkCatalogState.installedVersions] for a versioned
     * entry (one whose [SdkCatalogEntry.versionsScript] is set). Called lazily when a detail page opens.
     * Sets [SdkCatalogState.versionsLoadingEntryId] up-front so the picker can show a spinner, then runs
     * the (possibly network-bound) listing scripts under [lock] to serialize against installs. Cached:
     * a second open is a no-op unless [force] is set.
     */
    suspend fun fetchCatalogVersions(entryId: String, force: Boolean = false) {
        val entry = _sdkCatalogState.value.entries.firstOrNull { it.id == entryId } ?: return
        if (entry.versionsScript.isBlank()) return
        if (_environmentState.value.distroInstalled != true || _environmentState.value.jcodeUserReady != true) return
        if (!force && _sdkCatalogState.value.availableVersions[entryId]?.isNotEmpty() == true) return

        _sdkCatalogState.value = _sdkCatalogState.value.copy(versionsLoadingEntryId = entryId)
        lock.withLock {
            val availableResult = execCatalogScript(entry.versionsScript, timeoutMs = 180_000L)
            val available = if (availableResult.succeeded) parseVersionOptions(availableResult.stdout) else emptyList()
            val installed = readInstalledVersionsForEntry(entry)
            _sdkCatalogState.value = _sdkCatalogState.value.copy(
                availableVersions = _sdkCatalogState.value.availableVersions.toMutableMap()
                    .apply { if (available.isNotEmpty()) put(entryId, available) },
                installedVersions = _sdkCatalogState.value.installedVersions.toMutableMap()
                    .apply { put(entryId, installed.versions) },
                activeVersions = _sdkCatalogState.value.activeVersions.toMutableMap()
                    .apply { installed.active?.also { put(entryId, it) } ?: remove(entryId) },
                // Compare-and-clear: only drop the spinner if this entry is still the one loading — a
                // slower concurrent fetch for another entry must keep its own spinner.
                versionsLoadingEntryId = _sdkCatalogState.value.versionsLoadingEntryId.takeIf { it != entryId },
                errorMessage = if (available.isEmpty()) {
                    "Couldn't list installable versions for ${entry.name}."
                } else {
                    _sdkCatalogState.value.errorMessage
                },
            )
        }
    }

    suspend fun refreshLspCatalog() = withContext(Dispatchers.IO) {
        lock.withLock {
            val distroId = _environmentState.value.runtime.selectedDistro.id
            _lspCatalogState.value = _lspCatalogState.value.copy(
                entries = lspCatalogEntries(),
                installedEntryIds = readInstalledLspEntries(distroId),
                loaded = true,
                runningEntryId = null,
                runningAction = null,
                selectedDistroId = distroId,
                errorMessage = null,
            )
        }
    }

    suspend fun runLspCatalogAction(
        entryId: String,
        action: LspCatalogAction,
    ) {
        lock.withLock {
            val entry = LspServerCatalog.findById(entryId)
            if (entry == null) {
                _lspCatalogState.value = _lspCatalogState.value.copy(
                    errorMessage = "Unknown language server '$entryId'.",
                )
                return
            }

            if (_environmentState.value.distroInstalled != true || _environmentState.value.jcodeUserReady != true) {
                _lspCatalogState.value = _lspCatalogState.value.copy(
                    errorMessage = "Complete the environment setup before installing language servers.",
                )
                return
            }

            val distroId = _environmentState.value.runtime.selectedDistro.id
            val name = entry.name
            _lspCatalogState.value = _lspCatalogState.value.copy(
                runningEntryId = entry.id,
                runningAction = action,
                executionLabel = "${action.label} $name",
                selectedDistroId = distroId,
                errorMessage = null,
                logLines = appendCatalogLogLines(
                    existing = _lspCatalogState.value.logLines,
                    lines = buildList {
                        add("== ${action.label} $name (${_environmentState.value.runtime.selectedDistro.label}) ==")
                        addAll(entry.commandFor(action).lineSequence().map { line -> "$ $line" })
                    },
                ),
            )

            val actionResult = when (action) {
                LspCatalogAction.Install -> execCatalogAction("${action.label} ${entry.name}", entry.installCommand, timeoutMs = catalogInstallTimeoutMs)
                LspCatalogAction.Uninstall -> execCatalogAction("${action.label} ${entry.name}", entry.uninstallCommand, timeoutMs = 900_000L)
            }
            // The install/uninstall command's own exit status is not trusted — the verify command
            // is what decides whether the tool is actually there afterwards.
            val verifyResult = execCatalogScript(entry.verifyCommand, timeoutMs = 120_000L)

            invalidateCatalogProbes()
            val installedNow = verifyResult.succeeded
            val updatedInstalledEntries = readInstalledLspEntries(distroId).toMutableSet().apply {
                if (installedNow) {
                    add(entry.id)
                } else {
                    remove(entry.id)
                }
            }.toSet()
            persistInstalledLspEntries(distroId, updatedInstalledEntries)

            val errorMessage = when {
                !actionResult.succeeded && !installedNow -> actionResult.internalError
                    ?: actionResult.stderr.lineSequence().firstOrNull { it.isNotBlank() }
                    ?: actionResult.stdout.lineSequence().firstOrNull { it.isNotBlank() }
                    ?: "${action.label} failed."

                action == LspCatalogAction.Install && !installedNow ->
                    "Install finished, but verification did not detect $name."

                action == LspCatalogAction.Uninstall && installedNow ->
                    "Removal finished, but verification still detects $name."

                else -> null
            }

            _lspCatalogState.value = _lspCatalogState.value.copy(
                installedEntryIds = updatedInstalledEntries,
                runningEntryId = null,
                runningAction = null,
                executionLabel = "${action.label} $name",
                selectedDistroId = distroId,
                errorMessage = errorMessage,
                logLines = appendCatalogLogLines(
                    existing = _lspCatalogState.value.logLines,
                    lines = formatLspActionLogs(
                        name = name,
                        action = action,
                        actionResult = actionResult,
                        verifyResult = verifyResult,
                        installedNow = installedNow,
                    ),
                ),
            )
        }
    }

    private data class CatalogProbe(val id: String, val verifyScript: String, val updateCheckScript: String)

    /** Cached installed-state checks only. Never refresh package indexes on page navigation. */
    fun invalidateCatalogProbes() { probeResults.clear() }
    private val probeResults=java.util.concurrent.ConcurrentHashMap<String,Pair<Long,Pair<Set<String>,Set<String>>>>()
    private suspend fun runCatalogProbes(probes: List<CatalogProbe>): Pair<Set<String>,Set<String>> = withContext(Dispatchers.IO) {
        if(probes.isEmpty()) return@withContext emptySet<String>() to emptySet<String>()
        val runtime=_environmentState.value.runtime
        val key=runtime.selectedDistro.id+":"+probes.joinToString("\u0000") { it.id+":"+it.verifyScript }
        val now=android.os.SystemClock.elapsedRealtime()
        probeResults[key]?.takeIf { now-it.first<60_000L }?.let { return@withContext it.second }
        android.os.Trace.beginSection("sui.catalog.probes")
        try {
            val script=CatalogProbeBatch.script(probes.map { CatalogProbeBatch.Probe(it.id,it.verifyScript) })
            val result=execOwned(script,workdir=runtime.workdir,owner="sui-kit:core-catalog",timeoutMs=(probes.size*9_000L).coerceAtMost(45_000L))
            kotlinx.coroutines.currentCoroutineContext().ensureActive()
            val parsed=CatalogProbeBatch.parse(result.stdout)
            val previousInstalled=_sdkCatalogState.value.installedEntryIds+_lspCatalogState.value.installedEntryIds+_debugCatalogState.value.installedEntryIds
            val previousUpdatable=_sdkCatalogState.value.updatableEntryIds+_lspCatalogState.value.updatableEntryIds+_debugCatalogState.value.updatableEntryIds
            val ids=probes.map { it.id }.toSet()
            val value=(parsed.installed+(previousInstalled.intersect(ids)-parsed.checked)) to previousUpdatable.intersect(ids)
            if(parsed.checked.size==probes.size) probeResults[key]=android.os.SystemClock.elapsedRealtime() to value
            android.util.Log.i("SuiPerformance","catalog=${runtime.selectedDistro.id} count=${probes.size} ms=${android.os.SystemClock.elapsedRealtime()-now} thread=${Thread.currentThread().name} checked=${parsed.checked.size} timedOut=${parsed.timedOut.size}")
            value
        } finally { android.os.Trace.endSection() }
    }

    suspend fun checkAvailableCatalogUpdates() = withContext(Dispatchers.IO) {
        lock.withLock {
            check(isRuntimeReady()) { "Complete Ubuntu setup before checking updates" }
            refreshAptListsIfStale()
            suspend fun updates(probes: List<CatalogProbe>): Set<String> {
                val available=probes.filter { it.updateCheckScript.isNotBlank() }
                if(available.isEmpty()) return emptySet()
                val result=execOwned(CatalogProbeBatch.script(available.map { CatalogProbeBatch.Probe(it.id,it.updateCheckScript) },seconds=8),"/tmp","sui-kit:catalog-updates",60000)
                return CatalogProbeBatch.parse(result.stdout).installed
            }
            val sdk=_sdkCatalogState.value
            _sdkCatalogState.value=sdk.copy(updatableEntryIds=updates(sdk.entries.filter { it.id in sdk.installedEntryIds }.map { CatalogProbe(it.id,it.verifyScript,it.updateCheckScript) }))
            val lsp=_lspCatalogState.value
            _lspCatalogState.value=lsp.copy(updatableEntryIds=updates(lsp.entries.filter { it.id in lsp.installedEntryIds }.map { CatalogProbe(it.id,it.verifyCommand,it.updateCheckCommand) }))
            val debug=_debugCatalogState.value
            _debugCatalogState.value=debug.copy(updatableEntryIds=updates(debug.entries.filter { it.id in debug.installedEntryIds }.map { CatalogProbe(it.id,it.verifyCommand,it.updateCheckCommand) }))
            invalidateCatalogProbes()
        }
    }

    /** Re-check installed + update-available status for every SDK entry. Full check, run async; no-op if already running. */
    suspend fun checkSdkStatuses() = withContext(Dispatchers.IO) {
        val ready = _environmentState.value.distroInstalled == true && _environmentState.value.jcodeUserReady == true
        if (!ready) return@withContext
        if (!sdkCheckInProgress.compareAndSet(false, true)) return@withContext
        try {
            lock.withLock {
                val distroId = _environmentState.value.runtime.selectedDistro.id
                val entries = _sdkCatalogState.value.entries.ifEmpty {
                    runCatching { sdkCatalogLoader.load() }.getOrElse { emptyList() }
                }
                if (entries.isEmpty()) return@withContext
                _sdkCatalogState.value = _sdkCatalogState.value.copy(
                    entries = entries, checking = true, selectedDistroId = distroId, errorMessage = null,
                )
                val (installed, updatable) = runCatalogProbes(
                    entries.map { CatalogProbe(it.id, it.verifyScript, it.updateCheckScript) },
                )
                persistInstalledCatalogEntries(distroId, installed)
                _sdkCatalogState.value = _sdkCatalogState.value.copy(
                    installedEntryIds = installed, updatableEntryIds = updatable,
                    checking = false, selectedDistroId = distroId,
                )
            }
        } finally {
            _sdkCatalogState.value = _sdkCatalogState.value.copy(checking = false)
            sdkCheckInProgress.set(false)
        }
    }

    /** Re-check installed + update-available status for every LSP server. Full check, run async; no-op if already running. */
    suspend fun checkLspStatuses() = withContext(Dispatchers.IO) {
        val ready = _environmentState.value.distroInstalled == true && _environmentState.value.jcodeUserReady == true
        if (!ready) return@withContext
        if (!lspCheckInProgress.compareAndSet(false, true)) return@withContext
        try {
            lock.withLock {
                val distroId = _environmentState.value.runtime.selectedDistro.id
                val entries = LspServerCatalog.BUILT_IN
                _lspCatalogState.value = _lspCatalogState.value.copy(
                    entries = entries, checking = true, selectedDistroId = distroId, errorMessage = null,
                )
                val (installed, updatable) = runCatalogProbes(
                    entries.map { CatalogProbe(it.id, it.verifyCommand, it.updateCheckCommand) },
                )
                persistInstalledLspEntries(distroId, installed)
                _lspCatalogState.value = _lspCatalogState.value.copy(
                    installedEntryIds = installed, updatableEntryIds = updatable,
                    checking = false, selectedDistroId = distroId,
                )
            }
        } finally {
            _lspCatalogState.value = _lspCatalogState.value.copy(checking = false)
            lspCheckInProgress.set(false)
        }
    }

    suspend fun refreshDebugEngineCatalog() = withContext(Dispatchers.IO) {
        lock.withLock {
            val distroId = _environmentState.value.runtime.selectedDistro.id
            _debugCatalogState.value = _debugCatalogState.value.copy(
                entries = DebugEngineCatalog.all,
                installedEntryIds = readInstalledDebugEntries(distroId),
                runningEntryId = null,
                runningAction = null,
                selectedDistroId = distroId,
                errorMessage = null,
            )
        }
    }

    suspend fun runDebugEngineCatalogAction(
        entryId: String,
        action: DebugEngineAction,
    ) {
        lock.withLock {
            val entry = DebugEngineCatalog.findById(entryId)
            if (entry == null) {
                _debugCatalogState.value = _debugCatalogState.value.copy(
                    errorMessage = "Unknown debug engine '$entryId'.",
                )
                return
            }

            if (_environmentState.value.distroInstalled != true || _environmentState.value.jcodeUserReady != true) {
                _debugCatalogState.value = _debugCatalogState.value.copy(
                    errorMessage = "Complete the environment setup before installing debug engines.",
                )
                return
            }

            val distroId = _environmentState.value.runtime.selectedDistro.id
            val name = entry.name
            _debugCatalogState.value = _debugCatalogState.value.copy(
                runningEntryId = entry.id,
                runningAction = action,
                executionLabel = "${action.label} $name",
                selectedDistroId = distroId,
                errorMessage = null,
                logLines = appendCatalogLogLines(
                    existing = _debugCatalogState.value.logLines,
                    lines = buildList {
                        add("== ${action.label} $name (${_environmentState.value.runtime.selectedDistro.label}) ==")
                        addAll(entry.commandFor(action).lineSequence().map { line -> "$ $line" })
                    },
                ),
            )

            val actionResult = when (action) {
                DebugEngineAction.Install -> execCatalogAction("${action.label} ${entry.name}", entry.installCommand, timeoutMs = catalogInstallTimeoutMs)
                DebugEngineAction.Uninstall -> execCatalogAction("${action.label} ${entry.name}", entry.uninstallCommand, timeoutMs = 900_000L)
            }
            // The install/uninstall command's own exit status is not trusted — the verify command
            // is what decides whether the tool is actually there afterwards.
            val verifyResult = execCatalogScript(entry.verifyCommand, timeoutMs = 120_000L)

            invalidateCatalogProbes()
            val installedNow = verifyResult.succeeded
            val updatedInstalledEntries = readInstalledDebugEntries(distroId).toMutableSet().apply {
                if (installedNow) add(entry.id) else remove(entry.id)
            }.toSet()
            persistInstalledDebugEntries(distroId, updatedInstalledEntries)

            val errorMessage = when {
                !actionResult.succeeded && !installedNow -> actionResult.internalError
                    ?: actionResult.stderr.lineSequence().firstOrNull { it.isNotBlank() }
                    ?: actionResult.stdout.lineSequence().firstOrNull { it.isNotBlank() }
                    ?: "${action.label} failed."

                action == DebugEngineAction.Install && !installedNow ->
                    "Install finished, but verification did not detect $name."

                action == DebugEngineAction.Uninstall && installedNow ->
                    "Removal finished, but verification still detects $name."

                else -> null
            }

            _debugCatalogState.value = _debugCatalogState.value.copy(
                installedEntryIds = updatedInstalledEntries,
                runningEntryId = null,
                runningAction = null,
                executionLabel = "${action.label} $name",
                selectedDistroId = distroId,
                errorMessage = errorMessage,
                logLines = appendCatalogLogLines(
                    existing = _debugCatalogState.value.logLines,
                    lines = formatDebugActionLogs(
                        name = name,
                        action = action,
                        actionResult = actionResult,
                        verifyResult = verifyResult,
                        installedNow = installedNow,
                    ),
                ),
            )
        }
    }

    /** Re-check installed + update-available status for every debug engine. Full check, run async; no-op if already running. */
    suspend fun checkDebugEngineStatuses() = withContext(Dispatchers.IO) {
        val ready = _environmentState.value.distroInstalled == true && _environmentState.value.jcodeUserReady == true
        if (!ready) return@withContext
        if (!debugCheckInProgress.compareAndSet(false, true)) return@withContext
        try {
            lock.withLock {
                val distroId = _environmentState.value.runtime.selectedDistro.id
                val entries = DebugEngineCatalog.all
                _debugCatalogState.value = _debugCatalogState.value.copy(
                    entries = entries, checking = true, selectedDistroId = distroId, errorMessage = null,
                )
                val (installed, updatable) = runCatalogProbes(
                    entries.map { CatalogProbe(it.id, it.verifyCommand, it.updateCheckCommand) },
                )
                persistInstalledDebugEntries(distroId, installed)
                _debugCatalogState.value = _debugCatalogState.value.copy(
                    installedEntryIds = installed, updatableEntryIds = updatable,
                    checking = false, selectedDistroId = distroId,
                )
            }
        } finally {
            _debugCatalogState.value = _debugCatalogState.value.copy(checking = false)
            debugCheckInProgress.set(false)
        }
    }

    suspend fun refreshEnvironment() {
        lock.withLock {
            refreshEnvironmentInternal()
        }
    }

    /**
     * Internal refresh logic WITHOUT acquiring the lock.
     * Callers must ensure the lock is already held.
     */
    private suspend fun refreshEnvironmentInternal() {
        // Bring up the SELECTED environment from local state first — the persisted id and the rootfs
        // on disk. fetchManifest() is a network round-trip that only feeds the list of images
        // available to INSTALL, so leading with it made every start wait on the network before so
        // much as looking at the distro it was about to run, with the splash held up behind it.
        val knownDistros = _environmentState.value.availableDistros.ifEmpty { DistroProfile.defaults() }
        readSelectedDistro(knownDistros)?.let { persisted ->
            _environmentState.value = _environmentState.value.copy(
                runtime = _environmentState.value.runtime.copy(selectedDistro = persisted),
            )
        }
        // No fallback to the first catalog entry: an unreadable selection means "keep what is
        // running", never "silently retarget to whatever sits on top of the list".
        deriveSelectedDistroState()

        // Now the installable catalog, off the startup path. It never re-points the selection: an id
        // absent from the manifest still names a rootfs that is on disk and possibly active.
        val availableDistros = rootfsManager.downloader.fetchManifest().profiles()
            .ifEmpty { knownDistros }
        _environmentState.value = _environmentState.value.copy(availableDistros = availableDistros)
    }

    /**
     * Re-derive all per-distro environment state for the CURRENTLY selected distro, probing disk/proot.
     * [DistroEnvironmentState.completedSteps] is rebuilt from scratch (never seeded from the persisted set)
     * so switching to a different — or not-yet-installed — distro never inherits the previous distro's
     * completion, and the per-distro readiness flags are cleared when the distro isn't installed. Uses the
     * in-memory selection only (no persisted re-read), so it is safe to call straight after
     * [setSelectedDistro] without racing the async persist — which is why [runAllPendingSteps] calls it
     * before computing pending steps.
     */
    private suspend fun deriveSelectedDistroState() {
        val storedSetupDeferred = readFirstRunSetupDeferred()
        val completedSteps = mutableSetOf<WizardStepId>()

        val prootInstalled = prootManager.isProotInstalled
        if (prootInstalled) {
            completedSteps += WizardStepId.ProotReady
        }

        // A distro is always selected (default is Ubuntu).
        completedSteps += WizardStepId.DistroSelected

        val hasEnoughStorage = checkStorageSpace()
        if (hasEnoughStorage) {
            completedSteps += WizardStepId.CheckStorage
        }

        val distroId = _environmentState.value.runtime.selectedDistro.id
        val distroInstalled = rootfsManager.isDistroInstalled(distroId)
        if (distroInstalled) {
            completedSteps += WizardStepId.DistroInstalled

            val workspaceReady = primaryBind().hostFile.exists()
            if (workspaceReady) {
                completedSteps += WizardStepId.WorkspaceReady
            }

            val jcodeUserReady = checkDistroUser()
            if (jcodeUserReady == true) {
                completedSteps += WizardStepId.JcodeUserCreated
                // Refreshing package lists and installing Node are best-effort and idempotent; treat
                // them as done once the user is ready so they run only during the fresh first-run pass
                // (when the distro isn't installed at derive time) and never re-run on later
                // "Use"/refresh triggers — an environment set up before Node was part of setup should
                // not start a multi-minute install the next time it is selected.
                completedSteps += WizardStepId.AptUpdated
                completedSteps += WizardStepId.NodeInstalled
            }

            val toolchainReady = checkToolchainReady()
            if (toolchainReady == true) {
                completedSteps += WizardStepId.ToolchainBootstrapped
            }

            var smokeTestPassed: Boolean? = null
            if (jcodeUserReady == true && toolchainReady == true && workspaceReady) {
                smokeTestPassed = checkSmokeTest()
                if (smokeTestPassed == true) {
                    completedSteps += WizardStepId.SmokeTest
                }
            }

            _environmentState.value = _environmentState.value.copy(
                prootInstalled = prootInstalled,
                distroInstalled = distroInstalled,
                workspaceReady = workspaceReady,
                toolchainReady = toolchainReady,
                jcodeUserReady = jcodeUserReady,
                smokeTestPassed = smokeTestPassed,
                firstRunSetupDeferred = storedSetupDeferred,
                completedSteps = completedSteps.toSet(),
                errorMessage = null,
            )
        } else {
            // Not installed: clear any readiness carried over from a previously selected distro.
            _environmentState.value = _environmentState.value.copy(
                prootInstalled = prootInstalled,
                distroInstalled = distroInstalled,
                workspaceReady = false,
                toolchainReady = null,
                jcodeUserReady = null,
                smokeTestPassed = null,
                firstRunSetupDeferred = storedSetupDeferred,
                completedSteps = completedSteps.toSet(),
                errorMessage = null,
            )
        }

        // Remember (fast, synchronous) whether the environment is configured, so the next launch can skip
        // the first-run setup screen without waiting for this async probe to re-run.
        startupPrefs.edit()
            .putBoolean(KEY_ENV_CONFIGURED, _environmentState.value.smokeTestPassed == true)
            .putString(KEY_SELECTED_DISTRO, _environmentState.value.runtime.selectedDistro.id)
            .apply()
        persistCompletedSteps(completedSteps.toSet())
        syncSdkCatalogSelection(_environmentState.value.runtime.selectedDistro.id)
        syncLspCatalogSelection(_environmentState.value.runtime.selectedDistro.id)
        recomputeEnvironments()
    }

    /** Recompute the installed-environments list from disk + the active selection. */
    private fun recomputeEnvironments() {
        val activeId = _environmentState.value.runtime.selectedDistro.id
        val available = _environmentState.value.availableDistros
        _environments.value = rootfsManager.getInstalledDistros().map { installed ->
            val profile = available.firstOrNull { it.id == installed.id }
            val arch = profile?.arch ?: rootfsManager.readMetadataArch(installed.id) ?: Arch.ARM64
            EnvironmentInfo(
                id = installed.id,
                label = profile?.label ?: installed.id,
                arch = arch,
                installedAt = installed.installDate,
                isActive = installed.id == activeId,
            )
        }.sortedByDescending { it.installedAt }
    }

    @Suppress("UNUSED_PARAMETER")
    suspend fun runWizardStep(
        stepId: WizardStepId,
        callerContext: Context = appContext,
    ) {
        lock.withLock {
            updateRunningStep(stepId, "Running ${stepId.key}.")
            val result = when (stepId) {
                WizardStepId.CheckStorage -> checkStorageStep()
                WizardStepId.ProotReady -> ensureProotStep()
                WizardStepId.DistroSelected -> ExecResult(stdout = "Distro selected.", exitCode = 0)
                WizardStepId.DistroInstalled -> installSelectedDistro(onLine = ::appendActivityLogLine)
                WizardStepId.WorkspaceReady -> ensureWorkspaceDirectory()
                WizardStepId.ToolchainBootstrapped -> bootstrapToolchain(onLine = ::appendActivityLogLine)
                WizardStepId.JcodeUserCreated -> createDistroUser(onLine = ::appendActivityLogLine)
                WizardStepId.AptUpdated -> aptUpdateStep(onLine = ::appendActivityLogLine)
                WizardStepId.NodeInstalled -> installNodeStep(onLine = ::appendActivityLogLine)
                WizardStepId.SmokeTest -> smokeTest(onLine = ::appendActivityLogLine)
            }

            val logLine = buildString {
                append(stepId.key)
                append(": ")
                append(
                    result.internalError
                        ?: result.stdout.ifBlank { result.stderr.ifBlank { "Completed with exit ${result.exitCode ?: "?"}." } }
                            .lineSequence()
                            .firstOrNull()
                            .orEmpty(),
                )
            }

            val stepSucceeded = result.succeeded
            val updatedCompletedSteps = if (stepSucceeded) {
                _environmentState.value.completedSteps + stepId
            } else {
                _environmentState.value.completedSteps
            }
            val nextLog = (_environmentState.value.activityLog + logLine).takeLast(SETUP_ACTIVITY_LOG_LIMIT)
            _environmentState.value = _environmentState.value.copy(
                runningStep = null,
                completedSteps = updatedCompletedSteps,
                activityLog = nextLog,
                errorMessage = result.internalError,
            )
            if (stepSucceeded) {
                persistCompletedSteps(updatedCompletedSteps)
            }
        }
        refreshEnvironmentInternal()
    }

    /**
     * Run all pending wizard steps in sequence, emitting progress over [autoSetupProgress].
     */
    @Suppress("UNUSED_PARAMETER")
    suspend fun runAllPendingSteps(callerContext: Context = appContext) {
        lock.withLock {
            // Re-derive completion for the currently selected distro first, so a freshly selected (and
            // possibly not-yet-installed) distro is not treated as "already set up" from another distro's
            // state. Without this, selecting a second distro and tapping "Use" would no-op.
            deriveSelectedDistroState()
            val state = _environmentState.value

            val pendingSteps = WizardStepId.entries.filter { step ->
                step !in state.completedSteps
            }

            if (pendingSteps.isEmpty()) {
                _autoSetupProgress.tryEmit(DistroWizardProgress.AllDone(
                    totalSteps = WizardStepId.entries.size,
                    completedSteps = state.completedSteps.size,
                    summary = "All environment steps are already complete.",
                ))
                return
            }

            val totalSteps = pendingSteps.size
            var completedCount = 0

            for (step in pendingSteps) {
                _autoSetupProgress.tryEmit(DistroWizardProgress.Running(step, stepLabel(step)))
                updateRunningStep(step, stepLabel(step))

                val result = when (step) {
                    WizardStepId.CheckStorage -> checkStorageStep()
                    WizardStepId.ProotReady -> ensureProotStep()
                    WizardStepId.DistroSelected -> ExecResult(stdout = "Distro selected.", exitCode = 0)
                    WizardStepId.DistroInstalled -> installSelectedDistro(
                        onLine = ::appendActivityLogLine,
                        onDownloadProgress = { percent, detail ->
                            _autoSetupProgress.tryEmit(
                                DistroWizardProgress.Running(step, stepLabel(step), percent, detail),
                            )
                        },
                    )
                    WizardStepId.WorkspaceReady -> ensureWorkspaceDirectory()
                    WizardStepId.ToolchainBootstrapped -> bootstrapToolchain(onLine = ::appendActivityLogLine)
                    WizardStepId.JcodeUserCreated -> createDistroUser(onLine = ::appendActivityLogLine)
                    WizardStepId.AptUpdated -> aptUpdateStep(onLine = ::appendActivityLogLine)
                    WizardStepId.NodeInstalled -> installNodeStep(
                        onLine = ::appendActivityLogLine,
                        onProgress = { percent, detail ->
                            _autoSetupProgress.tryEmit(
                                DistroWizardProgress.Running(step, stepLabel(step), percent, detail),
                            )
                        },
                    )
                    WizardStepId.SmokeTest -> smokeTest(onLine = ::appendActivityLogLine)
                }

                val logLine = buildString {
                    append(step.key)
                    append(": ")
                    append(
                        result.internalError
                            ?: result.stdout.ifBlank { result.stderr.ifBlank { "Completed with exit ${result.exitCode ?: "?"}." } }
                                .lineSequence()
                                .firstOrNull()
                                .orEmpty(),
                    )
                }

                if (result.succeeded) {
                    _autoSetupProgress.tryEmit(DistroWizardProgress.Completed(
                        step,
                        result.stdout.ifBlank { "OK" }.lineSequence().firstOrNull().orEmpty(),
                    ))
                    completedCount++
                    val updatedCompletedSteps = _environmentState.value.completedSteps + step
                    val nextLog = (_environmentState.value.activityLog + logLine).takeLast(SETUP_ACTIVITY_LOG_LIMIT)
                    _environmentState.value = _environmentState.value.copy(
                        runningStep = null,
                        completedSteps = updatedCompletedSteps,
                        activityLog = nextLog,
                        errorMessage = null,
                    )
                    persistCompletedSteps(updatedCompletedSteps)
                } else {
                    val error = result.internalError
                        ?: result.stderr.ifBlank { result.stdout }.lineSequence().firstOrNull { it.isNotBlank() }
                        ?: "Step failed with exit ${result.exitCode ?: "?"}."
                    if (step in BEST_EFFORT_STEPS) {
                        // Best-effort steps (refreshing package lists) must never block setup: log it,
                        // mark it done so we don't loop on it, and carry on. A stale package list just
                        // means the first `apt-get install` will refresh itself.
                        _autoSetupProgress.tryEmit(DistroWizardProgress.Completed(step, "Skipped: $error"))
                        val updatedCompletedSteps = _environmentState.value.completedSteps + step
                        val nextLog = (_environmentState.value.activityLog + logLine).takeLast(SETUP_ACTIVITY_LOG_LIMIT)
                        _environmentState.value = _environmentState.value.copy(
                            runningStep = null,
                            completedSteps = updatedCompletedSteps,
                            activityLog = nextLog,
                            errorMessage = null,
                        )
                        persistCompletedSteps(updatedCompletedSteps)
                        continue
                    }
                    _autoSetupProgress.tryEmit(DistroWizardProgress.Failed(step, error))
                    val nextLog = (_environmentState.value.activityLog + logLine).takeLast(SETUP_ACTIVITY_LOG_LIMIT)
                    _environmentState.value = _environmentState.value.copy(
                        runningStep = null,
                        activityLog = nextLog,
                        errorMessage = error,
                    )
                    refreshEnvironmentInternal()
                    return
                }
            }

            refreshEnvironmentInternal()

            // Mark first-run setup as NOT deferred to prevent re-triggering
            // even if the state check functions can't verify everything (e.g., no proot)
            persistFirstRunSetupDeferred(false)
            _environmentState.value = _environmentState.value.copy(firstRunSetupDeferred = false)

            _autoSetupProgress.tryEmit(DistroWizardProgress.AllDone(
                totalSteps = totalSteps,
                completedSteps = completedCount,
                summary = "Setup complete: $completedCount/$totalSteps steps succeeded.",
            ))
        }
    }

    private fun stepLabel(step: WizardStepId): String = when (step) {
        WizardStepId.CheckStorage -> "Check storage space"
        WizardStepId.ProotReady -> "Extract proot binary"
        WizardStepId.DistroSelected -> "Select distro"
        WizardStepId.DistroInstalled -> "Install ${_environmentState.value.runtime.selectedDistro.label}"
        WizardStepId.WorkspaceReady -> "Create workspace directory"
        WizardStepId.ToolchainBootstrapped -> "Skip bootstrap (use SDK Manager for tools)"
        WizardStepId.JcodeUserCreated -> "Create jcode user"
        WizardStepId.AptUpdated -> "Refresh package lists"
        WizardStepId.NodeInstalled -> "Install Node.js (LTS)"
        WizardStepId.SmokeTest -> "Run smoke test"
    }

    fun install(profile: DistroProfile = _environmentState.value.runtime.selectedDistro): Flow<DistroEvent> = flow {
        emit(DistroEvent(stage = "install", message = "Installing ${profile.label}."))
        val result = installSelectedDistro(profile)
        emit(DistroEvent(stage = "install", message = summarizeResult(result), result = result))
    }

    fun bootstrap(
        profile: DistroProfile = _environmentState.value.runtime.selectedDistro,
        packages: List<String> = DEFAULT_BOOTSTRAP_PACKAGES,
        user: String = _environmentState.value.runtime.user,
    ): Flow<DistroEvent> = flow {
        emit(DistroEvent(stage = "bootstrap", message = "Bootstrapping ${profile.label} as $user."))
        val result = bootstrapToolchain(packages = packages)
        emit(DistroEvent(stage = "bootstrap", message = summarizeResult(result), result = result))
    }

    suspend fun exec(
        command: String,
        workdir: String = _environmentState.value.runtime.workdir,
        env: Map<String, String> = emptyMap(),
        timeoutMs: Long = 60_000L,
        onLine: ((String) -> Unit)? = null,
        user: String = _environmentState.value.runtime.user,
        raw: Boolean = false,
    ): ExecResult = withContext(Dispatchers.IO) {
        // The bridge (extension WebView) invokes this on its caller's thread; the proot round-trip
        // (ProcessBuilder + waitFor) blocks, so it must run on the IO dispatcher, never the main thread.
        execInDistro(
            command = command,
            workdir = workdir,
            env = env,
            timeoutMs = timeoutMs,
            onLine = onLine,
            user = user,
            raw = raw,
        )
    }

    /** Cancellable preparation for a reviewed Kit; never used for apt/dpkg installation. */
    suspend fun execOwned(command: String,workdir: String,owner: String,timeoutMs: Long=300_000L): ExecResult = withContext(Dispatchers.IO) {
        require(owner.startsWith("sui-kit:"))
        val process=spawnStdioProcess(command,workdir=workdir,owner=owner) ?: return@withContext ExecResult(internalError="Cannot start Kit preparation",exitCode=1)
        val stdout=StringBuffer();val stderr=StringBuffer()
        fun drain(input: java.io.InputStream,target: StringBuffer)=Thread {
            runCatching { input.bufferedReader().useLines { lines -> lines.forEach { line -> synchronized(target) { if(target.length<2*1024*1024) target.append(line).append('\n') } } } }
        }.apply { isDaemon=true;start() }
        val out=drain(process.inputStream,stdout);val err=drain(process.errorStream,stderr)
        try {
            val completed=kotlinx.coroutines.withTimeoutOrNull(timeoutMs) { while(process.isAlive) kotlinx.coroutines.delay(50);true } ?: false
            if(completed) { out.join(1000);err.join(1000) }
            ExecResult(stdout=stdout.toString(),stderr=stderr.toString(),exitCode=if(completed) process.exitValue() else 124,internalError=if(completed) null else "Kit preparation timed out")
        } finally {
            withContext(kotlinx.coroutines.NonCancellable+Dispatchers.IO) {
                GuestProcessTree.destroyBlocking(process)
                runCatching { process.inputStream.close() };runCatching { process.errorStream.close() };runCatching { process.outputStream.close() }
            }
        }
    }

    /** Whether the runtime is installed and the jcode user is ready (scaffold readiness gate). */
    fun isRuntimeReady(): Boolean {
        val state = _environmentState.value
        return state.distroInstalled == true && state.jcodeUserReady == true
    }

    /** Host directory of the active distro's rootfs. Lets the app read guest files directly (the rootfs
     *  is on app-private ext4) — e.g. a guest `/usr/share/fonts/...` path is `File(activeRootfsPath(),
     *  "usr/share/fonts/...")`. */
    fun activeRootfsPath(): File = rootfsManager.getRootfsPath(_environmentState.value.runtime.selectedDistro.id)

    // --- Private implementation methods ---

    private fun checkStorageStep(): ExecResult {
        return if (checkStorageSpace()) {
            ExecResult(stdout = "Sufficient storage available.", exitCode = 0)
        } else {
            ExecResult(internalError = "Insufficient storage. Need at least 2GB free.", exitCode = 1)
        }
    }

    private suspend fun ensureProotStep(): ExecResult {
        android.util.Log.d("DistroService", "ensureProotStep: checking proot installation...")
        val installed = prootManager.ensureProotInstalled()
        android.util.Log.d("DistroService", "ensureProotStep: proot installed=$installed")
        return if (installed) {
            ExecResult(stdout = "proot binary ready.", exitCode = 0)
        } else {
            // Non-blocking: proot binary not yet compiled. Continue setup.
            android.util.Log.w("DistroService", "ensureProotStep: proot not available, continuing anyway")
            ExecResult(stdout = "proot binary not available (will be compiled later). Continuing...", exitCode = 0)
        }
    }

    private fun checkStorageSpace(): Boolean {
        return try {
            val stat = StatFs(appContext.filesDir.absolutePath)
            val availableBytes = stat.availableBlocksLong * stat.blockSizeLong
            val availableGb = availableBytes / (1024.0 * 1024.0 * 1024.0)
            android.util.Log.d("DistroService", "checkStorageSpace: available=${"%.2f".format(availableGb)}GB, required=2GB")
            availableBytes >= MIN_REQUIRED_STORAGE_BYTES
        } catch (e: Exception) {
            android.util.Log.w("DistroService", "checkStorageSpace: failed to check, assuming OK: ${e.message}")
            true // Assume OK if we can't check
        }
    }

    // When armed (by an onboarding "restore from backup" action), the DistroInstalled step restores the
    // rootfs from this local tarball instead of downloading — so the rest of the pipeline (proot, jcode
    // user, smoke test) still runs and yields a working environment. Cleared after one use.
    @Volatile private var pendingRestoreTarball: File? = null

    /** Arm the next install run to restore from [tarball] instead of downloading. Pass null to clear. */
    fun setPendingRestoreTarball(tarball: File?) { pendingRestoreTarball = tarball }

    private fun installSelectedDistro(
        profile: DistroProfile = _environmentState.value.runtime.selectedDistro,
        onLine: ((String) -> Unit)? = null,
        onDownloadProgress: ((percent: Int?, detail: String) -> Unit)? = null,
    ): ExecResult {
        return try {
            val restore = pendingRestoreTarball
            if (restore != null) {
                pendingRestoreTarball = null
                onLine?.invoke("Restoring ${profile.label} from backup (${"%.1f".format(restore.length() / (1024f * 1024f))} MiB)…")
                onDownloadProgress?.invoke(null, "Restoring from backup…")
                val rootfsDir = rootfsManager.getRootfsPath(profile.id)
                val ok = rootfsManager.extractRootfs(restore, rootfsDir)
                restore.delete()
                if (!ok) return ExecResult(internalError = "Failed to restore rootfs for ${profile.label}", exitCode = 1)
                rootfsManager.writeMetadata(profile)
                onLine?.invoke("Restored rootfs at ${rootfsDir.absolutePath}.")
                return ExecResult(stdout = "${profile.label} restored from backup", exitCode = 0)
            }
            android.util.Log.d("DistroService", "installSelectedDistro: checking for ${profile.id}")
            if (rootfsManager.isDistroInstalled(profile.id)) {
                android.util.Log.d("DistroService", "installSelectedDistro: ${profile.label} already installed")
                onLine?.invoke("${profile.label} already installed.")
                return ExecResult(stdout = "${profile.label} already installed.", exitCode = 0)
            }

            // Download rootfs synchronously for auto-setup
            android.util.Log.d("DistroService", "installSelectedDistro: downloading rootfs for ${profile.label}...")
            onLine?.invoke("Downloading ${profile.label} rootfs...")
            val manifest = kotlinx.coroutines.runBlocking { rootfsManager.downloader.fetchManifest() }
            val entry = manifest.findByDistroId(profile.id)
            if (entry == null) {
                return ExecResult(internalError = "No rootfs image found for ${profile.label}", exitCode = 1)
            }
            // Use the file extension from the URL to preserve compression format
            val urlExt = entry.url.substringAfterLast('.').let { ext ->
                if (ext in listOf("xz", "gz", "bz2")) ".tar.$ext" else ".tar.gz"
            }
            val tarball = File(rootfsManager.tmpDir, "${profile.id}$urlExt")
            // Synchronous download for auto-setup (blocks the wizard but gives immediate feedback)
            var lastLoggedQuarter = -1
            val downloadOk = rootfsManager.downloadDirect(entry, tarball) { percent, detail ->
                onDownloadProgress?.invoke(percent, detail)
                val quarter = (percent ?: 0) / 25
                if (percent != null && quarter != lastLoggedQuarter) {
                    lastLoggedQuarter = quarter
                    onLine?.invoke("Downloading ${profile.label} rootfs: $percent% ($detail)")
                }
            }
            android.util.Log.d("DistroService", "installSelectedDistro: download result=$downloadOk, fileSize=${tarball.length()}")
            if (!downloadOk) {
                return ExecResult(internalError = "Failed to download rootfs for ${profile.label}", exitCode = 1)
            }
            onLine?.invoke("Downloaded ${"%.1f".format(tarball.length() / (1024f * 1024f))} MiB rootfs archive.")

            android.util.Log.d("DistroService", "installSelectedDistro: extracting rootfs...")
            onLine?.invoke("Extracting rootfs...")
            val rootfsDir = rootfsManager.getRootfsPath(profile.id)
            val extractOk = rootfsManager.extractRootfs(tarball, rootfsDir)
            android.util.Log.d("DistroService", "installSelectedDistro: extract result=$extractOk")
            tarball.delete()
            if (!extractOk) {
                return ExecResult(internalError = "Failed to extract rootfs for ${profile.label}", exitCode = 1)
            }
            rootfsManager.writeMetadata(profile)
            onLine?.invoke("Rootfs ready at ${rootfsDir.absolutePath}.")
            ExecResult(stdout = "${profile.label} installed at ${rootfsDir.absolutePath}", exitCode = 0)
        } catch (e: Exception) {
            android.util.Log.e("DistroService", "installSelectedDistro: exception", e)
            ExecResult(internalError = e.message ?: "Installation failed.", exitCode = 1)
        }
    }

    private fun ensureWorkspaceDirectory(): ExecResult {
        val bind = primaryBind()
        val created = bind.hostFile.mkdirs() || bind.hostFile.exists()
        return if (created) {
            ExecResult(stdout = "Workspace ready at ${bind.host}.", exitCode = 0)
        } else {
            ExecResult(internalError = "Failed to create ${bind.host}.", exitCode = 1)
        }
    }

    private fun bootstrapToolchain(
        packages: List<String> = DEFAULT_BOOTSTRAP_PACKAGES,
        onLine: ((String) -> Unit)? = null,
    ): ExecResult {
        // Skip on-device bootstrap: proot apt-get is too slow (10+ min for 3 packages).
        // Users install toolchains via SDK Manager or terminal as needed.
        onLine?.invoke("Bootstrap skipped. Install toolchains via SDK Manager or terminal.")
        return ExecResult(stdout = "Bootstrap skipped (use SDK Manager for toolchains).", exitCode = 0)
    }

    private fun createDistroUser(onLine: ((String) -> Unit)? = null): ExecResult {
        val runtime = _environmentState.value.runtime
        return ensureDistroUser(runtime.selectedDistro.id, runtime.user, onLine)
    }

    /** (distroId:user) pairs verified to exist in the rootfs, so execs don't re-check every time. */
    private val verifiedDistroUsers = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    /**
     * Whether [user]'s bootstrap is already present in [distroId]'s rootfs, judged from the rootfs
     * itself rather than from a remembered verdict.
     *
     * [ensureDistroUser] costs ~12s under proot and was the whole of a cold start, re-proving every
     * launch what the last one had established. But everything it writes is a plain file in
     * app-private storage, so the same question answers from a few stats — and unlike a persisted
     * flag this reads the CURRENT state, so deleting the account inside the distro makes the next
     * launch rebuild it. That self-healing is the property the check was built around.
     */
    private fun distroUserBootstrapped(distroId: String, user: String): Boolean {
        val rootfs = rootfsManager.getRootfsPath(distroId)
        if (!rootfs.isDirectory) return false
        val registered = runCatching {
            File(rootfs, "etc/passwd").useLines { lines -> lines.any { it.startsWith("$user:") } }
        }.getOrDefault(false)
        if (!registered) return false
        if (!File(rootfs, "home/$user").isDirectory) return false
        if (!File(rootfs, "etc/sudoers.d/$user").isFile) return false
        // Either a real sudo or the shim ensureDistroUser drops in for minimal images.
        return File(rootfs, "usr/bin/sudo").exists() || File(rootfs, "usr/local/bin/sudo").exists()
    }

    /** distroIds whose rootfs config (DNS, locale) has been ensured this process, so it runs at most once each. */
    private val rootfsConfigured = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    /** Last failed ensure per (distroId:user): a broken rootfs must not re-run the script on every refresh. */
    private val distroUserEnsureFailures = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /**
     * Idempotently make sure [user] exists inside [distroId]'s rootfs (useradd silently fails under
     * proot on some rootfs images, so fall back to writing the account records directly), has
     * passwordless sudo, and that a sudo binary is present — minimal images (cdimage ubuntu-base)
     * ship none, so install a shim that mimics sudo's argument handling (env assignments, -u, --)
     * and defers to /usr/bin/sudo once a real one is installed. Verified with `id -u` at the end —
     * failure here is a real failure, not swallowed.
     */
    private fun ensureDistroUser(distroId: String, user: String, onLine: ((String) -> Unit)? = null): ExecResult {
        if (!prootManager.isProotInstalled) {
            return ExecResult(stdout = "proot not available - skipping user creation.", exitCode = 0)
        }
        val cacheKey = "$distroId:$user"
        if (verifiedDistroUsers[cacheKey] == true) {
            return ExecResult(stdout = "user $user ready.", exitCode = 0)
        }
        if (distroUserBootstrapped(distroId, user)) {
            verifiedDistroUsers[cacheKey] = true
            return ExecResult(stdout = "user $user ready.", exitCode = 0)
        }
        val lastFailure = distroUserEnsureFailures[cacheKey]
        if (lastFailure != null && System.currentTimeMillis() - lastFailure < ENSURE_USER_RETRY_MS) {
            return ExecResult(internalError = "user '$user' could not be created in $distroId (retrying later).", exitCode = 1)
        }
        val d = "${'$'}"
        // Written on one printf line (no % or backslash in the body) so no heredoc-indentation
        // pitfalls. Runs as root (proot fake-root): passes commands through, exports leading
        // VAR=val, and honours `-u <user>` by su-ing to that account (e.g. postgres refuses root).
        val sudoShim = "#!/bin/sh\\n" +
            "[ -x /usr/bin/sudo ] && exec /usr/bin/sudo \"${d}@\"\\n" +
            "u=\\n" +
            "while [ ${d}# -gt 0 ]; do case \"${d}1\" in " +
            "-u|--user) u=${d}2; shift 2 ;; " +
            "--) shift; break ;; " +
            "[A-Za-z_]*=*) export \"${d}1\"; shift ;; " +
            "-*) shift ;; " +
            "*) break ;; esac; done\\n" +
            "[ -n \"${d}u\" ] && [ \"${d}u\" != root ] && exec su - \"${d}u\" -c \"${d}*\"\\n" +
            "exec \"${d}@\"\\n"
        val command = """
            if id -u $user >/dev/null 2>&1; then
                echo "user $user already exists"
            else
                /usr/sbin/useradd -m -u 1000 -s /bin/bash $user 2>/dev/null || true
                if ! id -u $user >/dev/null 2>&1; then
                    echo "$user:x:1000:1000:$user:/home/$user:/bin/bash" >> /etc/passwd
                    echo "$user:x:1000:" >> /etc/group
                    echo "$user::19000:0:99999:7:::" >> /etc/shadow 2>/dev/null || true
                    echo "manually registered $user"
                fi
            fi
            mkdir -p /home/$user
            chown -R 1000:1000 /home/$user 2>/dev/null || true
            /usr/bin/passwd -d $user >/dev/null 2>&1 || true
            /usr/bin/passwd -d root >/dev/null 2>&1 || true
            /usr/bin/install -d /etc/sudoers.d
            /usr/bin/printf '%s ALL=(ALL) NOPASSWD:ALL\n' $user > /etc/sudoers.d/$user
            /usr/bin/chmod 440 /etc/sudoers.d/$user
            if [ ! -x /usr/bin/sudo ]; then
                /usr/bin/printf '$sudoShim' > /usr/local/bin/sudo
                /usr/bin/chmod 755 /usr/local/bin/sudo
                echo "installed sudo shim"
            fi
            if id -u $user >/dev/null 2>&1; then echo OK; else echo "failed to create user $user"; exit 1; fi
        """.trimIndent()
        val result = execInDistro(command = command, timeoutMs = 300_000L, onLine = onLine, user = "root")
        if (result.succeeded) {
            distroUserEnsureFailures.remove(cacheKey)
            // Only cache when the world still matches what we verified: the rootfs must still be
            // there and the selection unchanged (a mid-flight environment switch or delete would
            // otherwise pin a stale "verified" entry and defeat the self-heal).
            if (rootfsManager.isDistroInstalled(distroId) &&
                _environmentState.value.runtime.selectedDistro.id == distroId
            ) {
                verifiedDistroUsers[cacheKey] = true
            }
        } else {
            distroUserEnsureFailures[cacheKey] = System.currentTimeMillis()
        }
        return result
    }

    private fun smokeTest(onLine: ((String) -> Unit)? = null): ExecResult {
        // Skip smoke test: minimal rootfs has limited tools, and proot execution is verified by other steps.
        onLine?.invoke("Smoke test skipped (rootfs verified by other steps).")
        return ExecResult(stdout = "Smoke test skipped.", exitCode = 0)
    }

    private fun checkToolchainReady(): Boolean? {
        // Rootfs always has sh; no bootstrap required
        return true
    }

    private fun checkDistroUser(): Boolean? {
        // Self-healing check: verify the user actually exists in the rootfs (a fresh rootfs, or one
        // where useradd silently failed under proot, won't have it) and create it when missing.
        // Cached per (distro, user), so this execs at most once per process for a healthy rootfs.
        val runtime = _environmentState.value.runtime
        if (!prootManager.isProotInstalled) return null
        if (verifiedDistroUsers["${runtime.selectedDistro.id}:${runtime.user}"] == true) return true
        return ensureDistroUser(runtime.selectedDistro.id, runtime.user).succeeded
    }

    private fun checkSmokeTest(): Boolean? {
        // Smoke test is skipped during onboarding; rootfs is verified by other steps.
        return true
    }

    /**
     * Run a toolchain catalog script (install/verify/uninstall) privileged. proot's fake-root only
     * covers uid 0, and `su - jcode` drops to uid 1000 where apt/dpkg refuse to run — so these
     * scripts run as root, but with HOME/USER pointed at the jcode user so toolchains install into
     * /home/jcode and remain usable from the (non-root) terminal. The scripts' own `sudo` prefixes
     * become a passthrough via the shim installed by [ensureDistroUser].
     */
    private fun execCatalogScript(
        script: String,
        timeoutMs: Long,
        onLine: ((String) -> Unit)? = null,
    ): ExecResult {
        val runtime = _environmentState.value.runtime
        // Root execs skip the su-guard, so make sure the jcode home + sudo shim exist first.
        val ensure = ensureDistroUser(runtime.selectedDistro.id, runtime.user)
        if (!ensure.succeeded) return ensure
        return execInDistro(
            command = script,
            timeoutMs = timeoutMs,
            user = "root",
            env = mapOf("HOME" to "/home/${runtime.user}", "USER" to runtime.user),
            onLine = onLine,
        )
    }

    /**
     * App-provided runner that executes a catalog install/uninstall inside the shared Setup terminal
     * (visible in the right drawer) instead of a silent in-process exec. Returns null to decline
     * (e.g. no session slot free), in which case the action falls back to [execCatalogScript].
     * Scripts run with the same semantics either way: root, with HOME/USER pointing at the jcode user.
     *
     * The runner reports the script's own `jcode_progress` calls back through `onProgress`.
     */
    @Volatile
    var interactiveCatalogRunner:
        (suspend (label: String, script: String, timeoutMs: Long, onProgress: (Int, String) -> Unit) -> ExecResult?)? = null

    /**
     * Stage [content] at [guestPath] inside the selected distro by writing it straight into the
     * rootfs on the host, returning true on success.
     *
     * The alternative — typing the content into a shell — goes through a PTY line discipline, which
     * buffers a few KB, caps a single line's length, and echoes everything back. That is fine for a
     * command but not for a script: the Setup terminal used to heredoc whole toolchain scripts in
     * (the Android SDK one is ~9 KB) and the tail was lost. The rootfs is app-private storage, so
     * the host can just write the file.
     */
    fun stageGuestFile(guestPath: String, content: String): Boolean = stageGuestBytes(guestPath,content.toByteArray(Charsets.UTF_8))

    fun stageGuestBytes(guestPath: String,content: ByteArray): Boolean = runCatching {
        val distroId=_environmentState.value.runtime.selectedDistro.id
        if(!rootfsManager.isDistroInstalled(distroId) || '\u0000' in guestPath) return false
        val root=rootfsManager.getRootfsPath(distroId).canonicalFile
        val target=File(root,guestPath.trimStart('/')).canonicalFile
        check(target.toPath().startsWith(root.toPath()) && target!=root) { "Invalid guest staging path" }
        val parent=target.parentFile ?: error("Missing staging parent")
        check(parent.isDirectory || parent.mkdirs())
        val temp=java.nio.file.Files.createTempFile(parent.toPath(),".sui-stage-",".tmp")
        try {
            java.io.FileOutputStream(temp.toFile()).use { it.write(content);it.fd.sync() }
            temp.toFile().setReadable(true,false)
            java.nio.file.Files.move(temp,target.toPath(),java.nio.file.StandardCopyOption.ATOMIC_MOVE,java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        } finally { java.nio.file.Files.deleteIfExists(temp) }
        true
    }.getOrDefault(false)

    private val _catalogProgress = MutableStateFlow<CatalogProgress?>(null)

    /** Percentage + phase of the running install/uninstall, or null when nothing is running (or the
     *  running script reports no progress). Shared by the SDK / LSP / debug-engine manager pages. */
    val catalogProgress: StateFlow<CatalogProgress?> = _catalogProgress.asStateFlow()

    /** Timeout (ms) for a catalog INSTALL action (SDK/LSP/debugger), set from the "Toolchain install
     *  timeout" setting. Verify/uninstall keep their own fixed budgets. Default is the pre-setting
     *  30-minute value; large SDKs on a slow connection may need more. */
    @Volatile
    var catalogInstallTimeoutMs: Long = 1_800_000L

    /** Long-running catalog actions go through the Setup terminal when wired; verify stays quiet so
     *  its exit code and output remain capturable.
     *
     *  Self-healing: a failed install is retried up to [CATALOG_INSTALL_MAX_ATTEMPTS] times with a
     *  linear back-off. The back-off rides out a transient network/mirror blip, and each attempt
     *  re-runs the apt self-heal preamble (dpkg reconfigure + fix-broken) so a half-installed state
     *  from the previous attempt is cleaned before retrying. Hard-stops that can't heal by re-running
     *  — a missing runtime ([ExecResult.internalError]) or a user cancel (SIGINT, exit 130) — break
     *  out immediately. Retries carry a "retry N/M" label so they're visible in the Setup terminal. */
    private suspend fun execCatalogAction(
        label: String,
        script: String,
        timeoutMs: Long,
        onProgress: ((Int, String) -> Unit)? = null,
        onLine: ((String) -> Unit)? = null,
    ): ExecResult {
        val prepared = withCatalogHelpers(withAptSelfHeal(script))
        var last: ExecResult? = null
        try {
            for (attempt in 1..CATALOG_INSTALL_MAX_ATTEMPTS) {
                val attemptLabel =
                    if (attempt == 1) label else "$label — retry $attempt/$CATALOG_INSTALL_MAX_ATTEMPTS"
                // Each attempt restarts the script from the top, so its progress restarts too.
                _catalogProgress.value = null
                val result = runCatalogOnce(attemptLabel, prepared, timeoutMs, onProgress, onLine)
                if (result.succeeded) return result
                last = result
                val healable = result.internalError == null && result.exitCode != 130
                if (!healable || attempt == CATALOG_INSTALL_MAX_ATTEMPTS) break
                delay(CATALOG_RETRY_BACKOFF_MS * attempt)
            }
        } finally {
            _catalogProgress.value = null
        }
        return last ?: ExecResult(exitCode = 1)
    }

    /** One catalog-action attempt: prefer the visible Setup terminal, fall back to a quiet in-process
     *  exec. [prepared] already carries the apt self-heal + progress-helper preambles. */
    private suspend fun runCatalogOnce(
        label: String,
        prepared: String,
        timeoutMs: Long,
        onProgress: ((Int, String) -> Unit)? = null,
        onLine: ((String) -> Unit)? = null,
    ): ExecResult {
        val runner = interactiveCatalogRunner
        if (runner != null) {
            val runtime = _environmentState.value.runtime
            val ensure = ensureDistroUser(runtime.selectedDistro.id, runtime.user)
            if (!ensure.succeeded) return ensure
            val reportProgress: (Int, String) -> Unit = { percent, phase ->
                _catalogProgress.value = CatalogProgress(percent.coerceIn(0, 100), phase)
                onProgress?.invoke(percent.coerceIn(0, 100), phase)
            }
            runner(label, prepared, timeoutMs, reportProgress)?.let { return it }
        }
        // Quiet fallback: no PTY, so the OSC markers go nowhere and the catalog UI stays indeterminate.
        // A caller that passed [onLine] still sees the script's own output, progress lines included.
        return execCatalogScript(prepared, timeoutMs, onLine)
    }

    /**
     * Prepend the shell helpers every catalog install/uninstall may call.
     *
     * `jcode_progress <percent> <label>` reports how far the script has got: an OSC 7716 marker the
     * Setup terminal turns into a determinate progress bar, plus a plain `[ 42%] …` line so the
     * progress is readable in the terminal itself. `jcode_fetch <url> <dest> <from> <to> <label>`
     * downloads a file and reports true byte-level progress across the [from,to] slice of the bar —
     * curl's own meter is a carriage-return animation no percentage can be recovered from once it
     * has been through a PTY. `jcode_apt <from> <to> <label> <packages…>` is `apt-get update` plus
     * `apt-get install`, reporting apt's own machine-readable `APT::Status-Fd` percentages (on fd 3,
     * for the reason spelled out at the call site), so a plain apt-based toolchain gets a genuine bar
     * rather than three hand-placed milestones. It keeps apt's exit status (via a temp file — the
     * status of a pipeline is its last member's).
     *
     * Both are defined unconditionally so a script can call them on either execution path; without a
     * PTY (`JCODE_PROGRESS_TOKEN` unset) the marker is simply not emitted. Every helper ends by
     * returning 0 — a script running under `set -e` would otherwise abort on a progress call whose
     * last comparison happened to be false.
     */
    private fun withCatalogHelpers(script: String): String = CATALOG_SHELL_HELPERS + script

    /** Fix DNS/resolv.conf for the selected distro before an apt operation. Host-side, idempotent,
     *  no proot round-trip; safe to call unconditionally (see [RootfsManager.ensureRootfsNetworking]). */
    private fun ensureSelectedDistroNetworking() {
        val distroId = _environmentState.value.runtime.selectedDistro.id
        runCatching { rootfsManager.ensureRootfsNetworking(rootfsManager.getRootfsPath(distroId)) }
    }

    /**
     * Best-effort `apt-get update` for the fresh distro's package lists, run once during first-run
     * setup ([WizardStepId.AptUpdated]). Ensures DNS first, then goes through [execCatalogAction] so it
     * inherits the apt self-heal preamble + retry/back-off. Never blocks setup: the caller treats this
     * step as best-effort ([BEST_EFFORT_STEPS]) — a stale list just means the first `apt-get install`
     * refreshes itself. Called from inside the wizard lock, so it must NOT take [lock] again.
     */
    private suspend fun aptUpdateStep(onLine: ((String) -> Unit)? = null): ExecResult {
        ensureSelectedDistroNetworking()
        onLine?.invoke("Refreshing package lists (apt-get update)…")
        return execCatalogAction("Refresh package lists", "sudo apt-get -y update", timeoutMs = 300_000L)
    }

    /**
     * Install the newest LTS Node.js during first-run setup ([WizardStepId.NodeInstalled]), straight
     * after the package lists are refreshed. Node is what most of the workbench leans on — imported
     * `.vsix` extensions, several language servers and most project templates all assume `node`/`npm`
     * are on PATH — so a fresh environment ships with it rather than making a trip to Toolchains
     * everyone's first task.
     *
     * Runs the `nodejs` catalog entry's own script (nvm, newest LTS) and records the outcome in the
     * same persisted installed-set the Toolchains panel reads, so the row already reads "Installed"
     * and the version picker can add or remove versions alongside it. Best-effort
     * ([BEST_EFFORT_STEPS]): a failure still leaves a usable environment. Called from inside the
     * wizard lock, so it must NOT take [lock] again.
     */
    private suspend fun installNodeStep(
        onLine: ((String) -> Unit)? = null,
        onProgress: ((Int, String) -> Unit)? = null,
    ): ExecResult {
        val entry = _sdkCatalogState.value.entries
            .ifEmpty { runCatching { sdkCatalogLoader.load() }.getOrElse { emptyList() } }
            .firstOrNull { it.id == NODE_CATALOG_ENTRY_ID }
            ?: return ExecResult(internalError = "Node.js is missing from the toolchain catalog.")

        if (execCatalogScript(entry.verifyScript, timeoutMs = 120_000L).succeeded) {
            return ExecResult(stdout = "Node.js is already installed.", exitCode = 0)
        }

        ensureSelectedDistroNetworking()
        onLine?.invoke("Installing Node.js (LTS)…")
        // Without a Setup terminal there is no PTY for the OSC progress marker, so the script's plain
        // "[ 42%] label" line is what drives the wizard's bar on that path.
        val result = execCatalogAction(
            label = "Install ${entry.name} (LTS)",
            script = entry.installScript,
            timeoutMs = entry.installTimeoutMs(catalogInstallTimeoutMs),
            onProgress = onProgress,
            onLine = { line ->
                onLine?.invoke(line)
                PROGRESS_LINE.matchEntire(line.trim())?.let { match ->
                    val percent = match.groupValues[1].toIntOrNull() ?: return@let
                    onProgress?.invoke(percent.coerceIn(0, 100), match.groupValues[2].trim())
                }
            },
        )

        // Same rule as a catalog install: the verify script, not the install script's exit code,
        // decides whether the tool is actually there.
        val installed = execCatalogScript(entry.verifyScript, timeoutMs = 120_000L).succeeded
        val distroId = _environmentState.value.runtime.selectedDistro.id
        persistInstalledCatalogEntries(
            distroId,
            readInstalledCatalogEntries(distroId).toMutableSet()
                .apply { if (installed) add(entry.id) else remove(entry.id) }
                .toSet(),
        )
        if (!installed) {
            return ExecResult(
                internalError = result.internalError
                    ?: "Node.js install finished, but verification did not detect it.",
                exitCode = result.exitCode ?: 1,
            )
        }
        return ExecResult(stdout = "Node.js (LTS) installed.", exitCode = 0)
    }

    /**
     * User-initiated system package update: `apt-get update && apt-get upgrade`. Deliberately opt-in —
     * never run automatically, since an upgrade can pull a lot and is slow under proot. Reuses
     * [execCatalogAction] for self-heal + retry and streams into the Setup terminal when available.
     * Takes [lock] to serialize against catalog installs (unlike [aptUpdateStep], which already runs
     * under the wizard's lock).
     */
    suspend fun updateSystemPackages(): ExecResult = lock.withLock {
        if (_environmentState.value.distroInstalled != true || _environmentState.value.jcodeUserReady != true) {
            return@withLock ExecResult(internalError = "Finish environment setup before updating packages.")
        }
        ensureSelectedDistroNetworking()
        execCatalogAction(
            "Update system packages",
            "sudo apt-get -y update && sudo apt-get -y upgrade",
            timeoutMs = 1_800_000L,
        )
    }

    /**
     * Prepend apt/dpkg self-healing so the runtime recovers from a dirty package state on its own
     * (only for scripts that actually use apt/dpkg — a no-op otherwise). The preamble:
     *  - writes an idempotent apt.conf drop-in so *every* apt command retries transient fetch failures
     *    ([Acquire::Retries]) and waits for a held dpkg/apt lock instead of dying ([DPkg::Lock::Timeout]);
     *  - runs `dpkg --configure -a` to finish a package left half-configured by a previously
     *    interrupted install (app killed / device slept mid-`apt`);
     *  - runs `apt-get install -f -y` to repair broken/partial dependencies from an aborted run.
     * All three are silent, fast no-ops when the runtime is already clean.
     */
    private fun withAptSelfHeal(script: String): String {
        // `jcode_apt` is the injected helper (see [withCatalogHelpers]) that most entries now use
        // instead of calling apt-get directly; it needs the same repair pass.
        if (!(
                script.contains("apt-get") || script.contains("apt ") ||
                    script.contains("dpkg") || script.contains("jcode_apt")
                )
        ) {
            return script
        }
        val preamble =
            "mkdir -p /etc/apt/apt.conf.d 2>/dev/null || true\n" +
            "printf 'Acquire::Retries \"3\";\\nAcquire::http::Timeout \"30\";\\n" +
            "DPkg::Lock::Timeout \"180\";\\n' > /etc/apt/apt.conf.d/80-jcode-heal 2>/dev/null || true\n" +
            "dpkg --configure -a 2>/dev/null || true\n" +
            "apt-get install -f -y 2>/dev/null || true\n"
        return preamble + script
    }

    /**
     * Execute a command inside the distro using proot.
     */
    private fun execInDistro(
        command: String,
        workdir: String = _environmentState.value.runtime.workdir,
        env: Map<String, String> = emptyMap(),
        timeoutMs: Long = 60_000L,
        onLine: ((String) -> Unit)? = null,
        user: String = _environmentState.value.runtime.user,
        raw: Boolean = false,
    ): ExecResult {
        val runtime = _environmentState.value.runtime
        val distroId = runtime.selectedDistro.id
        val arch = runtime.selectedDistro.arch
        val rootfsPath = rootfsManager.getRootfsPath(distroId)

        if (!rootfsManager.isDistroInstalled(distroId)) {
            return ExecResult(internalError = "Distro '$distroId' is not installed.", exitCode = 1)
        }

        if (!prootManager.isProotInstalled) {
            return ExecResult(internalError = "proot binary is not available.", exitCode = 1)
        }

        // Self-heal DNS/host config and the system locale once per distro per process. Fresh installs
        // get this at extraction time, but an environment installed before this fix (e.g. a broken
        // minimal ubuntu-base 26.04 with no working /etc/resolv.conf) is repaired here so apt starts
        // resolving without a reinstall.
        if (rootfsConfigured.add(distroId)) {
            rootfsManager.ensureRootfsConfig(rootfsPath)
        }

        // Foreign-arch environment: make sure the QEMU emulator is extracted before invoking proot.
        if (prootManager.needsQemu(arch) && !prootManager.isQemuInstalled(arch)) {
            val qemuOk = kotlinx.coroutines.runBlocking { prootManager.ensureQemuInstalled(arch) }
            if (!qemuOk) {
                return ExecResult(
                    internalError = "${arch.qemuUserBinary} is required to run ${runtime.selectedDistro.label} " +
                        "but is not available. The QEMU emulator binary has not been bundled yet.",
                    exitCode = 1,
                )
            }
        }

        // Non-root commands run through `su - <user>`, which hard-fails if the account is missing
        // (fresh rootfs, or useradd silently failed during setup). Ensure it exists first.
        if (user != "root" && verifiedDistroUsers["$distroId:$user"] != true) {
            val ensure = ensureDistroUser(distroId, user)
            if (!ensure.succeeded) {
                return ExecResult(
                    internalError = "user '$user' does not exist in $distroId and could not be created: " +
                        (ensure.internalError ?: ensure.stderr.lineSequence().firstOrNull { it.isNotBlank() } ?: "unknown error"),
                    exitCode = 1,
                )
            }
        }

        val prootArgs = prootManager.buildShellCommand(
            rootfsPath = rootfsPath,
            shellCommand = command,
            binds = runtime.binds,
            env = env,
            workdir = workdir,
            user = user,
            rootfsArch = arch,
        )

        return executeProcess(prootArgs, timeoutMs, onLine = onLine, rootfsArch = arch, raw = raw)
    }

    /**
     * Spawn a long-lived process inside the active distro with stdin/stdout PIPES (no PTY — clean
     * bidirectional protocol traffic, no echo). The caller reads from `process.inputStream` and writes
     * to `process.outputStream`; stderr is kept separate. Returns null if the runtime isn't ready.
     *
     * Used for both debug adapters (DAP) and language servers (LSP): both frame JSON over stdio, and
     * a PTY would echo every request back into the read stream.
     */
    fun spawnStdioProcess(
        command: String,
        workdir: String = _environmentState.value.runtime.workdir,
        // Some adapters must run as a specific user — e.g. netcoredbg needs root, where the .NET SDK
        // (installed under /root/.dotnet) is readable. Defaults to the runtime user.
        userOverride: String? = null,
        // Prepended to PATH so the process can find its runtime (e.g. /root/.dotnet for netcoredbg).
        extraPath: String = "",
        // The extension this tree belongs to. Stamped into the guest environment, and so inherited by
        // everything the process forks, which is how [GuestProcessTree] finds the tree again to end
        // it — a proot tree cannot be reached through the launcher alone.
        owner: String? = null,
    ): Process? {
        val runtime = _environmentState.value.runtime
        val distroId = runtime.selectedDistro.id
        val arch = runtime.selectedDistro.arch
        val rootfsPath = rootfsManager.getRootfsPath(distroId)
        val user = userOverride ?: runtime.user
        if (!rootfsManager.isDistroInstalled(distroId) || !prootManager.isProotInstalled) return null
        if (prootManager.needsQemu(arch) && !prootManager.isQemuInstalled(arch)) return null
        val basePath = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        val instance = owner?.let { GuestProcessTree.mintInstance(it) }
        val env = mapOf(
            "HOME" to (if (user == "root") "/root" else "/home/$user"),
            "USER" to user,
            "TERM" to "dumb",
            "TMPDIR" to "/tmp",
            "PATH" to (if (extraPath.isNotBlank()) "$extraPath:$basePath" else basePath),
        ) + instance?.let { GuestProcessTree.instanceEnv(owner!!, it) }.orEmpty()
        val prootArgs = prootManager.buildShellCommand(
            rootfsPath = rootfsPath,
            shellCommand = command,
            binds = runtime.binds,
            env = env,
            workdir = workdir,
            user = user,
            rootfsArch = arch,
        )
        return try {
            val builder = ProcessBuilder(prootArgs).redirectErrorStream(false)
            for (kv in prootManager.runtimeEnv(arch)) {
                val sep = kv.indexOf('=')
                if (sep > 0) builder.environment()[kv.substring(0, sep)] = kv.substring(sep + 1)
            }
            builder.start().also { started ->
                instance?.let { GuestProcessTree.register(started, it) }
            }
        } catch (e: Exception) {
            android.util.Log.e("DistroService", "spawnStdioProcess failed", e)
            null
        }
    }

    /**
     * Execute a process and capture output.
     */
    private fun executeProcess(
        command: List<String>,
        timeoutMs: Long,
        onLine: ((String) -> Unit)? = null,
        rootfsArch: Arch = Arch.ARM64,
        raw: Boolean = false,
    ): ExecResult {
        return try {
            val builder = ProcessBuilder(command)
                .redirectErrorStream(false)
            // Centralized runtime env (LD_LIBRARY_PATH, PROOT_TMP_DIR, + PROOT_NO_SECCOMP when emulating).
            for (kv in prootManager.runtimeEnv(rootfsArch)) {
                val sep = kv.indexOf('=')
                if (sep > 0) builder.environment()[kv.substring(0, sep)] = kv.substring(sep + 1)
            }
            val process = builder.start()

            val stdout = StringBuilder()
            val stderr = StringBuilder()

            // NOTE: the drain loops MUST NOT let any exception escape. When the process is destroyed
            // (timeout below, or killed while the runtime is under heavy load — e.g. a QEMU VM boot),
            // the blocked readLine() throws InterruptedIOException / "Stream closed"; uncaught on a
            // pool thread that would crash the whole app. Swallow it — partial output is kept.
            val stdoutTask = drainPool.submit(Runnable {
                try {
                    BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                        reader.lineSequence().forEach { line ->
                            (if (raw) rawProcessOutputLine(line) else normalizeProcessOutputLine(line))?.let { normalized ->
                                stdout.appendLine(normalized)
                                onLine?.invoke(normalized)
                            }
                        }
                    }
                } catch (_: Throwable) {
                    // process destroyed / stream closed mid-read — expected on teardown.
                }
            })
            val stderrTask = drainPool.submit(Runnable {
                try {
                    BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                        reader.lineSequence().forEach { line ->
                            (if (raw) rawProcessOutputLine(line) else normalizeProcessOutputLine(line))?.let { normalized ->
                                stderr.appendLine(normalized)
                                onLine?.invoke(normalized)
                            }
                        }
                    }
                } catch (_: Throwable) {
                    // process destroyed / stream closed mid-read — expected on teardown.
                }
            })

            val completed = process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)

            if (!completed) {
                process.destroyForcibly()
                return ExecResult(
                    stdout = stdout.toString(),
                    stderr = stderr.toString(),
                    internalError = "Command timed out after ${timeoutMs}ms.",
                    exitCode = -1,
                )
            }

            // Same 5s best-effort bound as the old join(5000): wait for the drains to reach EOF, but
            // don't propagate a timeout/interrupt — partial output is acceptable on a stuck stream.
            runCatching { stdoutTask.get(5000, TimeUnit.MILLISECONDS) }
            runCatching { stderrTask.get(5000, TimeUnit.MILLISECONDS) }

            ExecResult(
                stdout = stdout.toString(),
                stderr = stderr.toString(),
                exitCode = process.exitValue(),
            )
        } catch (e: Exception) {
            ExecResult(internalError = e.message ?: "Process execution failed.", exitCode = -1)
        }
    }

    private fun resolveBinds(
        distroBinds: List<dev.blamspot.jcode.core.config.BindMount>,
        projectHostPath: String?,
        projectTargetPath: String?,
        projectBinds: List<Pair<String, String>>,
    ): List<DistroBind> {
        return when {
            distroBinds.isNotEmpty() -> distroBinds.map { DistroBind(host = it.host, target = it.target) }
            // Bind every project of the current workspace (host dir -> its guest target) so a multi-repo
            // extension can reach them all at once; keep the selected project's bind first (it's the
            // primary — see primaryBind()). Dedup by target in case two resolve to the same mount.
            projectBinds.isNotEmpty() -> {
                val perProject = projectBinds.sortedByDescending { it.second == projectTargetPath }
                    .distinctBy { it.second }
                    .map { DistroBind(host = it.first, target = it.second) }
                // Then the projects folder itself, so the runtime also sees folders that are not
                // workspace projects yet. Without it a "choose a folder to add" browser can only offer
                // what is already open, which is the one thing nobody needs to add. Appended last so
                // the selected project stays the primary bind, and it is the least specific target, so
                // a project living outside this folder keeps resolving through its own bind.
                if (perProject.none { it.target == DEFAULT_DISTRO_WORKDIR }) {
                    perProject + DistroBind(WorkspaceHostPaths.projectsRoot, DEFAULT_DISTRO_WORKDIR)
                } else {
                    perProject
                }
            }
            !projectHostPath.isNullOrBlank() && !projectTargetPath.isNullOrBlank() -> {
                listOf(DistroBind(projectHostPath, projectTargetPath))
            }
            else -> listOf(DistroBind(WorkspaceHostPaths.projectsRoot, DEFAULT_DISTRO_WORKDIR))
        }
    }

    private fun primaryBind(): PrimaryBind {
        val bind = _environmentState.value.runtime.binds.firstOrNull()
            ?: DistroBind(WorkspaceHostPaths.projectsRoot, DEFAULT_DISTRO_WORKDIR)
        return PrimaryBind(
            host = bind.host,
            hostFile = File(bind.host),
            target = bind.target,
        )
    }

    private suspend fun readSelectedDistro(available: List<DistroProfile>): DistroProfile? {
        val selected = dataStore.data.first()[PreferencesKeys.SelectedDistro]
        return selected?.let { DistroProfile.fromId(it, available) }
    }

    private suspend fun persistSelectedDistro(profile: DistroProfile) {
        // Mirrored into startupPrefs so the next launch knows the selection before DataStore is read
        // — see seededDistro. DataStore stays the source of truth; this is only the startup seed.
        startupPrefs.edit().putString(KEY_SELECTED_DISTRO, profile.id).apply()
        dataStore.edit { prefs ->
            prefs[PreferencesKeys.SelectedDistro] = profile.id
        }
    }

    private suspend fun persistCompletedSteps(steps: Set<WizardStepId>) {
        dataStore.edit { prefs ->
            prefs[PreferencesKeys.CompletedSteps] = steps.mapTo(linkedSetOf(), WizardStepId::key)
        }
    }

    private suspend fun readFirstRunSetupDeferred(): Boolean {
        return dataStore.data.first()[PreferencesKeys.FirstRunSetupDeferred] ?: false
    }

    private suspend fun persistFirstRunSetupDeferred(deferred: Boolean) {
        dataStore.edit { prefs ->
            prefs[PreferencesKeys.FirstRunSetupDeferred] = deferred
        }
    }

    private suspend fun syncSdkCatalogSelection(distroId: String) {
        val entries = _sdkCatalogState.value.entries.ifEmpty {
            runCatching { sdkCatalogLoader.load() }.getOrElse { error ->
                _sdkCatalogState.value = _sdkCatalogState.value.copy(
                    selectedDistroId = distroId,
                    errorMessage = "Failed to load SDK catalog: ${error.message ?: "Unknown error"}",
                )
                return
            }
        }

        _sdkCatalogState.value = _sdkCatalogState.value.copy(
            entries = entries,
            installedEntryIds = readInstalledCatalogEntries(distroId),
            selectedDistroId = distroId,
        )
    }

    private suspend fun readInstalledCatalogEntries(distroId: String): Set<String> {
        return dataStore.data.first()[installedEntriesKey(distroId)].orEmpty()
    }

    private suspend fun persistInstalledCatalogEntries(
        distroId: String,
        entryIds: Set<String>,
    ) {
        dataStore.edit { prefs ->
            prefs[installedEntriesKey(distroId)] = entryIds
        }
    }

    private fun updateRunningStep(
        stepId: WizardStepId,
        message: String,
    ) {
        _environmentState.value = _environmentState.value.copy(
            runningStep = stepId,
            errorMessage = null,
            activityLog = (_environmentState.value.activityLog + message).takeLast(SETUP_ACTIVITY_LOG_LIMIT),
        )
    }

    private fun appendActivityLogLine(line: String) {
        val normalized = normalizeProcessOutputLine(line) ?: return
        synchronized(activityLogLock) {
            _environmentState.value = _environmentState.value.copy(
                activityLog = (_environmentState.value.activityLog + normalized).takeLast(SETUP_ACTIVITY_LOG_LIMIT),
            )
        }
    }

    private fun normalizeProcessOutputLine(line: String): String? {
        val normalized = ANSI_CSI.replace(line, "").trim()
        if (normalized.isBlank()) return null
        if (normalized.startsWith("proot warning: unknown syscall ")) return null
        return normalized
    }

    /**
     * Byte-accurate variant for programmatic consumers (the extension exec.run bridge). Preserves
     * leading/trailing whitespace and blank lines so column- and indent-sensitive output — git
     * status --porcelain, unified diffs, ls -l — is not corrupted. Only strips proot's syscall noise.
     */
    private fun rawProcessOutputLine(line: String): String? {
        if (line.startsWith("proot warning: unknown syscall ")) return null
        return line
    }

    private fun summarizeResult(result: ExecResult): String {
        return result.internalError
            ?: result.stdout.lineSequence().firstOrNull()?.takeIf(String::isNotBlank)
            ?: result.stderr.lineSequence().firstOrNull()?.takeIf(String::isNotBlank)
            ?: "Command exited with ${result.exitCode ?: "unknown"}."
    }

    private fun appendCatalogLogLines(
        existing: List<String>,
        lines: List<String>,
    ): List<String> {
        return (existing + lines).takeLast(240)
    }

    private fun formatActionLogs(
        entry: SdkCatalogEntry,
        action: SdkCatalogAction,
        actionResult: ExecResult,
        verifyResult: ExecResult,
        installedNow: Boolean,
    ): List<String> {
        return buildList {
            add("[command] ${action.label} ${entry.name}")
            addAll(actionResult.toLogBlock())
            add("[verify] ${entry.name}")
            addAll(verifyResult.toLogBlock())
            add(
                when (action) {
                    SdkCatalogAction.Install ->
                        if (installedNow) "[result] Installed." else "[result] Install completed but verification failed."

                    SdkCatalogAction.Uninstall ->
                        if (!installedNow) "[result] Removed." else "[result] Still detected after removal."

                    // Nothing was added or taken away, so the verify result says nothing about it —
                    // the listing script re-read afterwards is what confirms the switch.
                    SdkCatalogAction.Use ->
                        if (actionResult.succeeded) "[result] Switched." else "[result] Switch failed."
                },
            )
        }
    }

    private fun ExecResult.toLogBlock(): List<String> {
        return buildList {
            add("[exit] ${exitCode ?: "n/a"}${if (truncated) " (truncated)" else ""}")
            internalError?.takeIf { it.isNotBlank() }?.let { add("[error] $it") }
            stdout.lineSequence()
                .filter(String::isNotBlank)
                .forEach { add("[stdout] $it") }
            stderr.lineSequence()
                .filter(String::isNotBlank)
                .forEach { add("[stderr] $it") }
            if (size == 1) {
                add("[output] <empty>")
            }
        }
    }

    private fun SdkCatalogEntry.scriptFor(action: SdkCatalogAction): String {
        return when (action) {
            SdkCatalogAction.Install -> installScript
            SdkCatalogAction.Uninstall -> uninstallScript
            SdkCatalogAction.Use -> useVersionScript
        }
    }

    /** Substitute a chosen version into a catalog script: replaces the `{{version}}` placeholder and
     *  exports `JCODE_VERSION` so scripts can branch on it. No-op when [version] is null/blank. */
    private fun applyVersion(script: String, version: String?): String {
        if (version.isNullOrBlank()) return script
        val quoted = "'" + version.replace("'", "'\\''") + "'"
        return "export JCODE_VERSION=$quoted\n" + script.replace("{{version}}", version)
    }

    /** Parse a [SdkCatalogEntry.versionsScript] into tagged versions. Each line is `version` or
     *  `version<TAB>tag` (e.g. `v22.23.1\tLTS Jod`); the tag column is optional and display-only. */
    private fun parseVersionOptions(stdout: String): List<CatalogVersion> =
        stdout.lineSequence()
            .map { it.trimEnd('\r', '\n') }
            .filter { it.isNotBlank() }
            .map { line ->
                val parts = line.split('\t', limit = 2)
                CatalogVersion(version = parts[0].trim(), tag = parts.getOrNull(1)?.trim().orEmpty())
            }
            .filter { it.version.isNotEmpty() }
            .distinctBy { it.version }
            .toList()

    /** An entry's installed versions plus the one on PATH, when its listing script marks it. */
    private data class InstalledVersions(val versions: List<String> = emptyList(), val active: String? = null)

    private fun readInstalledVersionsForEntry(entry: SdkCatalogEntry): InstalledVersions {
        if (entry.installedVersionsScript.isBlank()) return InstalledVersions()
        val result = execCatalogScript(entry.installedVersionsScript, timeoutMs = 60_000L)
        if (!result.succeeded) return InstalledVersions()
        // Lines are "version" or "version<TAB>active" — the same tab-separated shape versionsScript
        // uses for its tags, so a script that reports no active version still parses.
        val rows = result.stdout.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { line ->
                val parts = line.split('\t', limit = 2)
                parts[0].trim() to parts.getOrNull(1)?.trim().orEmpty()
            }
            .filter { it.first.isNotEmpty() }
            .distinctBy { it.first }
            .toList()
        return InstalledVersions(
            versions = rows.map { it.first },
            active = rows.firstOrNull { it.second.equals("active", ignoreCase = true) }?.first,
        )
    }

    private fun installedEntriesKey(distroId: String) =
        stringSetPreferencesKey("sdk_catalog_installed.$distroId")

    private fun lspCatalogEntries(): List<LspCatalogEntry> = LspServerCatalog.BUILT_IN

    /** Note: deliberately leaves [LspCatalogState.loaded] alone — this runs during startup with a
     *  distro selection that may still be the default, so it cannot vouch for the installed set. */
    private suspend fun syncLspCatalogSelection(distroId: String) {
        _lspCatalogState.value = _lspCatalogState.value.copy(
            entries = _lspCatalogState.value.entries.ifEmpty { lspCatalogEntries() },
            installedEntryIds = readInstalledLspEntries(distroId),
            selectedDistroId = distroId,
        )
    }

    private suspend fun readInstalledLspEntries(distroId: String): Set<String> {
        return dataStore.data.first()[installedLspEntriesKey(distroId)].orEmpty()
    }

    private suspend fun persistInstalledLspEntries(
        distroId: String,
        entryIds: Set<String>,
    ) {
        dataStore.edit { prefs ->
            prefs[installedLspEntriesKey(distroId)] = entryIds
        }
    }

    private fun formatLspActionLogs(
        name: String,
        action: LspCatalogAction,
        actionResult: ExecResult,
        verifyResult: ExecResult,
        installedNow: Boolean,
    ): List<String> {
        return buildList {
            add("[command] ${action.label} $name")
            addAll(actionResult.toLogBlock())
            add("[verify] $name")
            addAll(verifyResult.toLogBlock())
            add(
                when (action) {
                    LspCatalogAction.Install ->
                        if (installedNow) "[result] Installed." else "[result] Install completed but verification failed."

                    LspCatalogAction.Uninstall ->
                        if (!installedNow) "[result] Removed." else "[result] Still detected after removal."
                },
            )
        }
    }

    private fun LspCatalogEntry.commandFor(action: LspCatalogAction): String {
        return when (action) {
            LspCatalogAction.Install -> installCommand
            LspCatalogAction.Uninstall -> uninstallCommand
        }
    }

    private fun installedLspEntriesKey(distroId: String) =
        stringSetPreferencesKey("lsp_catalog_installed.$distroId")

    private suspend fun readInstalledDebugEntries(distroId: String): Set<String> {
        return dataStore.data.first()[installedDebugEntriesKey(distroId)].orEmpty()
    }

    private suspend fun persistInstalledDebugEntries(distroId: String, entryIds: Set<String>) {
        dataStore.edit { prefs -> prefs[installedDebugEntriesKey(distroId)] = entryIds }
    }

    private fun installedDebugEntriesKey(distroId: String) =
        stringSetPreferencesKey("debug_catalog_installed.$distroId")

    private fun formatDebugActionLogs(
        name: String,
        action: DebugEngineAction,
        actionResult: ExecResult,
        verifyResult: ExecResult,
        installedNow: Boolean,
    ): List<String> {
        return buildList {
            add("[command] ${action.label} $name")
            addAll(actionResult.toLogBlock())
            add("[verify] $name")
            addAll(verifyResult.toLogBlock())
            add(
                when (action) {
                    DebugEngineAction.Install ->
                        if (installedNow) "[result] Installed." else "[result] Install completed but verification failed."

                    DebugEngineAction.Uninstall ->
                        if (!installedNow) "[result] Removed." else "[result] Still detected after removal."
                },
            )
        }
    }

    private fun DebugEngineEntry.commandFor(action: DebugEngineAction): String {
        return when (action) {
            DebugEngineAction.Install -> installCommand
            DebugEngineAction.Uninstall -> uninstallCommand
        }
    }

    private data class PrimaryBind(
        val host: String,
        val hostFile: File,
        val target: String,
    )

    private object PreferencesKeys {
        val FirstRunSetupDeferred = booleanPreferencesKey("first_run_setup_deferred")
        val SelectedDistro = stringPreferencesKey("selected_distro")
        val CompletedSteps = stringSetPreferencesKey("completed_steps")
    }

    companion object {
        private const val SETUP_ACTIVITY_LOG_LIMIT: Int = 240
        /** Back-off between ensureDistroUser retries on a rootfs where creation keeps failing. */
        private const val ENSURE_USER_RETRY_MS: Long = 30_000L
        /** Minimum required storage: 2GB */
        private const val MIN_REQUIRED_STORAGE_BYTES: Long = 2L * 1024 * 1024 * 1024
        /** A failed toolchain install (transient apt/network/dpkg hiccup) is retried this many times. */
        private const val CATALOG_INSTALL_MAX_ATTEMPTS: Int = 3
        /** Linear back-off base between install retries (× attempt): 3s, then 6s. */
        private const val CATALOG_RETRY_BACKOFF_MS: Long = 3_000L
        /** Wizard steps that must never abort setup — logged, marked done, and stepped over on failure. */
        private val BEST_EFFORT_STEPS: Set<WizardStepId> =
            setOf(WizardStepId.AptUpdated, WizardStepId.NodeInstalled)

        /** Catalog entry installed automatically during first-run setup — see [installNodeStep]. */
        private const val NODE_CATALOG_ENTRY_ID: String = "nodejs"

        /** The plain-text half of `jcode_progress`: `[ 42%] Downloading Node.js`. */
        private val PROGRESS_LINE = Regex("""\[\s*(\d+)%\]\s*(.*)""")

        /** CSI escapes (colour, cursor moves). The setup log is plain text, but plenty of install
         *  scripts colour their output — nvm's "Creating default alias" line is SGR-wrapped — and the
         *  raw bytes render there as stray control glyphs. The introducer is `Char(27)` rather than an
         *  escape so a literal ESC byte — invisible to most editors and easy to destroy on a later
         *  edit — stays out of the source. The bracket must still be backslash-escaped: ICU's regex
         *  reads `[` inside a class as the start of a *nested* class, so `[[]` fails to compile. */
        private val ANSI_CSI = Regex(Char(27) + """\[[0-9;?]*[ -/]*[@-~]""")

        /** Shell helpers prepended to every catalog install/uninstall — see [withCatalogHelpers]. */
        private val CATALOG_SHELL_HELPERS: String = """
            # --- JCode catalog helpers (injected by DistroService) ---
            __jc_last_pct=-1
            jcode_progress() {
              __jc_p=${'$'}1
              case "${'$'}__jc_p" in ''|*[!0-9]*) return 0 ;; esac
              [ "${'$'}__jc_p" -gt 100 ] && __jc_p=100
              if [ -n "${'$'}{JCODE_PROGRESS_TOKEN:-}" ]; then
                printf '\033]7716;%s;%s;%s\007' "${'$'}JCODE_PROGRESS_TOKEN" "${'$'}__jc_p" "${'$'}2"
              fi
              if [ "${'$'}__jc_p" != "${'$'}__jc_last_pct" ]; then
                __jc_last_pct=${'$'}__jc_p
                printf '[%3d%%] %s\n' "${'$'}__jc_p" "${'$'}2"
              fi
              return 0
            }
            jcode_fetch() {
              __jc_u=${'$'}1; __jc_d=${'$'}2; __jc_a=${'$'}{3:-0}; __jc_b=${'$'}{4:-100}; __jc_l=${'$'}{5:-Downloading}
              __jc_t=${'$'}(curl -fsSLI "${'$'}__jc_u" 2>/dev/null | tr -d '\r' |
                awk 'tolower(${'$'}1)=="content-length:"{n=${'$'}2} END{print n+0}')
              rm -f "${'$'}__jc_d"
              curl -fsSL --retry 3 --retry-delay 3 --connect-timeout 30 -o "${'$'}__jc_d" "${'$'}__jc_u" &
              __jc_pid=${'$'}!
              while kill -0 "${'$'}__jc_pid" 2>/dev/null; do
                if [ "${'$'}__jc_t" -gt 0 ] && [ -f "${'$'}__jc_d" ]; then
                  __jc_c=${'$'}(wc -c < "${'$'}__jc_d" 2>/dev/null || echo 0)
                  jcode_progress ${'$'}(( __jc_a + (__jc_b - __jc_a) * __jc_c / __jc_t )) "${'$'}__jc_l"
                fi
                sleep 2
              done
              wait "${'$'}__jc_pid"
            }
            __jc_apt_run() {
              __ja_a=${'$'}1; __ja_b=${'$'}2; __ja_l=${'$'}3; shift 3
              __ja_mid=${'$'}(( (__ja_a + __ja_b) / 2 ))
              rm -f /tmp/.jcode-apt-rc
              # Status-Fd MUST NOT be 1. Combined with Dpkg::Use-Pty=0 (no pty, so dpkg inherits our
              # stdout) apt claims fd 1 as its status channel while dpkg hands the same descriptor to
              # maintainer scripts, and their first write to stdout fails with EIO. That kills the
              # postinst and leaves the package half-configured ("iF") — ca-certificates on Ubuntu
              # 26.04 is the loud case, but it was measured on 24.04 too. Either option alone is
              # harmless; it is the pair that breaks. Status goes to fd 3 and is folded back into the
              # same pipe by `3>&1`, so the reader below still sees one merged stream.
              { sudo apt-get -y -o APT::Status-Fd=3 -o Dpkg::Use-Pty=0 "${'$'}@" 2>&1 3>&1
                echo "__jcrc:${'$'}?" > /tmp/.jcode-apt-rc
              } | while IFS= read -r __ja_line; do
                case "${'$'}__ja_line" in
                  dlstatus:*|pmstatus:*)
                    case "${'$'}__ja_line" in
                      dlstatus:*) __ja_x=${'$'}__ja_a; __ja_y=${'$'}__ja_mid ;;
                      *)          __ja_x=${'$'}__ja_mid; __ja_y=${'$'}__ja_b ;;
                    esac
                    __ja_p=${'$'}(printf '%s' "${'$'}__ja_line" | cut -d: -f3 | cut -d. -f1)
                    case "${'$'}__ja_p" in
                      ''|*[!0-9]*) ;;
                      *) jcode_progress ${'$'}(( __ja_x + (__ja_y - __ja_x) * __ja_p / 100 )) \
                           "${'$'}(printf '%s' "${'$'}__ja_line" | cut -d: -f4- | cut -c1-60)" ;;
                    esac
                    ;;
                  *) printf '%s\n' "${'$'}__ja_line" ;;
                esac
              done
              jcode_progress "${'$'}__ja_b" "${'$'}__ja_l"
              __ja_rc=${'$'}(sed -n 's/^__jcrc://p' /tmp/.jcode-apt-rc 2>/dev/null)
              rm -f /tmp/.jcode-apt-rc
              return "${'$'}{__ja_rc:-0}"
            }
            jcode_apt() {
              __ja0=${'$'}1; __ja1=${'$'}2; __ja2=${'$'}3; shift 3
              __ja_q=${'$'}(( __ja0 + (__ja1 - __ja0) / 5 ))
              __jc_apt_run "${'$'}__ja0" "${'$'}__ja_q" "${'$'}__ja2" update || true
              __jc_apt_run "${'$'}__ja_q" "${'$'}__ja1" "${'$'}__ja2" install "${'$'}@"
            }
            # --- end JCode catalog helpers ---

        """.trimIndent()
    }
}
