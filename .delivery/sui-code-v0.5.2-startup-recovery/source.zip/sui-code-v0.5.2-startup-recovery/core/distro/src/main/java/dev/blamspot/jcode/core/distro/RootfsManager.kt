package dev.blamspot.jcode.core.distro

import android.content.Context
import android.system.ErrnoException
import android.system.Os
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.GZIPInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.tukaani.xz.XZInputStream

/**
 * Manages rootfs (root filesystem) download, extraction, and lifecycle.
 * 
 * Storage layout:
 *   appContext.filesDir/distros/<distro-id>/
 *     ├── rootfs/          # Extracted root filesystem
 *     └── metadata.json    # Install metadata
 */
class RootfsManager(
    private val context: Context,
    val downloader: RootfsDownloader,
) {
    private val appContext = context.applicationContext
    
    /** Base directory for all distro installations */
    val distrosDir: File
        get() = File(appContext.filesDir, "distros")
    
    /** Temporary directory for downloads */
    val tmpDir: File
        get() = File(appContext.filesDir, "tmp").also { it.mkdirs() }
    
    /**
     * Get the rootfs directory for a specific distro.
     */
    fun getRootfsPath(distroId: String): File {
        return File(distrosDir, "$distroId/rootfs")
    }
    
    /**
     * Check if a distro is installed (rootfs extracted).
     */
    fun isDistroInstalled(distroId: String): Boolean {
        val rootfs = getRootfsPath(distroId)
        // Check for essential directories
        return rootfs.exists() &&
            File(rootfs, "bin").exists() &&
            File(rootfs, "etc").exists()
    }
    
    /**
     * Get list of installed distros.
     */
    fun getInstalledDistros(): List<InstalledDistro> {
        if (!distrosDir.exists()) return emptyList()
        
        return distrosDir.listFiles()
            ?.filter { it.isDirectory && isDistroInstalled(it.name) }
            ?.map { dir ->
                InstalledDistro(
                    id = dir.name,
                    rootfsPath = File(dir, "rootfs"),
                    installDate = File(dir, "metadata.json").lastModified(),
                )
            }
            ?: emptyList()
    }
    
    /**
     * Download and extract a rootfs for the given distro profile.
     * 
     * @param profile The distro to install
     * @return Flow of installation progress events
     */
    fun installDistro(profile: DistroProfile): Flow<InstallProgress> = flow {
        val distroDir = File(distrosDir, profile.id)
        val rootfsDir = File(distroDir, "rootfs")
        
        // Check if already installed
        if (isDistroInstalled(profile.id)) {
            emit(InstallProgress.AlreadyInstalled(profile.id))
            return@flow
        }
        
        emit(InstallProgress.FetchingManifest(profile.label))
        
        // Fetch manifest and find matching entry
        val manifest = downloader.fetchManifest()
        val entry = manifest.findByDistroId(profile.id)
        
        if (entry == null) {
            emit(InstallProgress.Failed(profile.id, "No rootfs image found for ${profile.label}"))
            return@flow
        }
        
        // Download tarball preserving compression extension from URL
        val urlExt = entry.url.substringAfterLast('.').let { ext ->
            if (ext in listOf("xz", "gz", "bz2")) ".tar.$ext" else ".tar.gz"
        }
        val tarball = File(tmpDir, "${profile.id}$urlExt")
        
        emit(InstallProgress.Downloading(profile.label, 0))
        
        var downloadFailed = false
        downloader.download(entry, tarball).collect { progress ->
            when (progress) {
                is DownloadProgress.Starting -> {
                    emit(InstallProgress.Downloading(profile.label, 0))
                }
                is DownloadProgress.Downloading -> {
                    emit(InstallProgress.Downloading(profile.label, progress.percent))
                }
                is DownloadProgress.Completed -> {
                    emit(InstallProgress.DownloadComplete(profile.label, tarball))
                }
                is DownloadProgress.Failed -> {
                    downloadFailed = true
                    emit(InstallProgress.Failed(profile.id, progress.error))
                }
            }
        }
        
        if (downloadFailed) return@flow
        
        // Extract tarball
        emit(InstallProgress.Extracting(profile.label))
        
        val extractSuccess = extractRootfs(tarball, rootfsDir)
        
        // Clean up tarball
        tarball.delete()
        
        if (!extractSuccess) {
            emit(InstallProgress.Failed(profile.id, "Failed to extract rootfs"))
            return@flow
        }
        
        // Write metadata
        writeMetadata(profile)
        
        emit(InstallProgress.Installed(profile.id, rootfsDir))
    }.flowOn(Dispatchers.IO)
    
    /**
     * Remove an installed distro.
     */
    suspend fun removeDistro(distroId: String): Boolean = withContext(Dispatchers.IO) {
        val distroDir = File(distrosDir, distroId)
        if (distroDir.exists()) {
            distroDir.deleteRecursively()
        } else {
            true
        }
    }
    
    /**
     * Download a rootfs tarball synchronously (for auto-setup).
     * @return true if download succeeded
     */
    fun downloadDirect(
        entry: RootfsEntry,
        targetFile: File,
        onProgress: ((percent: Int?, detail: String) -> Unit)? = null,
    ): Boolean {
        return try {
            android.util.Log.d("RootfsManager", "downloadDirect: downloading ${entry.url} to ${targetFile.absolutePath}")
            kotlinx.coroutines.runBlocking {
                var result = false
                var lastPercent = -1
                var lastReportedBytes = 0L
                downloader.download(entry, targetFile).collect { progress ->
                    when (progress) {
                        is DownloadProgress.Downloading -> {
                            val mb = progress.bytesDownloaded / (1024f * 1024f)
                            if (progress.totalBytes > 0) {
                                val percent = progress.percent.coerceIn(0, 100)
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    val totalMb = progress.totalBytes / (1024f * 1024f)
                                    onProgress?.invoke(percent, "%.1f / %.1f MB".format(mb, totalMb))
                                }
                            } else if (progress.bytesDownloaded - lastReportedBytes >= 512 * 1024) {
                                lastReportedBytes = progress.bytesDownloaded
                                onProgress?.invoke(null, "%.1f MB downloaded".format(mb))
                            }
                        }
                        is DownloadProgress.Completed -> {
                            result = true
                            android.util.Log.d("RootfsManager", "downloadDirect: completed, size=${progress.bytesDownloaded}")
                            // Say it out loud. This archive is about to be extracted and its binaries
                            // run under proot, so whether anything vouched for it belongs in the log
                            // the user is already watching — not buried behind a blank hash field.
                            onProgress?.invoke(
                                null,
                                if (progress.verified) "checksum verified (sha256 ${progress.sha256.take(12)}…)"
                                else "downloaded WITHOUT a checksum — the manifest carried none (sha256 ${progress.sha256.take(12)}…)",
                            )
                        }
                        is DownloadProgress.Failed -> {
                            android.util.Log.e("RootfsManager", "downloadDirect: failed - ${progress.error}")
                        }
                        else -> {}
                    }
                }
                result
            }
        } catch (e: Exception) {
            android.util.Log.e("RootfsManager", "downloadDirect: exception", e)
            false
        }
    }

    /**
     * Extract a rootfs tarball to the target directory. Extraction is pure Kotlin: SELinux denies
     * hard-link creation in app data at targetSdk >= 30, and Ubuntu rootfs tarballs are full of
     * hard links, so a system `tar` pass always fails — each hard link is instead created for real
     * when possible and otherwise degraded to a *relative* symlink to its target (already extracted
     * earlier in the stream), which resolves correctly both on the host and inside proot.
     */
    fun extractRootfs(tarball: File, targetDir: File, isRootfs: Boolean = true): Boolean {
        return try {
            // A previous interrupted pass may have left a partial tree; start clean.
            if (targetDir.exists()) targetDir.deleteRecursively()
            targetDir.mkdirs()
            val name = tarball.name.lowercase()
            val raw = FileInputStream(tarball).buffered(1 shl 16)
            // Every decompressor reads (and validates) the header in its constructor, so a truncated
            // or misnamed archive throws HERE — before anything owns `raw`. Downloads are not
            // checksum-verified, so that is a reachable path, and each failed attempt would otherwise
            // strand the tarball's fd until the finalizer ran.
            val decompressed: InputStream = try {
                when {
                    name.endsWith(".tar.xz") || name.endsWith(".txz") -> XZInputStream(raw)
                    name.endsWith(".tar.bz2") || name.endsWith(".tbz2") -> BZip2CompressorInputStream(raw)
                    name.endsWith(".tar.gz") || name.endsWith(".tgz") -> GZIPInputStream(raw)
                    name.endsWith(".tar") -> raw
                    else -> GZIPInputStream(raw)
                }
            } catch (e: Throwable) {
                runCatching { raw.close() }
                throw e
            }
            var hardlinks = 0
            var symlinkedLinks = 0
            TarArchiveInputStream(decompressed).use { tin ->
                var entry = tin.nextTarEntry
                while (entry != null) {
                    val e = entry
                    val out = File(targetDir, e.name)
                    when {
                        e.isDirectory -> out.mkdirs()
                        e.isSymbolicLink -> {
                            out.parentFile?.mkdirs()
                            out.delete()
                            Os.symlink(e.linkName, out.absolutePath)
                        }
                        e.isLink -> { // hard link — target already extracted earlier in the stream
                            out.parentFile?.mkdirs()
                            out.delete()
                            hardlinks++
                            val target = File(targetDir, e.linkName)
                            if (!tryHardLink(target, out)) {
                                // This filesystem rejects hard links: use a relative symlink instead.
                                val rel = out.parentFile!!.toPath().relativize(target.toPath()).toString()
                                Os.symlink(rel, out.absolutePath)
                                symlinkedLinks++
                            }
                        }
                        e.isFile -> {
                            out.parentFile?.mkdirs()
                            out.delete()
                            FileOutputStream(out).use { fos -> tin.copyTo(fos, 1 shl 16) }
                            // Preserve the executable bit (any-execute); other bits don't matter under proot -0.
                            if ((e.mode and 0b1001001) != 0) out.setExecutable(true, false)
                        }
                        // char/block/fifo device nodes: skip (proot fakes /dev; app can't mknod).
                    }
                    entry = tin.nextTarEntry
                }
            }
            // A freshly extracted minimal image has no working DNS/host config and no system locale —
            // set both. Only for an actual rootfs: this unpacker also reads the projects and extensions
            // archives in a migration bundle, and writing /etc into one of those leaves a stray
            // `etc/resolv.conf` sitting in the user's projects folder.
            if (isRootfs) ensureRootfsConfig(targetDir)
            android.util.Log.d(
                "RootfsManager",
                "extractRootfs: OK ($hardlinks hard links, $symlinkedLinks converted to symlinks)",
            )
            true
        } catch (e: Exception) {
            android.util.Log.e("RootfsManager", "extractRootfs: failed", e)
            false
        }
    }

    /**
     * Write the minimal DNS/host config a proot guest needs for name resolution to work. The official
     * minimal `ubuntu-base` images (used for newer releases such as 26.04) ship /etc/resolv.conf as an
     * EMPTY 0-byte file — normally populated at boot by systemd-resolved/cloud-init, none of which run
     * under proot — so glibc falls back to 127.0.0.1:53 (nothing listening) and every `apt-get update`
     * dies with "Temporary failure resolving 'archive.ubuntu.com'". The fuller AnLinux image (used for
     * 24.04) pre-bakes `nameserver 8.8.8.8`, which is why it "just works" and 26.04 does not. Mirrors
     * what proot-distro/Termux do post-extraction. NB: apt sources are left alone — 26.04 arm64 serves
     * correctly from archive.ubuntu.com; only DNS is missing.
     *
     * Idempotent and safe on images that already carry working config: resolv.conf is (re)written only
     * when missing, empty, or lacking a nameserver; /etc/hosts only when empty/missing — so a user's own
     * resolver/hosts customization is preserved on self-heal. A dangling systemd-resolved symlink (as in
     * fuller images) is unlinked first so the write can't follow it to a dead target. Pure host-side
     * writes into the extracted tree (the rootfs is plain files under filesDir) — no proot round-trip and
     * no DNS needed to perform them. Android exposes no host /etc/resolv.conf to copy, so public
     * resolvers are used.
     *
     * @return true if the config is in place afterwards.
     */
    fun ensureRootfsNetworking(rootfsDir: File): Boolean {
        return try {
            val etc = File(rootfsDir, "etc").apply { mkdirs() }

            val resolv = File(etc, "resolv.conf")
            if (!isUsableResolvConf(resolv)) {
                // Don't write *through* a dangling systemd-resolved stub symlink — replace it.
                if (isSymlink(resolv)) resolv.delete()
                resolv.writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\nnameserver 8.8.4.4\n")
            }

            // Loopback names — cosmetic, but the minimal base ships /etc/hosts empty (0 bytes), which
            // makes sudo/hostname emit "unable to resolve host" noise. Only fill when empty/missing.
            val hosts = File(etc, "hosts")
            if (!isSymlink(hosts) && hosts.length() == 0L) {
                hosts.writeText("127.0.0.1 localhost\n::1 localhost ip6-localhost ip6-loopback\n")
            }

            // Deliberately NOT written: /etc/nsswitch.conf (ubuntu-base ships a correct one), apt
            // sources (26.04 arm64 correctly uses archive.ubuntu.com — rewriting to ports would break
            // it), and ca-certificates (apt uses http+GPG; TLS tools install it on demand).
            true
        } catch (e: Exception) {
            android.util.Log.e("RootfsManager", "ensureRootfsNetworking failed", e)
            false
        }
    }

    /** [ensureRootfsNetworking] and [ensureRootfsLocale]: the config every rootfs gets before use. */
    fun ensureRootfsConfig(rootfsDir: File): Boolean =
        ensureRootfsNetworking(rootfsDir) and ensureRootfsLocale(rootfsDir)

    /**
     * Give the rootfs a system locale: `LANG=C.UTF-8` in /etc/default/locale, which pam_env applies to
     * every `su` login — terminals, language servers and the sudo shim all enter that way. C.UTF-8
     * because it is the one locale a minimal image ships; a named one needs the `locales` package.
     * Written only when the file is missing or empty, so a locale the user set (`update-locale`) stays.
     * A dangling link is replaced, as with resolv.conf: the 24.04 image links the file to an
     * /etc/locale.conf that nothing creates.
     */
    fun ensureRootfsLocale(rootfsDir: File): Boolean {
        return try {
            val locale = File(rootfsDir, "etc/default/locale")
            if (isSymlink(locale) && !locale.exists()) locale.delete()
            if (!isSymlink(locale) && locale.length() == 0L) {
                locale.parentFile?.mkdirs()
                locale.writeText("LANG=C.UTF-8\n")
            }
            true
        } catch (e: Exception) {
            android.util.Log.e("RootfsManager", "ensureRootfsLocale failed", e)
            false
        }
    }

    /** A resolv.conf is usable only if it is a real (non-symlink) file with at least one nameserver. */
    private fun isUsableResolvConf(f: File): Boolean =
        !isSymlink(f) && f.isFile &&
            runCatching {
                f.readText().lineSequence().any {
                    val t = it.trim()
                    t.startsWith("nameserver") && t.removePrefix("nameserver").isNotBlank()
                }
            }.getOrDefault(false)

    private fun isSymlink(f: File): Boolean =
        runCatching { java.nio.file.Files.isSymbolicLink(f.toPath()) }.getOrDefault(false)

    private fun tryHardLink(target: File, link: File): Boolean = try {
        Os.link(target.absolutePath, link.absolutePath)
        true
    } catch (e: ErrnoException) {
        false
    }

    /**
     * Write installation metadata for a distro profile.
     */
    fun writeMetadata(profile: DistroProfile) {
        val distroDir = File(distrosDir, profile.id)
        distroDir.mkdirs()
        val metadata = File(distroDir, "metadata.json")
        metadata.writeText("""
            {
                "distroId": "${profile.id}",
                "label": "${profile.label}",
                "arch": "${profile.arch.rootfsKey}",
                "installedAt": ${System.currentTimeMillis()},
                "version": "1.1"
            }
        """.trimIndent())
    }

    /**
     * Read the recorded architecture for an installed distro, or null if unknown
     * (e.g. a legacy install written before arch metadata existed).
     */
    fun readMetadataArch(distroId: String): Arch? {
        val metadata = File(File(distrosDir, distroId), METADATA_FILE)
        if (!metadata.exists()) return null
        return runCatching {
            val match = Regex("\"arch\"\\s*:\\s*\"([^\"]+)\"").find(metadata.readText())
            Arch.fromKey(match?.groupValues?.get(1))
        }.getOrNull()
    }

    /** Metadata filename for installation info */
    companion object {
        const val METADATA_FILE = "metadata.json"
    }
}

/** Represents an installed distro. */
data class InstalledDistro(
    val id: String,
    val rootfsPath: File,
    val installDate: Long,
)

/** Progress events for distro installation. */
sealed interface InstallProgress {
    data class FetchingManifest(val distroLabel: String) : InstallProgress
    data class Downloading(val distroLabel: String, val percent: Int) : InstallProgress
    data class DownloadComplete(val distroLabel: String, val file: File) : InstallProgress
    data class Extracting(val distroLabel: String) : InstallProgress
    data class Installed(val distroId: String, val rootfsPath: File) : InstallProgress
    data class AlreadyInstalled(val distroId: String) : InstallProgress
    data class Failed(val distroId: String, val error: String) : InstallProgress
}
