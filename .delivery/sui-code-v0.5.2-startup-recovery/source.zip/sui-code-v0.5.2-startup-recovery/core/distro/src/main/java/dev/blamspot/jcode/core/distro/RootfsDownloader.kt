package dev.blamspot.jcode.core.distro

import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.yield

/**
 * Downloads rootfs tarballs from a configurable server with progress streaming.
 * Supports SHA256 verification and resumable downloads.
 */
class RootfsDownloader(
    private val baseUrl: String = DEFAULT_ROOTFS_BASE_URL,
    private val tmpDir: File,
) {
    /**
     * Fetch the manifest of available rootfs images.
     * The manifest is a simple text/JSON file listing available distros.
     */
    suspend fun fetchManifest(): RootfsManifest {
        return try {
            val url = URL("$baseUrl/manifest.json")
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 30_000
            connection.readTimeout = 30_000
            
            val response = connection.inputStream.bufferedReader().readText()
            parseManifest(response)
        } catch (e: Exception) {
            // Return a default manifest if fetch fails
            RootfsManifest.default()
        }
    }
    
    /**
     * Download a rootfs tarball with progress reporting.
     * 
     * @param entry The rootfs entry to download
     * @param targetFile Where to save the downloaded tarball
     * @return Flow of download progress events
     */
    fun download(
        entry: RootfsEntry,
        targetFile: File,
    ): Flow<DownloadProgress> = flow {
        emit(DownloadProgress.Starting(entry.name, entry.sizeBytes))
        
        val url = URL(entry.url)
        val connection = url.openConnection() as HttpURLConnection
        connection.connectTimeout = 30_000
        connection.readTimeout = 60_000
        
        // Prefer the server's content length (exact) over the manifest's sizeBytes (an estimate
        // that would make the percent drift past 100).
        val totalSize = connection.contentLengthLong.takeIf { it > 0 }
            ?: entry.sizeBytes.takeIf { it > 0 }
            ?: -1L
        
        targetFile.parentFile?.mkdirs()
        
        val digest = MessageDigest.getInstance("SHA-256")
        var bytesDownloaded = 0L
        
        connection.inputStream.buffered().use { input ->
            FileOutputStream(targetFile).use { output ->
                val buffer = ByteArray(8192)
                var bytesRead: Int
                
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    yield() // Check for cancellation
                    
                    output.write(buffer, 0, bytesRead)
                    digest.update(buffer, 0, bytesRead)
                    bytesDownloaded += bytesRead
                    
                    if (totalSize > 0) {
                        val percent = (bytesDownloaded * 100 / totalSize).toInt()
                        emit(DownloadProgress.Downloading(
                            name = entry.name,
                            bytesDownloaded = bytesDownloaded,
                            totalBytes = totalSize,
                            percent = percent,
                        ))
                    } else {
                        emit(DownloadProgress.Downloading(
                            name = entry.name,
                            bytesDownloaded = bytesDownloaded,
                            totalBytes = -1,
                            percent = -1,
                        ))
                    }
                }
            }
        }
        
        // A rootfs is extracted and then *executed* under proot, so a mismatch is not a warning —
        // the file is deleted and the download fails. What a blank hash means is reported rather
        // than skipped silently: `verified` travels with the result so the caller can say so in the
        // setup log, which is the only place a user could ever notice.
        val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
        if (entry.sha256.isNotBlank() && actualHash != entry.sha256) {
            targetFile.delete()
            emit(DownloadProgress.Failed(
                name = entry.name,
                error = "SHA256 mismatch: expected ${entry.sha256}, got $actualHash",
            ))
            return@flow
        }

        emit(DownloadProgress.Completed(
            name = entry.name,
            file = targetFile,
            bytesDownloaded = bytesDownloaded,
            verified = entry.sha256.isNotBlank(),
            sha256 = actualHash,
        ))
    }.flowOn(Dispatchers.IO)
    
    private fun parseManifest(json: String): RootfsManifest {
        return runCatching {
            val root = JSONObject(json)
            val entriesJson = root.optJSONArray("entries") ?: JSONArray()
            val entries = buildList {
                for (index in 0 until entriesJson.length()) {
                    val item = entriesJson.optJSONObject(index) ?: continue
                    val id = item.optString("id").ifBlank {
                        item.optString("distroId").ifBlank {
                            item.optString("installRecipe")
                                .replace(':', '-')
                                .ifBlank { item.optString("name") }
                        }
                    }
                    val name = item.optString("name").ifBlank { item.optString("label") }
                    val url = item.optString("url")
                    if (id.isBlank() || name.isBlank() || url.isBlank()) continue
                    add(
                        RootfsEntry(
                            distroId = id,
                            name = name,
                            url = url,
                            sha256 = item.optString("sha256"),
                            sizeBytes = item.optLong("sizeBytes").takeIf { it > 0L }
                                ?: item.optLong("size").takeIf { it > 0L }
                                ?: -1L,
                            installRecipe = item.optString("installRecipe").ifBlank {
                                item.optString("recipe").ifBlank { id.replace('-', ':') }
                            },
                            approxFootprint = item.optString("approxFootprint").ifBlank {
                                item.optString("footprint").ifBlank { "~2.0 GB" }
                            },
                            arch = Arch.fromKey(item.optString("arch")) ?: Arch.ARM64,
                        ),
                    )
                }
            }
            if (entries.isEmpty()) RootfsManifest.default() else RootfsManifest(entries)
        }.getOrElse {
            RootfsManifest.default()
        }
    }
    
    companion object {
        /**
         * Default rootfs sources using existing online repositories.
         * 
         * Sources:
         * - AnLinux Resources: Community-maintained rootfs images on GitHub
         *   These are tested and verified to work with proot on Android.
         * - Debian: From AnLinux Resources on GitHub
         */
        const val DEFAULT_ROOTFS_BASE_URL = "https://distro.jcode.dev/rootfs"
        
        // --- Ubuntu 24.04 LTS (Noble) ---

        /**
         * Ubuntu 24.04 ARM64 rootfs from AnLinux Resources (tar.xz). Native on arm64 phones;
         * this is the proven default image. Size: ~40MB compressed.
         */
        const val UBUNTU_24_04_ARM64_URL = "https://raw.githubusercontent.com/EXALAB/Anlinux-Resources/master/Rootfs/Ubuntu/arm64/ubuntu-rootfs-arm64.tar.xz"

        // --- Ubuntu 26.04 LTS --- (official Ubuntu cdimage minimal base, tar.gz)

        /** Ubuntu 26.04 base (arm64) — native on arm64 phones. */
        const val UBUNTU_26_04_ARM64_URL = "https://cdimage.ubuntu.com/ubuntu-base/releases/26.04/release/ubuntu-base-26.04-base-arm64.tar.gz"
    }
}

/** Progress events for rootfs download. */
sealed interface DownloadProgress {
    data class Starting(val name: String, val expectedSize: Long) : DownloadProgress
    data class Downloading(
        val name: String,
        val bytesDownloaded: Long,
        val totalBytes: Long,
        val percent: Int,
    ) : DownloadProgress
    data class Completed(
        val name: String,
        val file: File,
        val bytesDownloaded: Long,
        /** True when the manifest carried a checksum and the download matched it. */
        val verified: Boolean = false,
        /** The hash actually computed, so an unverified download can still be pinned later. */
        val sha256: String = "",
    ) : DownloadProgress
    data class Failed(val name: String, val error: String) : DownloadProgress
}

/** Manifest of available rootfs images. */
data class RootfsManifest(
    val entries: List<RootfsEntry>,
) {
    fun findByDistroId(id: String): RootfsEntry? {
        return entries.firstOrNull { it.distroId == id }
    }
    
    companion object {
        /**
         * The fallback manifest, used only when the served one cannot be fetched.
         *
         * **These entries carry no checksum, so downloads through this path are unverified**, and
         * `RootfsManager` says so in the setup log. They are blank on purpose rather than by
         * oversight: one URL is a third-party repository's `master` branch and the other is an
         * Ubuntu release directory that is updated in place, so any hash pinned here would go stale
         * on somebody else's schedule and break first-run setup for everyone with a mismatch.
         *
         * The served manifest is where checksums belong — it can be updated in step with whatever
         * it points at. The fix for this gap is therefore to keep that manifest reachable and
         * populated, not to pin a moving target here.
         */
        fun default(): RootfsManifest = RootfsManifest(
            entries = listOf(
                RootfsEntry(
                    distroId = "ubuntu-24.04",
                    name = "Ubuntu 24.04 LTS (ARM64)",
                    url = RootfsDownloader.UBUNTU_24_04_ARM64_URL,
                    sha256 = "",
                    sizeBytes = 40_000_000L, // ~40MB compressed
                    installRecipe = "ubuntu:24.04",
                    approxFootprint = "~2.5 GB",
                    arch = Arch.ARM64,
                ),
                RootfsEntry(
                    distroId = "ubuntu-26.04",
                    name = "Ubuntu 26.04 LTS (ARM64)",
                    url = RootfsDownloader.UBUNTU_26_04_ARM64_URL,
                    sha256 = "",
                    sizeBytes = 30_000_000L, // ~30MB compressed (minimal base)
                    installRecipe = "ubuntu:26.04",
                    approxFootprint = "~2.5 GB",
                    arch = Arch.ARM64,
                ),
            ),
        )
    }

    fun profiles(): List<DistroProfile> {
        return entries.map { entry ->
            DistroProfile(
                id = entry.distroId,
                label = entry.name,
                installRecipe = entry.installRecipe,
                approxFootprint = entry.approxFootprint,
                arch = entry.arch,
            )
        }
    }
}

/** A single rootfs image entry. */
data class RootfsEntry(
    val distroId: String,
    val name: String,
    val url: String,
    val sha256: String,
    val sizeBytes: Long,
    val installRecipe: String,
    val approxFootprint: String,
    /** CPU architecture of this rootfs. Foreign-arch images run under QEMU user-mode. */
    val arch: Arch = Arch.ARM64,
)
