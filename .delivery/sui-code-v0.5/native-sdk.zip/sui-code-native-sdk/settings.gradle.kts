rootProject.name = "sui-code-native-sdk"
