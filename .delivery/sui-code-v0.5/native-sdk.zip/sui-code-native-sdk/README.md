# sui-code Native SDK 0.3 / Core API 3

This standalone JVM SDK copies the exact production Kotlin verifier, independent loaders, authorization API, native recipe/dataflow interpreter and design model. API-SOURCE-SHA256SUMS records byte identity. It does not emulate Android services or embed runtimes.

With JDK21 (Android SDK is not required):

```sh
./gradlew classes
./gradlew run --args="docs/specifications/examples/packages/minimal.suic"
./gradlew run --args="docs/specifications/examples/packages/minimal-kit.suik"
# Must fail with E_BOUNDARY:
./gradlew run --args="docs/specifications/examples/packages/illegal-plugin.suic"
```

Build a local development package with `python3 tools/sui_packages/pack.py SOURCE OUTPUT.suic` or `.suik`. The provided examples include actual runnable Basic resources and a native interactive statistics Kit. Read both formal specifications in docs/specifications before adding capabilities. Advanced/special features belong in `.suik`.

PackageTool verifies SHA-256 and any present signature; the standalone CLI does not pin a publisher, so its trust label is unverified. The Android app pins native-library/official-p256.der and separately verifies the official library. Do not add a key to a trust store merely because a package includes it. Official private keys, Android signing keys, installed Ubuntu and user data are excluded.

LSP/DAP/terminal/UI operation backends are implemented in the complete Android source distribution, not simulated in this SDK. Installing the exact same package in Package Manager still requires review and permissions. Linux protocol validity is not an ARM64 tablet acceptance result.
