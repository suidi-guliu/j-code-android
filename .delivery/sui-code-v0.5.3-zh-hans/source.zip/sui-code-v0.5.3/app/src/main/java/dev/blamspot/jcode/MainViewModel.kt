package dev.blamspot.jcode

import kotlinx.serialization.json.jsonPrimitive

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStoreFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.blamspot.jcode.backend.BackendSessionKind
import dev.blamspot.jcode.backend.SessionRegistry
import dev.blamspot.jcode.core.config.ConfigScope
import dev.blamspot.jcode.core.config.ConfigService
import dev.blamspot.jcode.core.config.ConfigServiceLocator
import dev.blamspot.jcode.core.editor.Caret
import dev.blamspot.jcode.core.buffer.EditTx
import dev.blamspot.jcode.core.config.EffectiveConfig
import dev.blamspot.jcode.core.distro.DistroProfile
import dev.blamspot.jcode.core.distro.RootfsArchiver
import dev.blamspot.jcode.core.distro.WorkspaceHostPaths
import dev.blamspot.jcode.core.distro.DebugEngineAction
import dev.blamspot.jcode.core.distro.DebugEngineCatalog
import dev.blamspot.jcode.core.distro.LspCatalogAction
import dev.blamspot.jcode.core.distro.LspServerCatalog
import dev.blamspot.jcode.debug.DebugController
import dev.blamspot.jcode.core.distro.SdkCatalogAction
import dev.blamspot.jcode.core.distro.DistroService
import dev.blamspot.jcode.core.distro.DistroServiceLocator
import dev.blamspot.jcode.core.distro.GuestProcessTree
import dev.blamspot.jcode.ext.NativeExtensionLoader
import dev.blamspot.jcode.vdevice.VirtualDeviceBridge
import dev.blamspot.jcode.core.distro.adb.AdbBridge
import dev.blamspot.jcode.core.distro.adb.AdbBridgeLocator
import dev.blamspot.jcode.core.distro.adb.AdbBridgeState
import dev.blamspot.jcode.core.distro.adb.AdbHostClient
import dev.blamspot.jcode.core.buffer.offsetToUtf16Position
import dev.blamspot.jcode.core.buffer.utf16PositionToOffset
import dev.blamspot.jcode.core.editor.EditorLanguageAction
import dev.blamspot.jcode.core.editor.completion.CompletionItem
import dev.blamspot.jcode.core.lsp.Diagnostic as LspDiagnostic
import dev.blamspot.jcode.core.lsp.DiagnosticSeverity as LspDiagnosticSeverity
import dev.blamspot.jcode.core.lsp.LocationResult
import dev.blamspot.jcode.core.lsp.LspState
import dev.blamspot.jcode.core.lsp.TextEditResult
import dev.blamspot.jcode.core.lsp.WorkspaceEditResult
import dev.blamspot.jcode.editor.toEditorItem
import dev.blamspot.jcode.lsp.LspFeature
import dev.blamspot.jcode.lsp.LspLocationEntry
import dev.blamspot.jcode.lsp.LspLocationPicker
import dev.blamspot.jcode.lsp.LspRenameRequest
import dev.blamspot.jcode.core.resource.ResourceManager
import dev.blamspot.jcode.core.resource.ResourceManagerLocator
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import dev.blamspot.jcode.design.AndroidRunTarget
import dev.blamspot.jcode.design.BottomBarVisibility
import dev.blamspot.jcode.design.ExtraKeysVisibility
import dev.blamspot.jcode.design.FileIconSet
import dev.blamspot.jcode.design.IconPackLoader
import dev.blamspot.jcode.design.HeaderActionButton
import dev.blamspot.jcode.core.diag.DiagLevel
import dev.blamspot.jcode.core.diag.DiagnosticLog
import dev.blamspot.jcode.design.SettingsDefaults
import dev.blamspot.jcode.design.TabColoring
import dev.blamspot.jcode.design.TabMaxSize
import dev.blamspot.jcode.design.ThemeMode
import dev.blamspot.jcode.design.UiIconSet
import dev.blamspot.jcode.design.VolumeKeyAction
import dev.blamspot.jcode.design.randomTabColor
import dev.blamspot.jcode.design.tabColorFromHex
import dev.blamspot.jcode.design.tabColorToHex
import dev.blamspot.jcode.editor.SyntaxHighlighter
import dev.blamspot.jcode.feature.editor.pane.EditorGroup
import dev.blamspot.jcode.feature.editor.pane.EditorPageKind
import dev.blamspot.jcode.feature.editor.pane.EditorTab
import dev.blamspot.jcode.feature.marketplace.IconPackLayout
import dev.blamspot.jcode.feature.marketplace.ExtensionActivation
import dev.blamspot.jcode.feature.marketplace.enabledIn
import dev.blamspot.jcode.feature.marketplace.ExtensionDeps
import dev.blamspot.jcode.feature.marketplace.ExtensionInstaller
import dev.blamspot.jcode.feature.marketplace.ExtensionType
import dev.blamspot.jcode.feature.marketplace.InstalledExtension
import dev.blamspot.jcode.feature.marketplace.isUpdateAvailable
import dev.blamspot.jcode.feature.marketplace.languageFor
import dev.blamspot.jcode.feature.marketplace.MarketplaceEntry
import dev.blamspot.jcode.feature.marketplace.MarketplaceServiceLocator
import dev.blamspot.jcode.feature.marketplace.ProjectTemplate
import dev.blamspot.jcode.feature.marketplace.TemplateCatalog
import dev.blamspot.jcode.feature.marketplace.TemplateScaffolder
import dev.blamspot.jcode.feature.marketplace.nativeGuestModule
import dev.blamspot.jcode.workbench.SetupTerminalRunner
import dev.blamspot.jcode.fs.FsKind
import dev.blamspot.jcode.fs.FsNode
import dev.blamspot.jcode.fs.FsPath
import dev.blamspot.jcode.fs.copyFolderToLocal
import dev.blamspot.jcode.fs.copyLocalTreeToDocumentTree
import dev.blamspot.jcode.fs.folderDisplayName
import dev.blamspot.jcode.fs.Project
import dev.blamspot.jcode.fs.ProjectKind
import dev.blamspot.jcode.fs.RecentEntity
import dev.blamspot.jcode.fs.scanFolderForImport
import dev.blamspot.jcode.fs.TrashSource
import dev.blamspot.jcode.fs.Workspace
import dev.blamspot.jcode.fs.WorkspaceCrumb
import dev.blamspot.jcode.fs.WorkspaceManager
import dev.blamspot.jcode.fs.WorkspaceNodeType
import dev.blamspot.jcode.fs.WorkspaceServiceLocator
import dev.blamspot.jcode.run.ProjectRunner
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject

/** Version of the JCode <-> extension request/event API served by this app build. Bump when route
 *  families or envelope semantics change; extensions gate on it via their manifest's api.minApiVersion. */
const val EXTENSION_API_VERSION = 1

/** Upper bound on per-push explorer decoration/submodule entries — a runaway or malicious extension
 *  must not be able to grow the decoration maps without limit. */
const val MAX_EXPLORER_DECORATIONS = 20_000

/** Throttle for the "Android killed the distro" prompt — one kill takes every terminal at once. */
private const val PROCESS_LIMIT_PROMPT_INTERVAL_MS = 60_000L

/**
 * `{{extensionDir}}` or `{{some.setting.key}}` inside an autocomplete's suggest command.
 *
 * Both braces of the closing pair are escaped. Android's regex engine is ICU, not the JDK's, and it
 * rejects a bare `}` that desktop Java quietly accepts as a literal — so the unescaped form compiles
 * everywhere it is written and throws on the only machine that runs it.
 */
private val SUGGEST_PLACEHOLDER = Regex("""\{\{([A-Za-z0-9_.\-]+)\}\}""")

/** A settings field is waiting on this; a tool that has not answered by now is not going to. */
private const val SUGGEST_TIMEOUT_MS = 15_000L

/** Enough to pick from. A tool that lists thousands is not offering a choice, it is offering a wall. */
private const val SUGGEST_LIMIT = 200

/**
 * Process-singleton holder for the app-level UI-preferences DataStore. A DataStore must be created
 * exactly once per file per process; constructing a second one (e.g. when MainViewModel is rebuilt
 * after the Activity is recreated) throws "multiple DataStores active for the same file".
 */
/** (lastModified, size) fingerprint used to detect external edits to an open file. */
private data class DiskSignature(val lastModified: Long, val size: Long)

/** Result of probing + preparing a file to open, computed off the main thread (see openLocalFile). */
private sealed interface OpenPrep {
    data object Missing : OpenPrep
    data object Image : OpenPrep
    data object Binary : OpenPrep
    data class Text(val tab: EditorTab, val signature: DiskSignature?) : OpenPrep
}

private object UiPreferencesStore {
    @Volatile
    private var instance: DataStore<Preferences>? = null

    fun get(context: Context): DataStore<Preferences> =
        instance ?: synchronized(this) {
            instance ?: PreferenceDataStoreFactory.create {
                context.applicationContext.preferencesDataStoreFile("ui-preferences.preferences_pb")
            }.also { instance = it }
        }
}

/** The user's choice in the "unsaved changes" prompt shown when closing editor tabs. */
enum class EditorCloseChoice { SAVE, DISCARD, CLOSE_SAVED, CANCEL }

/** Drives the editor "unsaved changes" dialog: the titles of the dirty tabs about to be closed. */
/**
 * [savedCount] is how many tabs in the closing set are already saved. It is zero whenever a single
 * dirty tab is closed, and that is what hides the prompt's "Close Saved" action — with nothing clean
 * in the set it would close nothing at all.
 */
data class PendingEditorClose(val dirtyTitles: List<String>, val savedCount: Int)

/** Live state of an external-folder import, driving the progress modal. During [ImportPhase.Scanning]
 *  the total is unknown ([total] == 0 → indeterminate); during [ImportPhase.Copying], [done]/[total]
 *  files gives a determinate bar. */
enum class ImportPhase { Scanning, Copying }

data class ImportProgress(
    val label: String,
    val phase: ImportPhase,
    val done: Int = 0,
    val total: Int = 0,
)

/** A folder awaiting the Project/Workspace choice: opened in place on managed storage, or copied into
 *  /sources and awaiting adoption. [label] names it in the dialog. */
sealed interface PendingFolderType {
    val label: String

    data class OpenInPlace(val path: FsPath) : PendingFolderType {
        override val label: String get() = path.displayName
    }

    data class AdoptStaged(val staged: File) : PendingFolderType {
        override val label: String get() = staged.name
    }
}

/** An actionable prompt the shell shows as a snackbar with a single button. */
sealed interface WorkbenchPrompt {
    /** A change only applies on a fresh process — offer to restart the app. */
    data class RestartApp(val message: String) : WorkbenchPrompt

    /**
     * An uninstalled extension whose views are still on screen — offer to clear them.
     *
     * Distinct from [RestartApp], which is what a plugin that loaded *code* into this process needs:
     * a web extension leaves nothing resident, so closing what it has open finishes the job without
     * taking the workbench down with it.
     */
    data class ReloadExtension(val id: String, val message: String) : WorkbenchPrompt

    /** Android killed the distro's processes; point the user at the setting that explains it. */
    data object ProcessLimit : WorkbenchPrompt

    /** A toolchain was installed into the selected distro while open terminals are still running the
     *  one they were spawned against, where it can never appear. */
    data class StaleTerminalDistro(val sessionDistro: String, val installedInto: String) : WorkbenchPrompt
}

/** An updated extension awaiting a reload; surfaced as a compact banner atop the Extensions panel. */
data class PendingReload(val id: String, val name: String)

/**
 * Where the virtual device is drawn, or that there is nowhere to draw it.
 *
 * [None] is not a third placement but the absence of one: no installed pack provides a device, so
 * there is nothing to move and nothing to open. It is distinct from [Tab] because as a Boolean the
 * pack being *uninstalled* was indistinguishable from its setting being changed to "tab" — and the
 * workbench answered an uninstall by opening the very device it had just removed.
 */
enum class VirtualDeviceSurface { None, Drawer, Tab }

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val workspaceManager: WorkspaceManager = WorkspaceServiceLocator.workspaceManager(application)
    val configService: ConfigService = ConfigServiceLocator.configService()
    val distroService: DistroService = DistroServiceLocator.distroService(application)
    val adbBridge: AdbBridge = AdbBridgeLocator.adbBridge(application)
    val resourceManager: ResourceManager = ResourceManagerLocator.resourceManager(application)
    val currentWorkspace: StateFlow<Workspace?> = workspaceManager.currentWorkspace
    val breadcrumb: StateFlow<List<WorkspaceCrumb>> = workspaceManager.breadcrumb

    private val appContext: Context = application.applicationContext
    val templateCatalog: TemplateCatalog = MarketplaceServiceLocator.templateCatalog(application)
    private val templateScaffolder: TemplateScaffolder = MarketplaceServiceLocator.templateScaffolder(application)
    private val extensionInstaller = MarketplaceServiceLocator.extensionInstaller(application)
    val scaffoldState = templateScaffolder.state

    /** Shared "Setup" terminal in the right drawer that runs toolchain installs and scaffolds. */
    private var nativeSourceId: String? = null
    private fun nativeSourceTab(): EditorTab? = _editorGroup.value.activeTab?.takeIf { !it.isPage }
        ?: _editorGroup.value.tabs.firstOrNull { it.id==nativeSourceId && !it.isPage }
    val nativePackages = dev.suicode.nativehost.NativePackageHost.get(appContext)
    val javaQuickRun = JavaQuickRunController(appContext, distroService, viewModelScope, ::emitMessage)

    fun quickRunActiveFile(repeatCount: Int): Boolean {
        val tab = _editorGroup.value.activeTab ?: return false
        if (tab.isPage || tab.editorState == null) return false
        return javaQuickRun.start(tab.filePath, repeatCount) { saveTabAwait(tab) }
    }

    val setupTerminalRunner = SetupTerminalRunner.get(appContext, distroService)

    private val _runTerminalCompletions = MutableSharedFlow<Pair<String, Int>>(extraBufferCapacity = 16)

    /** (sessionId, exitCode) for every terminal task that reported completion via OSC 7713. The
     *  workbench consumes this to mark a run finished (done/killed) when the command bound to its
     *  terminal exits — a run config binds to its single command's process. */
    val runTerminalCompletions: SharedFlow<Pair<String, Int>> = _runTerminalCompletions.asSharedFlow()

    init {
        nativePackages.onDeactivated = { id -> viewModelScope.launch(Dispatchers.Main.immediate) { javaQuickRun.stopPackage(id); debugController.stopPackage(id) } }
        TerminalSessionHost.manager(appContext).onTaskComplete = { sessionId, payload ->
            setupTerminalRunner.handleTaskComplete(sessionId, payload)
            javaQuickRun.complete(sessionId, payload)
            _runTerminalCompletions.tryEmit(sessionId to (payload.substringAfter(';').trim().toIntOrNull() ?: -1))
        }
        TerminalSessionHost.manager(appContext).onTaskProgress = setupTerminalRunner::handleTaskProgress
        distroService.interactiveJavaRunner = { label, script, timeoutMs, distroId ->
            setupTerminalRunner.run(label, script, null, "root", timeoutMs, focus = true, expectedDistroId = distroId)
        }
        distroService.interactiveCatalogRunner = { label, script, timeoutMs, onProgress ->
            setupTerminalRunner.run(
                label = label,
                script = script,
                workdir = null,
                asUser = "root",
                timeoutMs = timeoutMs,
                onProgress = onProgress,
            )
        }
        templateScaffolder.interactiveExec = { label, command, workdir, timeoutMs ->
            setupTerminalRunner.run(
                label = label,
                script = command,
                workdir = workdir,
                asUser = distroService.environmentState.value.runtime.user,
                timeoutMs = timeoutMs,
            )
        }
    }

    private val _templates = MutableStateFlow<List<ProjectTemplate>>(emptyList())
    val templates: StateFlow<List<ProjectTemplate>> = _templates.asStateFlow()

    /** Extensions currently installed under the app's install root (templates + language packs). */
    private val _installedExtensions = MutableStateFlow<List<InstalledExtension>>(emptyList())
    val installedExtensions: StateFlow<List<InstalledExtension>> = _installedExtensions
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.Eagerly, emptyList())

    /** Extensions available in the remote marketplace index (populated on demand). The public,
     *  UI-facing list is [marketplaceEntries] below — it folds in custom-source update entries and so
     *  is declared after the source state it depends on. */
    private val _marketplaceEntries = MutableStateFlow<List<MarketplaceEntry>>(emptyList())

    /** True while a marketplace fetch / install is in flight. */
    private val _marketplaceBusy = MutableStateFlow(false)
    val marketplaceBusy: StateFlow<Boolean> = _marketplaceBusy.asStateFlow()

    /** Per-extension install phase ("Installing…", "Installing required tools…", "Verifying…"),
     *  keyed by extension id, shown on the detail chip and list rows while an install runs. */
    private val _extensionInstallPhases = MutableStateFlow<Map<String, String>>(emptyMap())
    val extensionInstallPhases: StateFlow<Map<String, String>> = _extensionInstallPhases.asStateFlow()

    private fun setExtensionPhase(id: String, phase: String?) {
        _extensionInstallPhases.value =
            if (phase == null) _extensionInstallPhases.value - id
            else _extensionInstallPhases.value + (id to phase)
    }

    /** Re-scan installed extensions and refresh the available templates. */
    fun refreshInstalledExtensions() {
        // Keep legacy data on disk for recovery, but never discover or activate its code.
        _installedExtensions.value = emptyList()
        _templates.value = listOf(ProjectTemplate(id = "empty", name = "Empty Project", description = "A blank project folder.")) +
            nativePackages.templates().map { ProjectTemplate(id=it.id,name=it.title,description=it.description) }
    }

    // Extensions updated this session that are waiting for a reload — shown as a compact banner at
    // the top of the Extensions panel. Cleared per-id on reload.
    private val _pendingReload = MutableStateFlow<List<PendingReload>>(emptyList())
    val pendingReload: StateFlow<List<PendingReload>> = _pendingReload.asStateFlow()

    private fun markPendingReload(id: String, name: String) {
        _pendingReload.update { list -> list.filterNot { it.id == id } + PendingReload(id, name) }
    }

    /** Reload an extension's live webviews with its freshly-installed code (from the panel banner).
     *  A plain update leaves an already-open extension tab running the OLD bundle; a `reload` event
     *  makes each of that extension's live [ExtensionWebViewPage]s re-fetch the updated on-disk page,
     *  and the SCM/background host is torn down (no-op otherwise) so it too recreates fresh. */
    fun reloadExtension(id: String) {
        _extensionEvents.tryEmit("reload" to JSONObject().put("extensionId", id).toString())
        runCatching { dev.blamspot.jcode.workbench.ScmWebViewHolder.destroy(id) }
        _pendingReload.update { list -> list.filterNot { it.id == id } }
    }

    /** Reload every extension awaiting one (the banner's "Reload" button). */
    fun reloadPendingExtensions() {
        _pendingReload.value.map { it.id }.forEach { reloadExtension(it) }
    }

    /** Whether [id] still has something of its own on screen: a live host, a `.vsix` session, or a
     *  page tab. Asked after an uninstall, where each of those is a view of an extension that is
     *  no longer installed and goes on working until something takes it down. */
    private fun hasLiveSurfaces(id: String): Boolean =
        id in liveExtensionHosts ||
            dev.blamspot.jcode.workbench.ScmWebViewHolder.get(id) != null ||
            dev.blamspot.jcode.workbench.VsixViewHolder.get(id) != null ||
            _editorGroup.value.tabs.any { it.id.startsWith(EXT_APP_PREFIX + id) || it.id.startsWith(VSIX_PANEL_PREFIX + id) }

    /**
     * Close what an uninstalled extension still has open (the "Reload" on its removal snackbar).
     *
     * Not [reloadExtension]: that tells a live page to re-read its extension off disk, and for one
     * that has just been removed there is nothing to re-read — the page would reload into a 404 and
     * sit there. What a removed extension needs is for its surfaces to go.
     *
     * The extension's *detail* page deliberately survives, the same way its source attribution does:
     * it is the page the uninstall was pressed on, and it keeps a working Install.
     */
    fun unloadRemovedExtension(id: String) {
        viewModelScope.launch(Dispatchers.Main) {
            liveExtensionHosts.remove(id)
            runCatching { dev.blamspot.jcode.workbench.ScmWebViewHolder.destroy(id) }
            runCatching { dev.blamspot.jcode.workbench.VsixViewHolder.destroy(id) }
            val open = _editorGroup.value.tabs
                .filter { it.id.startsWith(EXT_APP_PREFIX + id) || it.id.startsWith(VSIX_PANEL_PREFIX + id) }
                .map { it.id }
                .toSet()
            if (open.isNotEmpty()) requestCloseEditorTabs(open, activate = null)
            _pendingReload.update { list -> list.filterNot { it.id == id } }
        }
    }

    /** Actionable prompts surfaced as a snackbar with a button (restart the app). */
    private val _prompts = MutableSharedFlow<WorkbenchPrompt>(extraBufferCapacity = 4)
    val prompts = _prompts.asSharedFlow()

    private var lastProcessLimitPromptAt = 0L

    /**
     * A terminal's process tree was killed from outside the app (see
     * [dev.blamspot.jcode.core.term.TerminalSessionManager.onExternalKill]). One kill takes every session down
     * at once, so the prompt is throttled — otherwise the user gets a snackbar per dead terminal.
     */
    fun reportExternalProcessKill() {
        val now = System.currentTimeMillis()
        if (now - lastProcessLimitPromptAt < PROCESS_LIMIT_PROMPT_INTERVAL_MS) return
        lastProcessLimitPromptAt = now
        _prompts.tryEmit(WorkbenchPrompt.ProcessLimit)
    }

    /**
     * Install an extension package the user picked — `.jext` or `.vsix`, told apart by what is
     * inside it rather than by its name (a file from SAF often arrives without a usable extension).
     *
     * One entry point for both, because from the user's side they are one act: bringing in an
     * extension the marketplace does not publish. Neither is verified, and both run code in the
     * Linux runtime, so the picker sits behind a trust warning either way.
     *
     * An unsigned package installs like any other and says so afterwards. Nothing has vouched for
     * its code, which is worth a warning rather than a refusal — Developer options is about
     * *debugging* an unsigned extension, not about permission to have one.
     */
    fun importExtension(uri: android.net.Uri) {
        openNativePackagesPage(2)
        viewModelScope.launch { emitMessage("Import .suic or .suik through Package Manager to review the publisher, permissions and execution behavior.") }
    }

    /** Fetch the remote marketplace index (extensions available to install). */
    fun refreshMarketplace() {
        viewModelScope.launch { runCatching { nativePackages.refreshLibrary() }.onFailure { emitMessage("Native library: ${it.message}") } }
    }
    fun installExtension(entry: MarketplaceEntry) {
        openNativePackagesPage(0)
        viewModelScope.launch { emitMessage("Legacy JCode/VSIX packages are not supported by the native ecosystem.") }
    }

    /**
     * Install [entry] after everything it `requires` (extensions recursively, then toolchains and
     * language servers via the catalogs). A missing required *extension* aborts the install; a failed
     * required *toolchain* is best-effort (the pack still installs, the toolchain stays retryable).
     * `suggests` stays manual.
     */
    private suspend fun installExtensionResolvingDeps(
        entry: MarketplaceEntry,
        visiting: MutableSet<String>,
    ): Boolean {
        if (!visiting.add(entry.id)) return true

        // A code UPDATE/REINSTALL of an already-installed extension must never be blocked on
        // (re)installing its toolchains: the extension is already present, and its required SDKs/LSPs
        // (e.g. Node + npm-based language servers) may legitimately be uninstallable in the current
        // runtime. Only a FRESH install resolves the index-declared `requires` up front with
        // abort-on-fail; for an update we land the new package and let the post-install pass below
        // attempt any missing toolchains best-effort, so the code update always applies.
        val freshInstall = !extensionInstaller.isInstalled(entry.id)
        if (freshInstall && !entry.requires.isEmpty) {
            setExtensionPhase(entry.id, "Installing required tools…")
            // Deps the marketplace index declared for this entry — resolved before install. A missing
            // required *extension* aborts (the pack is broken without it); a required *toolchain* is
            // best-effort so a heavy/flaky download (e.g. android-sdk) can't roll back the whole pack.
            if (!resolveRequires(entry.name, entry.requires, visiting, abortOnExtensionFail = true, abortOnToolchainFail = false)) return false
        }

        setExtensionPhase(entry.id, "Installing…")
        val result = extensionInstaller.install(entry, BuildConfig.VERSION_NAME)
            .onFailure { _messages.tryEmit("Install failed: ${it.message ?: "error"}") }
        if (result.isFailure) {
            setExtensionPhase(entry.id, null)
            return false
        }

        setExtensionPhase(entry.id, "Verifying…")
        val installedEntry = runCatching { extensionInstaller.installed() }
            .getOrDefault(emptyList())
            .firstOrNull { it.id == entry.id }
        if (installedEntry == null) {
            setExtensionPhase(entry.id, null)
            _messages.tryEmit("${entry.name}: installed but not detected on disk — install failed.")
            return false
        }
        _messages.tryEmit("Installed ${entry.name}")

        // The marketplace index currently omits `requires`, so the pre-install pass above sees nothing
        // for most extensions. Re-resolve from the freshly-installed manifest (the authoritative
        // source) to pull chained extensions (e.g. Android Dev Pack → Kotlin) and toolchains the index
        // left out. Non-fatal: the extension is already installed and usable on its own.
        if (!installedEntry.requires.isEmpty) {
            setExtensionPhase(entry.id, "Installing required tools…")
            resolveRequires(entry.name, installedEntry.requires, visiting, abortOnExtensionFail = false, abortOnToolchainFail = false)
        }
        setExtensionPhase(entry.id, null)
        return true
    }

    /**
     * Install everything [deps] names that isn't already present: required extensions (recursively),
     * then toolchain SDKs, language servers and debuggers via the catalogs. Failures are reported
     * either way; the abort flags decide whether a failure rolls the caller's install back.
     *
     * [abortOnExtensionFail] gates required *extensions* — cheap, essential, and the pack is broken
     * without them, so a fresh install aborts. [abortOnToolchainFail] gates required *toolchains*
     * (SDKs/LSPs/debuggers): even on a fresh install these are best-effort, because a heavy or flaky
     * download (e.g. android-sdk, a "Large download") shouldn't roll back an otherwise-usable pack —
     * its language features still work and the toolchain stays retryable from the Toolchains manager.
     */
    private suspend fun resolveRequires(
        sourceName: String,
        deps: ExtensionDeps,
        visiting: MutableSet<String>,
        abortOnExtensionFail: Boolean,
        abortOnToolchainFail: Boolean,
    ): Boolean {
        for (depId in deps.extensions) {
            if (depId in visiting) continue
            if (_installedExtensions.value.any { it.id == depId }) continue
            val depEntry = _marketplaceEntries.value.firstOrNull { it.id == depId }
            if (depEntry == null) {
                _messages.tryEmit("$sourceName: required extension '$depId' isn't in the marketplace.")
                if (abortOnExtensionFail) return false else continue
            }
            _messages.tryEmit("Installing required extension: ${depEntry.name}…")
            if (!installExtensionResolvingDeps(depEntry, visiting)) {
                _messages.tryEmit("$sourceName: required extension ${depEntry.name} failed.")
                if (abortOnExtensionFail) return false
            }
        }
        // resolveAndInstallSdk installs each SDK's own transitive requiredSdks first (e.g. android-sdk →
        // android-prereqs); installRequiredSdk alone skips that, so an extension requiring android-sdk
        // aborted because android-sdk's script needs the tools android-prereqs provides. Shared with the
        // direct-toolchain/LSP/debugger install paths, which already resolve prerequisites this way.
        val sdkVisiting = mutableSetOf<String>()
        for (sdkId in deps.sdks) {
            if (!resolveAndInstallSdk(sdkId, sourceName, sdkVisiting)) {
                if (abortOnToolchainFail) return false
            }
        }
        for (lspId in deps.lsps) {
            if (lspId in distroService.lspCatalogState.value.installedEntryIds) continue
            _messages.tryEmit("Installing required language server: $lspId…")
            if (!installRequiredLsp(lspId)) {
                val reason = distroService.lspCatalogState.value.errorMessage ?: "install failed"
                _messages.tryEmit("$sourceName: required language server '$lspId' — $reason")
                if (abortOnToolchainFail) return false
            }
        }
        for (dbgId in deps.dbg) {
            if (dbgId in distroService.debugCatalogState.value.installedEntryIds) continue
            _messages.tryEmit("Installing required debugger: $dbgId…")
            if (!installRequiredDbg(dbgId)) {
                val reason = distroService.debugCatalogState.value.errorMessage ?: "install failed"
                _messages.tryEmit("$sourceName: required debugger '$dbgId' — $reason")
                if (abortOnToolchainFail) return false
            }
        }
        return true
    }

    private suspend fun installRequiredSdk(entryId: String): Boolean = withContext(Dispatchers.IO) {
        val session = SessionRegistry.registerSession(
            context = getApplication(),
            kind = BackendSessionKind.JOB,
            name = "sdk:install:$entryId",
        )
        try {
            distroService.runSdkCatalogAction(entryId, SdkCatalogAction.Install)
        } finally {
            session.close()
        }
        entryId in distroService.sdkCatalogState.value.installedEntryIds
    }

    private suspend fun installRequiredLsp(entryId: String): Boolean = withContext(Dispatchers.IO) {
        // The server's own prerequisites first, exactly as installLspCatalogEntry and
        // installRequiredDbg do. Without this an extension that requires jdtls installs the server's
        // files and no JVM, so its verify fails and it can never launch.
        val entry = LspServerCatalog.findById(entryId)
        if (entry != null && !installRequiredSdks(entry.requiredSdks, entry.name)) return@withContext false
        val session = SessionRegistry.registerSession(
            context = getApplication(),
            kind = BackendSessionKind.JOB,
            name = "lsp:install:$entryId",
        )
        try {
            distroService.runLspCatalogAction(entryId, LspCatalogAction.Install)
        } finally {
            session.close()
        }
        entryId in distroService.lspCatalogState.value.installedEntryIds
    }

    private suspend fun installRequiredDbg(entryId: String): Boolean = withContext(Dispatchers.IO) {
        val entry = DebugEngineCatalog.findById(entryId)
        if (entry != null && !installRequiredSdks(entry.requiredSdks, entry.name)) return@withContext false
        val session = SessionRegistry.registerSession(
            context = getApplication(),
            kind = BackendSessionKind.JOB,
            name = "dbg:install:$entryId",
        )
        try {
            distroService.runDebugEngineCatalogAction(entryId, DebugEngineAction.Install)
        } finally {
            session.close()
        }
        entryId in distroService.debugCatalogState.value.installedEntryIds
    }

    /**
     * Install every SDK in [requiredSdks] (and their transitive SDK requirements) before the caller
     * installs the tool itself. Already-installed SDKs are skipped; the first failure aborts and
     * returns false so the tool install can be skipped too.
     */
    private suspend fun installRequiredSdks(requiredSdks: List<String>, forName: String): Boolean {
        val visiting = mutableSetOf<String>()
        for (sdkId in requiredSdks) {
            if (!resolveAndInstallSdk(sdkId, forName, visiting)) return false
        }
        return true
    }

    private suspend fun resolveAndInstallSdk(
        sdkId: String,
        forName: String,
        visiting: MutableSet<String>,
    ): Boolean {
        if (sdkId in distroService.sdkCatalogState.value.installedEntryIds) return true
        if (!visiting.add(sdkId)) return true
        val entry = distroService.sdkCatalogState.value.entries.firstOrNull { it.id == sdkId }
        for (dep in entry?.requiredSdks.orEmpty()) {
            if (!resolveAndInstallSdk(dep, forName, visiting)) return false
        }
        _messages.tryEmit("Installing required toolchain: ${entry?.name ?: sdkId}…")
        if (!installRequiredSdk(sdkId)) {
            val reason = distroService.sdkCatalogState.value.errorMessage ?: "install failed"
            _messages.tryEmit("$forName: required toolchain '${entry?.name ?: sdkId}' — $reason Install aborted.")
            return false
        }
        return true
    }

    private suspend fun runCatalogInstall(kind: String, entryId: String, block: suspend () -> Unit) {
        val session = SessionRegistry.registerSession(
            context = getApplication(),
            kind = BackendSessionKind.JOB,
            name = "$kind:install:$entryId",
        )
        try {
            block()
            warnIfTerminalsRunAnotherDistro()
        } finally {
            session.close()
        }
    }

    /**
     * A terminal is pinned to the rootfs it was spawned against (proot's `-r`) for the life of its
     * shell, so a toolchain installed into a different distro can never turn up in it: `which` finds
     * nothing and the whole install tree is invisible, which reads as an install that silently
     * failed. Nothing can migrate a running shell, so name both distros and let the user open a new
     * terminal. Worded to hold whether or not the install itself succeeded.
     */
    private fun warnIfTerminalsRunAnotherDistro() {
        val target = distroService.environmentState.value.runtime.selectedDistro.id
        val stale = TerminalSessionHost.existingManager()?.sessions?.values
            ?.mapNotNull { it.spawnSpec?.distroId }
            ?.firstOrNull { it != target } ?: return
        _prompts.tryEmit(WorkbenchPrompt.StaleTerminalDistro(stale, target))
    }

    fun uninstallExtension(id: String) {
        clearExtensionActivation(id)
        // Read before the uninstall takes it out of the list, and only for the message.
        val name = _installedExtensions.value.firstOrNull { it.id == id }?.name
        // A plugin that ran code in this process does not leave when its files do: its dex is loaded
        // and Android cannot unload one, so its pages, its background host and anything it registered
        // — the virtual device among them — stay live until the process is replaced. Uninstalling the
        // Android pack with a device open otherwise reads as an uninstall that did not work.
        val residentCode = NativeExtensionLoader.hasLoadedCode(id)
        // Also read while it is still listed: what it declares is how the workbench knows it is the
        // one running the virtual device.
        val providesDevice = _installedExtensions.value.firstOrNull { it.id == id }?.nativeGuestModule() != null
        // Read here too: the holders behind it are the main thread's, and the uninstall below runs
        // on IO. Nothing the uninstall does changes the answer — a view stays live until something
        // takes it down, which is the whole reason for asking.
        val liveSurfaces = hasLiveSurfaces(id)
        // The source attribution deliberately survives: it is what still ties the removed extension to
        // the repo that publishes it, so its source keeps offering it under the right id — and the
        // detail page left open by this uninstall keeps a working Install.
        viewModelScope.launch(Dispatchers.IO) {
            // A pack that provides the virtual device is *running* one, and none of that goes when
            // its files do: the `:guest` process, the adb daemon serving it and the tabs drawing it
            // all outlive the uninstall. Stopped here, before the files are removed, because
            // `shutdown` reaches the device through the pack — afterwards there is nothing left to
            // ask, and what is running becomes unreachable rather than stopped.
            if (providesDevice) {
                runCatching { VirtualDeviceBridge.shutdown(loadIfNeeded = true) }
                runCatching { stopVirtualDeviceAdb() }
                closeEditorTab(APP_SANDBOX_TAB_ID)
                closeEditorTab(VIRTUAL_HARDWARE_TAB_ID)
            }
            extensionInstaller.uninstall(id)
            // Icon art is held decoded and keyed by file path; the files are about to go, and a set
            // the user has just removed should stop being drawn rather than linger in a cache.
            IconPackLoader.evict()
            refreshInstalledExtensions()
            // The bridge caches which installed pack provides the device, and `evict` is what makes
            // that current again. Without it the workbench goes on being told a device is available
            // by the pack it has just removed, and keeps offering every surface that draws one.
            if (providesDevice) runCatching { VirtualDeviceBridge.evict() }
            if (residentCode) {
                _prompts.tryEmit(
                    WorkbenchPrompt.RestartApp(
                        "Restart JCode to finish removing ${name ?: "the extension"}.",
                    ),
                )
            } else if (liveSurfaces) {
                // Nothing of this one is resident, so its views are all that is left of it — and they
                // keep working, which reads as an uninstall that did not happen.
                _prompts.tryEmit(
                    WorkbenchPrompt.ReloadExtension(
                        id = id,
                        message = "${name ?: "The extension"} was removed — reload to close what it still has open.",
                    ),
                )
            }
        }
    }

    private val _showNewItemDialog = MutableStateFlow(false)
    val showNewItemDialog: StateFlow<Boolean> = _showNewItemDialog.asStateFlow()

    /** After a folder is opened as a project while a User Workspace is open (e.g. from a clone in the
     *  SCM extension), the registered project awaiting an open-vs-add choice. */
    private val _postClonePrompt = MutableStateFlow<Project?>(null)
    val postClonePrompt: StateFlow<Project?> = _postClonePrompt.asStateFlow()

    /** A folder awaiting a Project/Workspace choice (it has no `.jcode` type yet) — either opened in
     *  place on managed storage, or already copied into /sources staging and awaiting adoption. */
    private val _openFolderTypePrompt = MutableStateFlow<PendingFolderType?>(null)
    val openFolderTypePrompt: StateFlow<PendingFolderType?> = _openFolderTypePrompt.asStateFlow()

    /** Non-null while an off-ext4 folder is being scanned/copied into /sources — drives the modal. */
    private val _importProgress = MutableStateFlow<ImportProgress?>(null)
    val importProgress: StateFlow<ImportProgress?> = _importProgress.asStateFlow()

    private val _selectedProjectId = MutableStateFlow<Long?>(null)
    val selectedProject: StateFlow<Project?> = currentWorkspace
        .combine(_selectedProjectId) { workspace, selectedProjectId ->
            val projects = workspace?.projects.orEmpty()
            projects.firstOrNull { it.id == selectedProjectId } ?: projects.firstOrNull()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _editorGroup = MutableStateFlow(EditorGroup.create())
    val editorGroup: StateFlow<EditorGroup> = _editorGroup.asStateFlow()

    // App-level (non-workspace) UI preferences. Durable across restarts, mirroring how the fs and
    // distro modules persist their own preference stores. Uses a process singleton: creating a second
    // DataStore for the same file (e.g. when a new MainViewModel is built after Activity recreation)
    // crashes with "multiple DataStores active for the same file".
    private val uiPreferences = UiPreferencesStore.get(appContext)

    /** Serialize the app-preferences DataStore for the Settings > Backup "Export settings" action. */
    suspend fun exportSettingsJson(): String = SettingsBackup.export(uiPreferences)

    /** Apply a previously-exported settings document; returns how many settings were restored. */
    suspend fun importSettingsJson(document: String): Int = SettingsBackup.import(uiPreferences, document)

    private val _envBackupStatus = MutableStateFlow<String?>(null)
    /** Non-null while an environment backup/restore runs; the message drives a modal progress dialog. */
    val envBackupStatus = _envBackupStatus.asStateFlow()

    /** Pack the active environment's rootfs to a SAF-created .tar.gz [uri]. */
    fun backupEnvironmentTo(uri: android.net.Uri) {
        if (_envBackupStatus.value != null) return
        viewModelScope.launch {
            _envBackupStatus.value = "Preparing backup…"
            val ok = runCatching {
                withContext(Dispatchers.IO) {
                    appContext.contentResolver.openOutputStream(uri)?.use { os ->
                        distroService.packSelectedEnvironment(os) { files, bytes ->
                            _envBackupStatus.value = "Backing up… $files files (${bytes / (1024 * 1024)} MB)"
                        }
                    } ?: error("Could not open the destination file")
                }
            }.getOrDefault(false)
            _messages.tryEmit(if (ok) "Environment backed up." else "Environment backup failed.")
            _envBackupStatus.value = null
        }
    }

    /** Restore the active environment's rootfs from a SAF-picked .tar.gz [uri], replacing it. */
    fun restoreEnvironmentFrom(uri: android.net.Uri) {
        if (_envBackupStatus.value != null) return
        viewModelScope.launch {
            _envBackupStatus.value = "Restoring environment…"
            val ok = runCatching {
                val tmp = withContext(Dispatchers.IO) {
                    val t = java.io.File(appContext.cacheDir, "env-restore-${System.nanoTime()}.tar.gz")
                    appContext.contentResolver.openInputStream(uri)?.use { input ->
                        t.outputStream().use { input.copyTo(it, 1 shl 16) }
                    } ?: error("Could not read the backup file")
                    t
                }
                val restored = distroService.restoreSelectedEnvironment(tmp)
                withContext(Dispatchers.IO) { tmp.delete() }
                restored
            }.getOrDefault(false)
            _messages.tryEmit(if (ok) "Environment restored." else "Environment restore failed.")
            _envBackupStatus.value = null
        }
    }

    /**
     * Restore the environment from a backup during ONBOARDING: copy the picked .tar.gz to cache, arm the
     * DistroInstalled step to restore from it (instead of downloading), then run the full setup pipeline
     * so proot / jcode-user / smoke-test still run and produce a working environment. Progress shows in
     * the onboarding "Setup log" and finishes with the normal "Done" completion.
     */
    fun restoreEnvironmentOnboarding(uri: android.net.Uri) {
        viewModelScope.launch {
            val tmp = withContext(Dispatchers.IO) {
                runCatching {
                    val t = java.io.File(appContext.cacheDir, "env-restore-onboarding-${System.nanoTime()}.tar.gz")
                    appContext.contentResolver.openInputStream(uri)?.use { input ->
                        t.outputStream().use { input.copyTo(it, 1 shl 16) }
                    } ?: error("Could not read the backup file")
                    t
                }.getOrNull()
            }
            if (tmp == null) {
                _messages.tryEmit("Could not read the backup file.")
                return@launch
            }
            distroService.setPendingRestoreTarball(tmp)
            runAutoSetup()
        }
    }

    /**
     * What a finished import left behind: the bundle in shared storage, and the install it came
     * from. Held rather than announced once, because the import happens during onboarding where a
     * transient message would go unread — the offer has to survive until the user reaches a screen
     * that can show it.
     */
    data class MigrationCleanup(val sourcePackage: String, val bytes: Long, val oldAppInstalled: Boolean)

    private val _migrationCleanup = MutableStateFlow<MigrationCleanup?>(null)
    val migrationCleanup: StateFlow<MigrationCleanup?> = _migrationCleanup.asStateFlow()

    fun dismissMigrationCleanup() {
        _migrationCleanup.value = null
    }

    /**
     * Delete the bundle now that its contents live here.
     *
     * Safe to do without asking twice: the install it came from still holds everything, so this
     * removes a copy rather than the last one. Uninstalling that install is a separate step, and
     * Android puts its own confirmation in front of it.
     */
    fun cleanUpAfterMigration() {
        val pending = _migrationCleanup.value ?: return
        _migrationCleanup.value = null
        viewModelScope.launch {
            val freed = withContext(Dispatchers.IO) {
                val dir = MigrationBundle.directory()
                val size = runCatching { dir.walkBottomUp().filter { it.isFile }.sumOf { it.length() } }.getOrDefault(0L)
                runCatching { dir.deleteRecursively() }
                size
            }
            _migrationBundle.value = null
            emitMessage("Removed the migration bundle (${freed / (1024 * 1024)} MB).")
            if (pending.oldAppInstalled) requestUninstall(pending.sourcePackage)
        }
    }

    /**
     * Ask Android to uninstall [packageName]. It shows its own confirmation and does the work; an
     * app cannot remove another one on its own, and should not be able to.
     */
    fun requestUninstall(packageName: String) {
        runCatching {
            appContext.startActivity(
                android.content.Intent(android.content.Intent.ACTION_DELETE)
                    .setData(Uri.parse("package:$packageName"))
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }.onFailure { _messages.tryEmit("Could not open the uninstaller for $packageName.") }
    }

    /** A migration bundle waiting to be imported, refreshed on demand. See [MigrationBundle]. */
    private val _migrationBundle = MutableStateFlow<MigrationBundle.Found?>(null)
    val migrationBundle: StateFlow<MigrationBundle.Found?> = _migrationBundle.asStateFlow()

    private fun isPackageInstalled(packageName: String): Boolean = runCatching {
        appContext.packageManager.getPackageInfo(packageName, 0) != null
    }.getOrDefault(false)

    fun refreshMigrationBundle() {
        viewModelScope.launch(Dispatchers.IO) {
            _migrationBundle.value = runCatching { MigrationBundle.find(appContext) }.getOrNull()
        }
    }

    /**
     * Write this install's rootfs, projects, extensions and settings to shared storage so a
     * differently-packaged build can pick them up. See [MigrationBundle] for why that is the only
     * way across.
     *
     * The parts are written first and the manifest last, so an export that is interrupted — and at
     * 2.5 GB that is a real possibility — leaves nothing that presents itself as importable.
     */
    fun exportMigrationBundle() {
        if (_envBackupStatus.value != null) return
        viewModelScope.launch {
            val result = runCatching { writeMigrationBundle { _envBackupStatus.value = it } }
            _envBackupStatus.value = null
            result
                .onSuccess { (dir, parts) ->
                    emitMessage("Migration bundle written to ${dir.absolutePath} (${parts.size} parts).")
                }
                .onFailure { emitMessage("Migration export failed: ${it.message ?: "unknown error"}") }
        }
    }

    /**
     * Copy this install out for an update that changes the package, reporting progress through
     * [onProgress]. Returns null when the bundle is complete, or why it is not.
     *
     * Called by the updater between downloading an APK and installing it — see
     * [AppUpdateInstaller.downloadAndInstall]. Failures are returned rather than thrown because the
     * update is still installable without the data, and that is the user's call to make.
     */
    suspend fun prepareMigrationForUpdate(onProgress: (String) -> Unit): String? {
        val shortfall = withContext(Dispatchers.IO) { migrationSpaceShortfall() }
        if (shortfall != null) return shortfall
        return runCatching { writeMigrationBundle(onProgress); null }
            .getOrElse { it.message ?: "the copy could not be completed" }
    }

    /**
     * Whether there is room to write the bundle, as a sentence, or null when there is.
     *
     * Checked up front because the expensive part is the rootfs: finding out halfway through a
     * multi-gigabyte copy leaves a part-written bundle and a user who has waited for nothing.
     */
    private fun migrationSpaceShortfall(): String? {
        val sources = listOf(
            File(appContext.filesDir, "distros"),
            File(WorkspaceHostPaths.projectsRoot),
            File(appContext.filesDir, "extensions"),
        )
        val raw = sources.filter { it.isDirectory }
            .sumOf { d -> runCatching { d.walkBottomUp().filter { it.isFile }.sumOf { it.length() } }.getOrDefault(0L) }
        if (raw <= 0L) return null
        // A rootfs is mostly text and binaries and gzips to roughly a third, but half is reserved
        // deliberately: over-reserving costs a warning, under-reserving costs the whole copy.
        val needed = raw / 2
        val target = MigrationBundle.directory()
        runCatching { target.parentFile?.mkdirs() }
        val free = runCatching { android.os.StatFs(target.parentFile?.absolutePath ?: "/storage/emulated/0").availableBytes }
            .getOrDefault(0L)
        if (free >= needed) return null
        val mb = { b: Long -> "${b / (1024 * 1024)} MB" }
        return "copying your environment needs about ${mb(needed)} free and there is ${mb(free)}"
    }

    /** Writes the bundle; throws on failure. Returns the directory and the parts that landed. */
    private suspend fun writeMigrationBundle(onProgress: (String) -> Unit): Pair<File, List<String>> {
        onProgress("Preparing migration bundle…")
        return withContext(Dispatchers.IO) {
            val dir = MigrationBundle.directory()
            dir.deleteRecursively()
            require(dir.mkdirs() || dir.isDirectory) { "cannot write to ${dir.absolutePath}" }
            val parts = mutableListOf<String>()

            File(dir, MigrationBundle.SETTINGS).writeText(SettingsBackup.export(uiPreferences))
            parts += MigrationBundle.SETTINGS

            // Reuses the same packer the "Back up environment" action uses, so a bundle's
            // rootfs is byte-for-byte an ordinary environment backup.
            if (distroService.selectedEnvironmentInstalled()) {
                onProgress("Packing the Linux environment…")
                File(dir, MigrationBundle.ROOTFS).outputStream().use { out ->
                    distroService.packSelectedEnvironment(out) { files, bytes ->
                        onProgress("Packing the environment… $files files (${bytes / (1024 * 1024)} MB)")
                    }
                }
                parts += MigrationBundle.ROOTFS
            }

            // Projects only when they have moved to app-private storage; before that
            // migration they are already in the shared folder and go nowhere.
            val projects = File(WorkspaceHostPaths.projectsRoot)
            if (projects.isDirectory && projects.absolutePath.startsWith(appContext.filesDir.absolutePath)) {
                onProgress("Packing projects…")
                File(dir, MigrationBundle.PROJECTS).outputStream().use { out ->
                    RootfsArchiver.pack(projects, out) { files, _ ->
                        onProgress("Packing projects… $files files")
                    }
                }
                parts += MigrationBundle.PROJECTS
            }

            val extensions = File(appContext.filesDir, "extensions")
            if (extensions.isDirectory) {
                onProgress("Packing extensions…")
                File(dir, MigrationBundle.EXTENSIONS).outputStream().use { out ->
                    RootfsArchiver.pack(extensions, out) { files, _ ->
                        onProgress("Packing extensions… $files files")
                    }
                }
                parts += MigrationBundle.EXTENSIONS
            }

            MigrationBundle.writeManifest(appContext, dir, parts, BuildConfig.VERSION_NAME)
            dir to parts
        }
    }

    /**
     * Take over a bundle another install left behind.
     *
     * Settings, projects and extensions are restored directly. The rootfs goes through the same
     * pipeline an onboarding restore uses ([restoreEnvironmentOnboarding]) rather than being dropped
     * into place: proot, the jcode user and the smoke test still have to run against it, or the
     * environment is present but not usable.
     */
    fun importMigrationBundle() {
        if (_envBackupStatus.value != null) return
        val bundle = _migrationBundle.value ?: return
        viewModelScope.launch {
            _envBackupStatus.value = "Importing from ${bundle.sourcePackage}…"
            val restored = runCatching {
                withContext(Dispatchers.IO) {
                    bundle.file(MigrationBundle.SETTINGS)?.let { SettingsBackup.import(uiPreferences, it.readText()) }

                    bundle.file(MigrationBundle.PROJECTS)?.let {
                        _envBackupStatus.value = "Restoring projects…"
                        distroService.extractArchive(it, File(WorkspaceHostPaths.projectsRoot))
                    }
                    bundle.file(MigrationBundle.EXTENSIONS)?.let {
                        _envBackupStatus.value = "Restoring extensions…"
                        distroService.extractArchive(it, File(appContext.filesDir, "extensions"))
                    }
                    // Copied out of shared storage first: the setup pipeline consumes the tarball,
                    // and the bundle is the user's only copy until the import has finished.
                    bundle.file(MigrationBundle.ROOTFS)?.let { source ->
                        val tmp = File(appContext.cacheDir, "env-migrate-${System.nanoTime()}.tar.gz")
                        source.inputStream().use { input -> tmp.outputStream().use { input.copyTo(it, 1 shl 16) } }
                        tmp
                    }
                }
            }.getOrElse {
                _envBackupStatus.value = null
                emitMessage("Migration import failed: ${it.message ?: "unknown error"}")
                return@launch
            }
            _envBackupStatus.value = null
            refreshInstalledExtensions()
            _migrationCleanup.value = MigrationCleanup(
                sourcePackage = bundle.sourcePackage,
                bytes = bundle.bytes,
                oldAppInstalled = isPackageInstalled(bundle.sourcePackage),
            )
            _migrationBundle.value = null
            if (restored != null) {
                distroService.setPendingRestoreTarball(restored)
                runAutoSetup()
            } else {
                emitMessage("Imported settings, projects and extensions.")
            }
        }
    }

    private val hardwareAccelerationKey = booleanPreferencesKey("perf_hardware_acceleration")

    /** GPU-accelerated window rendering (default on). Applied by MainActivity at window creation, so
     *  changes take effect on the next app start. The value is mirrored into synchronous
     *  SharedPreferences because the window flag must be read before any async storage is available. */
    val hardwareAcceleration: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[hardwareAccelerationKey] ?: SettingsDefaults.HARDWARE_ACCELERATION }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.HARDWARE_ACCELERATION)

    fun setHardwareAcceleration(enabled: Boolean) {
        val changed = enabled != hardwareAcceleration.value
        getApplication<Application>()
            .getSharedPreferences(MainActivity.UI_STARTUP_PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(MainActivity.KEY_HW_ACCELERATION, enabled).apply()
        viewModelScope.launch { uiPreferences.edit { it[hardwareAccelerationKey] = enabled } }
        // The window flag is read once at startup (see MainActivity), so only a fresh process applies it.
        if (changed) _prompts.tryEmit(WorkbenchPrompt.RestartApp("Restart JCode to apply the hardware acceleration change."))
    }

    // Explorer "hide files at the project root" preference: a mode + the user's newline-separated
    // by-line pattern list. The injected (.gitignore) list lives in hiddenInjected below.
    private val explorerHiddenModeKey = stringPreferencesKey("explorer_hidden_root_mode")
    val explorerHiddenMode: StateFlow<dev.blamspot.jcode.design.ExplorerHiddenMode> = uiPreferences.data
        .map { prefs ->
            runCatching { dev.blamspot.jcode.design.ExplorerHiddenMode.valueOf(prefs[explorerHiddenModeKey] ?: "") }
                .getOrDefault(SettingsDefaults.HIDDEN_ROOT_MODE)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.HIDDEN_ROOT_MODE)

    fun setExplorerHiddenMode(mode: dev.blamspot.jcode.design.ExplorerHiddenMode) {
        viewModelScope.launch { uiPreferences.edit { it[explorerHiddenModeKey] = mode.name } }
    }

    private val explorerExcludeEffectKey = stringPreferencesKey("explorer_exclude_effect")
    val explorerExcludeEffect: StateFlow<dev.blamspot.jcode.design.ExplorerExcludeEffect> = uiPreferences.data
        .map { prefs ->
            runCatching { dev.blamspot.jcode.design.ExplorerExcludeEffect.valueOf(prefs[explorerExcludeEffectKey] ?: "") }
                .getOrDefault(SettingsDefaults.EXCLUDE_EFFECT)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.EXCLUDE_EFFECT)

    fun setExplorerExcludeEffect(effect: dev.blamspot.jcode.design.ExplorerExcludeEffect) {
        viewModelScope.launch { uiPreferences.edit { it[explorerExcludeEffectKey] = effect.name } }
    }

    private val explorerHiddenPatternsKey = stringPreferencesKey("explorer_hidden_root_patterns")
    val explorerHiddenPatterns: StateFlow<String> = uiPreferences.data
        .map { prefs -> prefs[explorerHiddenPatternsKey] ?: SettingsDefaults.HIDDEN_ROOT_PATTERNS }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.HIDDEN_ROOT_PATTERNS)

    fun setExplorerHiddenPatterns(raw: String) {
        viewModelScope.launch { uiPreferences.edit { it[explorerHiddenPatternsKey] = raw } }
    }

    private val trashEnabledKey = booleanPreferencesKey("trash_enabled")

    /** Whether an Explorer delete and an SCM discard move to the Trash instead of destroying. */
    val trashEnabled: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[trashEnabledKey] ?: SettingsDefaults.TRASH_ENABLED }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.TRASH_ENABLED)

    fun setTrashEnabled(enabled: Boolean) {
        viewModelScope.launch { uiPreferences.edit { it[trashEnabledKey] = enabled } }
    }

    private val trashRetentionDaysKey = intPreferencesKey("trash_retention_days")

    /** How long a trashed item is kept before the sweep drops it. 0 keeps it until the user empties. */
    val trashRetentionDays: StateFlow<Int> = uiPreferences.data
        .map { prefs -> prefs[trashRetentionDaysKey] ?: SettingsDefaults.TRASH_RETENTION_DAYS }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.TRASH_RETENTION_DAYS)

    fun setTrashRetentionDays(days: Int) {
        viewModelScope.launch {
            uiPreferences.edit { it[trashRetentionDaysKey] = days.coerceAtLeast(0) }
            // Immediately, not at the next launch: shortening the period is an instruction about
            // what is in the bin now, and leaving expired entries visible would contradict it.
            trash.sweep(days.coerceAtLeast(0))
        }
    }

    /** The app's bin — see [dev.blamspot.jcode.fs.Trash]. */
    private val trash by lazy { WorkspaceServiceLocator.trash(appContext) }

    private val respectCutoutKey = booleanPreferencesKey("respect_device_cutout")

    /** Whether to keep content out of the display cutout (notch/punch-hole). Mirrored to synchronous
     *  SharedPreferences so MainActivity applies the window cutout mode on the first frame; JCodeShell
     *  also applies it live (window.attributes is mutable, unlike the hardware-acceleration flag). */
    val respectDeviceCutout: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[respectCutoutKey] ?: SettingsDefaults.RESPECT_DEVICE_CUTOUT }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.RESPECT_DEVICE_CUTOUT)

    fun setRespectDeviceCutout(enabled: Boolean) {
        getApplication<Application>()
            .getSharedPreferences(MainActivity.UI_STARTUP_PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(MainActivity.KEY_RESPECT_CUTOUT, enabled).apply()
        viewModelScope.launch { uiPreferences.edit { it[respectCutoutKey] = enabled } }
    }

    private val tabColoringKey = stringPreferencesKey("tab_coloring")

    /** App-level (Global) editor-tab coloring default; a project/workspace .jcode can override it. */
    val tabColoringMode: StateFlow<TabColoring> = uiPreferences.data
        .map { prefs ->
            prefs[tabColoringKey]?.let { runCatching { TabColoring.valueOf(it) }.getOrNull() }
                ?: SettingsDefaults.TAB_COLORING
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.TAB_COLORING)

    fun setTabColoringMode(mode: TabColoring) {
        viewModelScope.launch { uiPreferences.edit { it[tabColoringKey] = mode.name } }
    }

    private val tabMaxSizeKey = stringPreferencesKey("tab_max_size")

    /** Max width of editor/terminal tabs before the title middle-ellipsizes (Small/Medium/Large). */
    val tabMaxSize: StateFlow<TabMaxSize> = uiPreferences.data
        .map { prefs ->
            prefs[tabMaxSizeKey]?.let { runCatching { TabMaxSize.valueOf(it) }.getOrNull() }
                ?: SettingsDefaults.TAB_MAX_SIZE
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.TAB_MAX_SIZE)

    fun setTabMaxSize(size: TabMaxSize) {
        viewModelScope.launch { uiPreferences.edit { it[tabMaxSizeKey] = size.name } }
    }

    private val confirmCloseRunningKey = booleanPreferencesKey("perf_confirm_close_running")

    /** When true (default), closing a project/workspace with a running terminal program, an active
     *  Build & Run, or a live debug session prompts for confirmation before killing them. */
    val confirmCloseRunning: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[confirmCloseRunningKey] ?: SettingsDefaults.CONFIRM_CLOSE_RUNNING }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.CONFIRM_CLOSE_RUNNING)

    fun setConfirmCloseRunning(enabled: Boolean) {
        viewModelScope.launch { uiPreferences.edit { it[confirmCloseRunningKey] = enabled } }
    }

    private val exitOnSwipeAwayKey = booleanPreferencesKey(EXIT_ON_SWIPE_AWAY_KEY)

    /** When true (default on), swiping JCode off the Android recents screen tears down the Linux
     *  runtime (terminals, runs, VMs) and exits the process entirely — handled in
     *  [BackendService.onTaskRemoved], which reads the mirrored [exitOnSwipeAwayEnabled]. */
    val exitOnSwipeAway: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[exitOnSwipeAwayKey] ?: SettingsDefaults.EXIT_ON_SWIPE_AWAY }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.EXIT_ON_SWIPE_AWAY)

    fun setExitOnSwipeAway(enabled: Boolean) {
        exitOnSwipeAwayEnabled = enabled
        viewModelScope.launch { uiPreferences.edit { it[exitOnSwipeAwayKey] = enabled } }
    }

    init {
        // Keep the static mirror BackendService reads in sync, and register the runtime teardown it
        // runs on a swipe-away exit. (Placed after the property declarations it references.)
        runtimeTeardown = {
            runCatching { stopAllRuntimeServices() }
            runCatching { adbBridge.stop() }
            runCatching { stopVirtualDeviceAdb() }
        }
        sessionFlushBlocking = { runCatching { runBlocking { persistSession() } } }
        viewModelScope.launch { exitOnSwipeAway.collect { exitOnSwipeAwayEnabled = it } }
        // The device ships in the Android Dev Pack now; this is the app's only handle on it, and it
        // needs a context before any of the manifest stubs can ask it for one.
        VirtualDeviceBridge.init(appContext)
        // Bring the adb bridge back up, but only once a serial has been restored — i.e. only for a
        // device that was paired before. Otherwise every cold start of a fresh install would pay a
        // full mDNS discovery plus an `adb start-server` in the distro for nothing.
        viewModelScope.launch {
            adbBridge.serial.filterNotNull().first()
            adbBridge.ensureConnected()
        }
        // Point guest tooling at the relay while it is up (bare `adb`, `gradlew installDebug`,
        // `flutter run` then target this phone with no -s flag), and unset it when it is not.
        viewModelScope.launch {
            adbBridge.state.collect { state ->
                TerminalSessionHost.manager(appContext).adbRelayPort =
                    (state as? AdbBridgeState.Ready)?.relayPort ?: 0
            }
        }
        // Expire the Trash once per start. Not on a timer: the retention period is measured in days
        // and a session rarely spans one, so a start plus the sweep the Trash view does when opened
        // covers everything a schedule would, without a wakeup that exists only to delete nothing.
        viewModelScope.launch { trash.sweep(trashRetentionDays.value) }
    }

    /** Holds the guest's adb client open; see [startVirtualDeviceAdb]. */
    private var virtualDeviceAdbServer: Process? = null

    /**
     * Whether the device's adb is actually up.
     *
     * Not the setting: the setting is what the user asked for, and this is what is true. They
     * part company the moment anything stops it -- the Task Manager, for one, which otherwise
     * went on listing an adb it had just been told to stop.
     */
    @Volatile
    private var virtualDeviceAdbRunning = false

    /**
     * The rootfs the device's adb socket goes inside: the selected distro's own.
     *
     * That is what makes it reachable from the distro without a new proot bind -- `<rootfs>/run/x`
     * on this side is `/run/x` on that one -- and unreachable from anywhere else, since the whole
     * rootfs lives in JCode's private storage where no other uid may open a file. Which file it
     * binds in there is the device's business, not this one's.
     */
    private fun virtualDeviceRootfs(): File? {
        val distro = distroService.selectedEnvironment().id.takeIf { it.isNotBlank() } ?: return null
        return File(appContext.filesDir, "distros/$distro/rootfs").takeIf { it.isDirectory }
    }

    private suspend fun startVirtualDeviceAdb() {
        val rootfs = virtualDeviceRootfs() ?: run {
            OutputLog.append(
                "Virtual device adb not started: no installed Linux runtime to host its socket\n",
                OutputKind.Error,
            )
            return
        }
        // The device's own daemon, in the pack that provides the device. With no pack installed
        // there is nothing to start, and nothing for a client to connect to.
        val spec = runCatching { VirtualDeviceBridge.startAdb(rootfs) }.getOrNull() ?: run {
            OutputLog.append(
                "Virtual device adb not started: no pack provides a device\n",
                OutputKind.Error,
            )
            return
        }
        TerminalSessionHost.manager(appContext).let { manager ->
            manager.virtualDeviceAdbSpec = spec
            manager.installAdbShim(rootfs)
        }
        virtualDeviceAdbRunning = true
        // The daemon only trusts the distro's own adbkey.pub, and adb does not create one until it
        // has run once — so mint it before connecting, or the first connection is refused for want
        // of a key rather than because anything is wrong.
        attachVirtualDeviceAdb(spec)
    }

    /**
     * Hold the guest's adb server open with the virtual device attached to it.
     *
     * `adb connect` registers the device with an adb *server*, and that server is a child of whatever
     * proot session started it — which proot reaps on exit. Connecting from a one-shot command
     * therefore left nothing behind: the next terminal started a server of its own, `adb devices` was
     * empty, and `adb install` had no device to install to. Keeping this session alive keeps that
     * server alive, and every terminal shares it. The client is the runtime's, which is why this
     * half stayed here when the daemon went to the pack.
     */
    private fun attachVirtualDeviceAdb(spec: String) {
        runCatching { virtualDeviceAdbServer?.destroy() }
        virtualDeviceAdbServer = distroService.spawnStdioProcess(
            command = "mkdir -p \"\$HOME/.android\" && " +
                "{ [ -f \"\$HOME/.android/adbkey.pub\" ] || adb keygen \"\$HOME/.android/adbkey\"; } && " +
                "adb start-server && adb connect $spec && exec sleep infinity",
        )
        if (virtualDeviceAdbServer == null) {
            OutputLog.append("Virtual device adb connect failed: the Linux runtime is not ready\n", OutputKind.Error)
        }
    }

    /**
     * Bring the device's adb up if it should be and is not.
     *
     * Called when a device starts. The setting's collector only fires when the *setting* changes,
     * so anything that stops adb while the setting stays on -- the Task Manager, for one -- left
     * it down until the switch was toggled: the device came back and `adb devices` was empty.
     *
     * Idempotent, because a device can be opened any number of times.
     */
    fun ensureVirtualDeviceAdb() {
        if (!runInVirtualDevice.value || virtualDeviceAdbRunning) return
        viewModelScope.launch { startVirtualDeviceAdb() }
    }

    private fun stopVirtualDeviceAdb() {
        virtualDeviceAdbRunning = false
        runCatching { virtualDeviceAdbServer?.destroy() }
        virtualDeviceAdbServer = null
        // `adb start-server` daemonises, so destroying the session that started it leaves the
        // server behind -- still listed, still holding the device it can no longer reach. It is
        // the runtime's own server and this is what started it, so this is what ends it.
        runCatching { distroService.spawnStdioProcess(command = "adb kill-server") }
        runCatching { VirtualDeviceBridge.stopAdb() }
        TerminalSessionHost.manager(appContext).let { manager ->
            manager.virtualDeviceAdbSpec = ""
            virtualDeviceRootfs()?.let(manager::installAdbShim)
        }
    }

    /**
     * Re-attach the virtual device to the runtime's adb server.
     *
     * The attachment is not owned by JCode once made: `adb kill-server`, an adb client of a different
     * version taking the port, or the runtime restarting all drop it, and the device then goes missing
     * from `adb devices` with nothing to say why. This puts it back without restarting the app.
     */
    private val _virtualDeviceAdbReconnecting = MutableStateFlow(false)

    /** True while [reconnectVirtualDeviceAdb] is working, so the settings action can show it. */
    val virtualDeviceAdbReconnecting: StateFlow<Boolean> = _virtualDeviceAdbReconnecting.asStateFlow()

    fun reconnectVirtualDeviceAdb() {
        if (_virtualDeviceAdbReconnecting.value) return
        viewModelScope.launch {
            if (!runInVirtualDevice.value) {
                OutputLog.append("Virtual device is off — turn it on to connect.\n", OutputKind.Error)
                return@launch
            }
            _virtualDeviceAdbReconnecting.value = true
            try {
                // Reattach to the socket already bound where there is one, rather than restarting the
                // daemon: terminals are told the device's address through ANDROID_SERIAL when they
                // start, and rebinding would leave every open terminal pointing at a dead one.
                val spec = TerminalSessionHost.manager(appContext).virtualDeviceAdbSpec
                if (spec.isNotEmpty()) attachVirtualDeviceAdb(spec) else startVirtualDeviceAdb()
                // Spawning the client only starts the connect; wait for the device to actually be
                // listed before saying so, or the action reports success the moment it is asked and
                // the user finds out otherwise from `adb devices`.
                val target = TerminalSessionHost.manager(appContext).virtualDeviceAdbSpec
                val attached = target.isNotEmpty() && awaitVirtualDeviceAttached(target)
                OutputLog.append(
                    if (attached) "Virtual device attached at $target.\n"
                    else "Virtual device did not attach at $target.\n",
                    if (attached) OutputKind.Info else OutputKind.Error,
                )
            } finally {
                _virtualDeviceAdbReconnecting.value = false
            }
        }
    }

    /** Poll `adb devices` until [target] shows up, so "reconnected" means it actually is. */
    private suspend fun awaitVirtualDeviceAttached(target: String): Boolean {
        repeat(VIRTUAL_DEVICE_ATTACH_ATTEMPTS) {
            val listed = runCatching {
                distroService.exec("adb devices", timeoutMs = 10_000L).stdout
            }.getOrDefault("")
            if (listed.lineSequence().any { it.startsWith(target) && it.trimEnd().endsWith("device") }) {
                return true
            }
            delay(VIRTUAL_DEVICE_ATTACH_POLL_MS)
        }
        return false
    }

    // --- Android run targets -------------------------------------------------
    // Which device an Android project's Run/Debug goes to. The runtime's adb server is the single
    // source of truth: JCode's own virtual device and this phone both reach a project only by being
    // connected to it, so anything it does not list cannot be launched on either.

    private val _androidRunTargets = MutableStateFlow<List<AndroidRunTarget>>(emptyList())
    val androidRunTargets: StateFlow<List<AndroidRunTarget>> = _androidRunTargets.asStateFlow()

    private val _androidRunTargetsLoading = MutableStateFlow(false)
    val androidRunTargetsLoading: StateFlow<Boolean> = _androidRunTargetsLoading.asStateFlow()

    /** The serial terminals already carry, so the picker can mark which device a run uses by default. */
    fun androidDefaultSerial(): String {
        val manager = TerminalSessionHost.manager(appContext)
        manager.virtualDeviceAdbSpec.takeIf { it.isNotEmpty() }?.let { return it }
        return manager.adbRelayPort.takeIf { it > 0 }?.let { "${AdbHostClient.LOOPBACK}:$it" }.orEmpty()
    }

    /** Re-read `adb devices`. Cheap and loopback-only, so the Run panel can call it on every open. */
    fun refreshAndroidRunTargets() {
        if (_androidRunTargetsLoading.value) return
        viewModelScope.launch {
            _androidRunTargetsLoading.value = true
            try {
                val virtualSpec = TerminalSessionHost.manager(appContext).virtualDeviceAdbSpec
                val relaySerial = TerminalSessionHost.manager(appContext).adbRelayPort
                    .takeIf { it > 0 }?.let { "${AdbHostClient.LOOPBACK}:$it" }
                _androidRunTargets.value = runCatching { adbBridge.devices() }
                    .getOrDefault(emptyList())
                    .map { device ->
                        AndroidRunTarget(
                            serial = device.serial,
                            label = when {
                                device.serial == virtualSpec -> "Virtual device"
                                device.serial == relaySerial -> "This phone"
                                else -> device.model?.replace('_', ' ') ?: device.serial
                            },
                            state = device.state,
                            isVirtual = device.serial == virtualSpec,
                        )
                    }
            } finally {
                _androidRunTargetsLoading.value = false
            }
        }
    }

    private val androidRunTargetProjectsKey = stringPreferencesKey("android_run_target_projects")

    /** Per-project device pick keyed by project id; absent = follow the session's own ANDROID_SERIAL. */
    val androidRunTargetProjects: StateFlow<Map<String, String>> = uiPreferences.data
        .map { prefs -> parseStringMap(prefs[androidRunTargetProjectsKey]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    fun setProjectAndroidRunTarget(projectKey: String, serial: String) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val obj = runCatching { JSONObject(prefs[androidRunTargetProjectsKey] ?: "{}") }.getOrDefault(JSONObject())
                // Blank is "no pick" — drop the entry rather than storing an empty override.
                if (serial.isBlank()) obj.remove(projectKey) else obj.put(projectKey, serial)
                prefs[androidRunTargetProjectsKey] = obj.toString()
            }
        }
    }

    private val autoCloseIdleKey = booleanPreferencesKey("perf_auto_close_idle_terminals")

    /** When true, terminals sitting idle at the prompt (no foreground program, no I/O) past
     *  [idleTimeoutMinutes] are closed automatically to free their proot process trees + memory. */
    val autoCloseIdleTerminals: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[autoCloseIdleKey] ?: SettingsDefaults.AUTO_CLOSE_IDLE_TERMINALS }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.AUTO_CLOSE_IDLE_TERMINALS)

    fun setAutoCloseIdleTerminals(enabled: Boolean) {
        viewModelScope.launch { uiPreferences.edit { it[autoCloseIdleKey] = enabled } }
    }

    private val idleTimeoutMinKey = intPreferencesKey("perf_idle_timeout_minutes")

    /** Idle-terminal auto-close threshold in minutes (5…120). Default 30. */
    val idleTimeoutMinutes: StateFlow<Int> = uiPreferences.data
        .map { prefs -> (prefs[idleTimeoutMinKey] ?: SettingsDefaults.IDLE_TIMEOUT_MINUTES).coerceIn(5, 120) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.IDLE_TIMEOUT_MINUTES)

    fun setIdleTimeoutMinutes(minutes: Int) {
        viewModelScope.launch { uiPreferences.edit { it[idleTimeoutMinKey] = minutes.coerceIn(5, 120) } }
    }

    private val maxTerminalSessionsKey = intPreferencesKey("perf_max_terminal_sessions")

    /** Max concurrent terminal instances the "+" button will open (1…24). Default 12. */
    val maxTerminalSessions: StateFlow<Int> = uiPreferences.data
        .map { prefs -> (prefs[maxTerminalSessionsKey] ?: SettingsDefaults.MAX_TERMINAL_SESSIONS).coerceIn(1, 24) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.MAX_TERMINAL_SESSIONS)

    fun setMaxTerminalSessions(count: Int) {
        viewModelScope.launch { uiPreferences.edit { it[maxTerminalSessionsKey] = count.coerceIn(1, 24) } }
    }

    private val nestedShellTabsKey = booleanPreferencesKey("perf_nested_shell_tabs")

    /** When true, typing an interactive shell (`bash`/`zsh`/…) at a terminal relocates it into its own
     *  temporary tab that closes when the sub-shell exits, returning focus to the parent (OSC 7715). */
    val nestedShellTabs: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[nestedShellTabsKey] ?: SettingsDefaults.NESTED_SHELL_TABS }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.NESTED_SHELL_TABS)

    fun setNestedShellTabs(enabled: Boolean) {
        viewModelScope.launch { uiPreferences.edit { it[nestedShellTabsKey] = enabled } }
    }

    private val installTimeoutMinKey = intPreferencesKey("perf_install_timeout_minutes")

    /** Timeout (minutes, 5…180) for a toolchain INSTALL from the catalog (SDK/LSP/debugger). Large SDKs
     *  on a slow connection can exceed the 30-min default; pushed to [DistroService.catalogInstallTimeoutMs]. */
    val installTimeoutMinutes: StateFlow<Int> = uiPreferences.data
        .map { prefs -> (prefs[installTimeoutMinKey] ?: SettingsDefaults.INSTALL_TIMEOUT_MINUTES).coerceIn(5, 180) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.INSTALL_TIMEOUT_MINUTES)

    fun setInstallTimeoutMinutes(minutes: Int) {
        viewModelScope.launch { uiPreferences.edit { it[installTimeoutMinKey] = minutes.coerceIn(5, 180) } }
    }

    // Keep DistroService's install timeout in sync with the setting (this init runs after the flow above
    // is initialized; the main init block at the top of the class runs too early to reference it).
    init {
        viewModelScope.launch {
            installTimeoutMinutes.collect { distroService.catalogInstallTimeoutMs = it * 60_000L }
        }
    }


    private val envVarsKey = stringPreferencesKey("env_vars_json")

    /** User-defined environment variables (Settings → Env Var), applied to every terminal/run session.
     *  Stored as a JSON object (name → value); pushed to [TerminalSessionManager.userEnvVars]. */
    val envVars: StateFlow<Map<String, String>> = uiPreferences.data
        .map { prefs -> parseEnvVars(prefs[envVarsKey]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    /** Add or update [name]=[value]. Renames via [oldName]: when it differs from [name], the old key is
     *  dropped so an in-place rename doesn't leave a stale variable behind. */
    fun setEnvVar(name: String, value: String, oldName: String? = null) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val current = parseEnvVars(prefs[envVarsKey]).toMutableMap()
                if (oldName != null && oldName != trimmed) current.remove(oldName)
                current[trimmed] = value
                prefs[envVarsKey] = serializeEnvVars(current)
            }
        }
    }

    fun removeEnvVar(name: String) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val current = parseEnvVars(prefs[envVarsKey]).toMutableMap()
                current.remove(name)
                prefs[envVarsKey] = serializeEnvVars(current)
            }
        }
    }

    private fun parseEnvVars(json: String?): Map<String, String> {
        if (json.isNullOrBlank()) return emptyMap()
        return runCatching {
            val obj = org.json.JSONObject(json)
            buildMap { obj.keys().forEach { k -> put(k, obj.optString(k)) } }
        }.getOrDefault(emptyMap())
    }

    private fun serializeEnvVars(map: Map<String, String>): String {
        val obj = org.json.JSONObject()
        map.forEach { (k, v) -> obj.put(k, v) }
        return obj.toString()
    }

    // Apply the user env vars to every session the terminal manager spawns (terminals + run/build).
    init {
        viewModelScope.launch {
            envVars.collect { TerminalSessionHost.manager(appContext).userEnvVars = it }
        }
    }

    private val extraKeysPortraitKey = stringPreferencesKey("extra_keys_portrait")
    private val extraKeysLandscapeKey = stringPreferencesKey("extra_keys_landscape")

    /** Per-orientation visibility of the Termux-style extra-keys row (Esc/Tab/Ctrl/arrows…) shown
     *  above the keyboard while the terminal or editor is focused. Defaults: portrait = with the
     *  soft keyboard, landscape = hidden (little vertical room). */
    val extraKeysPortrait: StateFlow<ExtraKeysVisibility> = uiPreferences.data
        .map { prefs -> prefs[extraKeysPortraitKey].toExtraKeysVisibility(SettingsDefaults.EXTRA_KEYS_PORTRAIT) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.EXTRA_KEYS_PORTRAIT)

    val extraKeysLandscape: StateFlow<ExtraKeysVisibility> = uiPreferences.data
        .map { prefs -> prefs[extraKeysLandscapeKey].toExtraKeysVisibility(SettingsDefaults.EXTRA_KEYS_LANDSCAPE) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.EXTRA_KEYS_LANDSCAPE)

    fun setExtraKeysPortrait(mode: ExtraKeysVisibility) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[extraKeysPortraitKey] = mode.name }
        }
    }

    fun setExtraKeysLandscape(mode: ExtraKeysVisibility) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[extraKeysLandscapeKey] = mode.name }
        }
    }

    private val extraKeysFunctionKeysKey = booleanPreferencesKey("extra_keys_function_keys")

    /** Whether the extra-keys row appends F1-F12 chips for surfaces that consume them (terminal). */
    val extraKeysFunctionKeys: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[extraKeysFunctionKeysKey] ?: SettingsDefaults.EXTRA_KEYS_FUNCTION_KEYS }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.EXTRA_KEYS_FUNCTION_KEYS)

    fun setExtraKeysFunctionKeys(enabled: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[extraKeysFunctionKeysKey] = enabled }
        }
    }

    private fun String?.toExtraKeysVisibility(default: ExtraKeysVisibility): ExtraKeysVisibility =
        this?.let { runCatching { ExtraKeysVisibility.valueOf(it) }.getOrNull() } ?: default

    private val editorFontKey = stringPreferencesKey("editor_font")
    private val terminalFontKey = stringPreferencesKey("terminal_font")

    /** Selected monospace font id for the editor / terminal (see [MonoFontCatalog]). A saved id for a
     *  font that was removed from the catalog (e.g. the retired "System monospace") falls back to the
     *  default. */
    val editorFontId: StateFlow<String> = uiPreferences.data
        .map { prefs ->
            prefs[editorFontKey]?.ifBlank { null }?.takeUnless { it == MonoFontCatalog.RETIRED_SYSTEM }
                ?: MonoFontCatalog.EDITOR_DEFAULT
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MonoFontCatalog.EDITOR_DEFAULT)

    val terminalFontId: StateFlow<String> = uiPreferences.data
        .map { prefs ->
            prefs[terminalFontKey]?.ifBlank { null }?.takeUnless { it == MonoFontCatalog.RETIRED_SYSTEM }
                ?: MonoFontCatalog.TERMINAL_DEFAULT
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MonoFontCatalog.TERMINAL_DEFAULT)

    fun setEditorFont(id: String) {
        viewModelScope.launch { uiPreferences.edit { it[editorFontKey] = id } }
    }

    fun setTerminalFont(id: String) {
        viewModelScope.launch { uiPreferences.edit { it[terminalFontKey] = id } }
    }

    // --- Environment (distro) fonts ----------------------------------------------------------------
    // Monospace fonts installed in the Linux runtime (DejaVu Sans Mono ships with the base image;
    // users apt-install FiraCode / Nerd Fonts) discovered via fontconfig and loaded straight from the
    // rootfs on ext4. Offered in the editor/terminal font pickers next to the built-ins. Ids are
    // prefixed [MonoFontCatalog.ENV_PREFIX]: "env:default" follows `fc-match monospace`; "env:fam:<f>"
    // is a specific installed family.
    data class EnvironmentFont(val id: String, val name: String, val path: String)

    private val _environmentFonts = MutableStateFlow<List<EnvironmentFont>>(emptyList())
    val environmentFonts: StateFlow<List<EnvironmentFont>> = _environmentFonts.asStateFlow()

    init {
        // Discover once the rootfs is installed (root exec is enough — no need for the jcode user);
        // re-discover if the selected distro changes.
        viewModelScope.launch {
            distroService.environmentState
                .map { it.distroInstalled == true }
                .distinctUntilChanged()
                .collect { installed -> if (installed) refreshEnvironmentFonts() }
        }
    }

    /** Re-scan the runtime's installed monospace fonts (no-op until the rootfs is installed). Cheap
     *  enough to call whenever the font settings open, so newly apt-installed fonts appear without a
     *  restart. */
    fun refreshEnvironmentFonts() {
        viewModelScope.launch(Dispatchers.IO) {
            if (distroService.environmentState.value.distroInstalled != true) return@launch
            val fonts = runCatching { discoverEnvironmentFonts() }
                .onFailure { android.util.Log.w("JCode", "environment font discovery failed", it) }
                .getOrDefault(emptyList())
            if (fonts != _environmentFonts.value) _environmentFonts.value = fonts
        }
    }

    private suspend fun discoverEnvironmentFonts(): List<EnvironmentFont> {
        val rootfs = distroService.activeRootfsPath()
        fun hostFile(guestPath: String): File? {
            val p = guestPath.trim()
            if (p.isEmpty() || !p.startsWith("/")) return null
            return File(rootfs, p.removePrefix("/")).takeIf { it.isFile && it.canRead() }
        }
        // Enumerate mono/charcell families: "spacing|family|style|file" ('|' dodges tab-escaping through
        // the proot shell; fontconfig still interprets the trailing \n).
        val listCmd = "command -v fc-list >/dev/null 2>&1 && " +
            "fc-list -f '%{spacing}|%{family}|%{style}|%{file}\\n' : 2>/dev/null || true"
        val byFamily = LinkedHashMap<String, EnvironmentFont>()
        distroService.exec(listCmd, user = "root", raw = true).stdout.lineSequence().forEach { line ->
            val parts = line.split('|')
            if (parts.size < 4) return@forEach
            if ((parts[0].trim().toIntOrNull() ?: 0) < 100) return@forEach // fontconfig: mono=100, charcell=110
            val family = parts[1].substringBefore(',').trim().ifBlank { return@forEach }
            val host = hostFile(parts[3]) ?: return@forEach
            val style = parts[2].substringBefore(',').trim()
            val isRegular = style.isEmpty() || style.equals("Regular", true) ||
                style.equals("Book", true) || style.equals("Normal", true) || style.equals("Medium", true)
            if (isRegular || family !in byFamily) {
                byFamily[family] = EnvironmentFont("${MonoFontCatalog.ENV_PREFIX}fam:$family", family, host.absolutePath)
            }
        }
        val out = mutableListOf<EnvironmentFont>()
        // The environment's default monospace (follows fontconfig), shown first as "Distro monospace".
        val matchCmd = "command -v fc-match >/dev/null 2>&1 && fc-match -f '%{file}' monospace 2>/dev/null || true"
        hostFile(distroService.exec(matchCmd, user = "root", raw = true).stdout)
            ?.let { out.add(EnvironmentFont("${MonoFontCatalog.ENV_PREFIX}default", "Distro monospace", it.absolutePath)) }
        out.addAll(byFamily.values.sortedBy { it.name.lowercase() })
        return out
    }

    private val bottomStatusBarKey = stringPreferencesKey("bottom_status_bar")

    /** Visibility of the workbench's bottom status bar (branch/distro/caret). Default: hide it while
     *  the soft keyboard is up. */
    val bottomStatusBar: StateFlow<BottomBarVisibility> = uiPreferences.data
        .map { prefs ->
            prefs[bottomStatusBarKey]?.let { runCatching { BottomBarVisibility.valueOf(it) }.getOrNull() }
                ?: SettingsDefaults.BOTTOM_STATUS_BAR
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.BOTTOM_STATUS_BAR)

    fun setBottomStatusBar(mode: BottomBarVisibility) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[bottomStatusBarKey] = mode.name }
        }
    }

    private val headerActionButtonKey = stringPreferencesKey("header_action_button")

    /** What the workbench header's quick-action button does (terminal, palette, or nothing). */
    val headerActionButton: StateFlow<HeaderActionButton> = uiPreferences.data
        .map { prefs ->
            prefs[headerActionButtonKey]?.let { runCatching { HeaderActionButton.valueOf(it) }.getOrNull() }
                ?: SettingsDefaults.HEADER_ACTION_BUTTON
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.HEADER_ACTION_BUTTON)

    fun setHeaderActionButton(button: HeaderActionButton) {
        viewModelScope.launch { uiPreferences.edit { it[headerActionButtonKey] = button.name } }
    }

    private val volumeUpActionKey = stringPreferencesKey("volume_up_action")
    private val volumeDownActionKey = stringPreferencesKey("volume_down_action")

    /** Action bound to the hardware Volume Up button; [VolumeKeyAction.SystemDefault] = normal volume. */
    val volumeUpAction: StateFlow<VolumeKeyAction> = uiPreferences.data
        .map { prefs ->
            prefs[volumeUpActionKey]?.let { runCatching { VolumeKeyAction.valueOf(it) }.getOrNull() }
                ?: SettingsDefaults.VOLUME_UP_ACTION
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.VOLUME_UP_ACTION)

    /** Action bound to the hardware Volume Down button; [VolumeKeyAction.SystemDefault] = normal volume. */
    val volumeDownAction: StateFlow<VolumeKeyAction> = uiPreferences.data
        .map { prefs ->
            prefs[volumeDownActionKey]?.let { runCatching { VolumeKeyAction.valueOf(it) }.getOrNull() }
                ?: SettingsDefaults.VOLUME_DOWN_ACTION
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.VOLUME_DOWN_ACTION)

    fun setVolumeUpAction(action: VolumeKeyAction) {
        viewModelScope.launch { uiPreferences.edit { it[volumeUpActionKey] = action.name } }
    }

    fun setVolumeDownAction(action: VolumeKeyAction) {
        viewModelScope.launch { uiPreferences.edit { it[volumeDownActionKey] = action.name } }
    }

    // Built-in Command Palette commands the user switched off (Settings → Command Palette); stored
    // as a JSON array of command ids so the default (everything enabled) needs no migration.
    private val paletteDisabledKey = stringPreferencesKey("palette_disabled_commands")

    val paletteDisabledCommands: StateFlow<Set<String>> = uiPreferences.data
        .map { prefs ->
            runCatching {
                val arr = org.json.JSONArray(prefs[paletteDisabledKey] ?: "[]")
                buildSet { for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotBlank() }?.let(::add) }
            }.getOrDefault(emptySet())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    fun setPaletteCommandEnabled(id: String, enabled: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val current = runCatching {
                    val arr = org.json.JSONArray(prefs[paletteDisabledKey] ?: "[]")
                    buildSet { for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotBlank() }?.let(::add) }
                }.getOrDefault(emptySet())
                val next = if (enabled) current - id else current + id
                prefs[paletteDisabledKey] = org.json.JSONArray(next.toList()).toString()
            }
        }
    }

    /** Volume-key actions that must run in the Compose layer (focused-pane arrows/scroll, command
     *  palette). Undo/Redo are invoked directly by the Activity. Collected by JCodeShell. */
    private val _volumeKeyAction = MutableSharedFlow<VolumeKeyAction>(extraBufferCapacity = 8)
    val volumeKeyAction = _volumeKeyAction.asSharedFlow()

    fun emitVolumeKeyAction(action: VolumeKeyAction) {
        _volumeKeyAction.tryEmit(action)
    }

    private val hideTabCloseButtonKey = booleanPreferencesKey("hide_tab_close_button")

    /** When true, the "×" close button is hidden on editor + terminal tabs to avoid accidental
     *  closes; a tab is then closed via its long-press menu. */
    val hideTabCloseButton: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[hideTabCloseButtonKey] ?: SettingsDefaults.HIDE_TAB_CLOSE_BUTTON }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.HIDE_TAB_CLOSE_BUTTON)

    fun setHideTabCloseButton(enabled: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[hideTabCloseButtonKey] = enabled }
        }
    }

    private val markdownWrapPortraitKey = booleanPreferencesKey("markdown_wrap_portrait")

    /** Markdown preview: wrap to the viewport in portrait (default). When off, portrait previews
     *  lay out at landscape width (the screen height, honoring the cutout setting) and pan sideways. */
    val markdownWrapPortrait: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[markdownWrapPortraitKey] ?: SettingsDefaults.MARKDOWN_WRAP_PORTRAIT }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.MARKDOWN_WRAP_PORTRAIT)

    fun setMarkdownWrapPortrait(enabled: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[markdownWrapPortraitKey] = enabled }
        }
    }

    private val editorFontSizeGlobalKey = floatPreferencesKey("editor_font_size_global")

    /** App-level (Global settings) editor font-size default, applied when no workspace/project .jcode
     *  override exists. Pushed into [ConfigService] so it feeds the effective font-size merge. */
    val editorFontSizeGlobal: StateFlow<Float> = uiPreferences.data
        .map { prefs -> (prefs[editorFontSizeGlobalKey] ?: SettingsDefaults.EDITOR_FONT_SIZE).coerceIn(8f, 72f) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.EDITOR_FONT_SIZE)

    fun setEditorFontSizeGlobal(size: Float) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[editorFontSizeGlobalKey] = size.coerceIn(8f, 72f) }
        }
    }

    /** Text scale for imported .vsix extension webviews, as a percentage. See
     *  [dev.blamspot.jcode.design.ExtensionFontSizeSetting] for why this is a scale and not a size. */
    private val extensionFontScaleKey = intPreferencesKey("extension_font_scale")
    val extensionFontScale: StateFlow<Int> = uiPreferences.data
        .map { prefs -> (prefs[extensionFontScaleKey] ?: SettingsDefaults.EXTENSION_FONT_SCALE).coerceIn(50, 300) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.EXTENSION_FONT_SCALE)

    fun setExtensionFontScale(percent: Int) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[extensionFontScaleKey] = percent.coerceIn(50, 300) }
        }
    }

    private val terminalFontSizeGlobalKey = floatPreferencesKey("terminal_font_size_global")

    /** App-level (Global settings) terminal font size, in sp. Unlike the editor's, this has no
     *  workspace/project override — a terminal is not tied to one file tree. */
    val terminalFontSizeGlobal: StateFlow<Float> = uiPreferences.data
        .map { prefs -> (prefs[terminalFontSizeGlobalKey] ?: SettingsDefaults.TERMINAL_FONT_SIZE).coerceIn(6f, 40f) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.TERMINAL_FONT_SIZE)

    fun setTerminalFontSizeGlobal(size: Float) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[terminalFontSizeGlobalKey] = size.coerceIn(6f, 40f) }
        }
    }

    private val editorWordWrapKey = booleanPreferencesKey("editor_word_wrap")

    /** App-level (Global settings) editor word-wrap toggle. Drives [dev.blamspot.jcode.core.editor.RenderConfig]
     *  soft-wrap for every open editor tab. */
    val editorWordWrap: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[editorWordWrapKey] ?: SettingsDefaults.EDITOR_WORD_WRAP }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.EDITOR_WORD_WRAP)

    fun setEditorWordWrap(enabled: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[editorWordWrapKey] = enabled }
        }
    }

    private val diagnosticLoggingKey = booleanPreferencesKey("diagnostic_logging")
    private val diagnosticLevelKey = stringPreferencesKey("diagnostic_level")
    private val diagnosticSystemLogKey = booleanPreferencesKey("diagnostic_system_log")
    private val diagnosticCrashesKey = booleanPreferencesKey("diagnostic_crashes")

    /** Settings → Diagnostics, opt-in. Collected into [DiagnosticLog.configure] below, which is the
     *  only thing that ever starts recording. */
    data class DiagnosticsPrefs(
        val enabled: Boolean = SettingsDefaults.DIAGNOSTIC_LOGGING,
        val level: DiagLevel = SettingsDefaults.DIAGNOSTIC_LEVEL,
        val captureSystemLog: Boolean = SettingsDefaults.DIAGNOSTIC_SYSTEM_LOG,
        val captureCrashes: Boolean = SettingsDefaults.DIAGNOSTIC_CRASHES,
    )

    val diagnosticsPrefs: StateFlow<DiagnosticsPrefs> = uiPreferences.data
        .map { prefs ->
            DiagnosticsPrefs(
                enabled = prefs[diagnosticLoggingKey] ?: SettingsDefaults.DIAGNOSTIC_LOGGING,
                level = prefs[diagnosticLevelKey]
                    ?.let { name -> DiagLevel.entries.firstOrNull { it.name == name } }
                    ?: SettingsDefaults.DIAGNOSTIC_LEVEL,
                captureSystemLog = prefs[diagnosticSystemLogKey] ?: SettingsDefaults.DIAGNOSTIC_SYSTEM_LOG,
                captureCrashes = prefs[diagnosticCrashesKey] ?: SettingsDefaults.DIAGNOSTIC_CRASHES,
            )
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, DiagnosticsPrefs())

    fun setDiagnosticLogging(enabled: Boolean) = editDiagnostics { it[diagnosticLoggingKey] = enabled }

    fun setDiagnosticLevel(level: DiagLevel) = editDiagnostics { it[diagnosticLevelKey] = level.name }

    fun setDiagnosticSystemLog(enabled: Boolean) = editDiagnostics { it[diagnosticSystemLogKey] = enabled }

    fun setDiagnosticCrashes(enabled: Boolean) = editDiagnostics { it[diagnosticCrashesKey] = enabled }

    private fun editDiagnostics(edit: (MutablePreferences) -> Unit) {
        viewModelScope.launch { uiPreferences.edit { prefs -> edit(prefs) } }
    }

    private val developerOptionsKey = booleanPreferencesKey("developer_options")

    /** Developer options (off by default): reveals extension-authoring tools — the Extension Dev
     *  right-drawer tab, and permits an unsigned extension's native code to load into this process.
     *  Importing an unsigned package is not gated by it; see [importExtension]. */
    val developerOptions: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[developerOptionsKey] ?: SettingsDefaults.DEVELOPER_OPTIONS }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.DEVELOPER_OPTIONS)

    fun setDeveloperOptions(enabled: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[developerOptionsKey] = enabled }
        }
    }

    // A third init block, for the reason the second one gives: [developerOptions] is declared just
    // above and the main init block at the top of the class runs long before it exists.
    //
    // Developer options is what lets an unsigned, sideloaded pack load code into JCode's process.
    // Pushed into the loader rather than read on demand, because the loader is called from the
    // composition and a DataStore read is suspending.
    init {
        viewModelScope.launch {
            var previous: Boolean? = null
            developerOptions.collect { allowed ->
                NativeExtensionLoader.setAllowUnsigned(appContext, allowed)
                // Whatever asked for the device before this flag arrived got a refusal -- the pack
                // is unsigned and the loader only takes unsigned code once this is on -- and
                // [VirtualDeviceBridge.device] caches that answer for the life of the process. Two
                // collectors start in this init and the other one reaches the device through
                // stopVirtualDeviceAdb, so a DataStore read losing that race left the virtual device
                // dead with developer options visibly ON, and a restart only re-ran the race.
                // Dropping the cached refusal is what makes the switch mean anything after startup;
                // nothing is running this early, so there is no live device to lose.
                if (allowed && previous != true) VirtualDeviceBridge.evict()
                previous = allowed
            }
        }
    }

    private val rightDrawerPersistentKey = booleanPreferencesKey("right_drawer_persistent")

    /** In landscape, dock the right drawer beside the editor at half the screen instead of sliding it
     *  over as a modal sheet. Ignored in portrait, where there is no width to share. */
    val rightDrawerPersistent: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[rightDrawerPersistentKey] ?: SettingsDefaults.RIGHT_DRAWER_PERSISTENT }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.RIGHT_DRAWER_PERSISTENT)

    fun setRightDrawerPersistent(enabled: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[rightDrawerPersistentKey] = enabled }
        }
    }

    private val rightDrawerWidthKey = floatPreferencesKey("right_drawer_width_fraction")

    /**
     * Share of the docked split the right drawer takes, set by dragging the divider.
     *
     * Clamped on the way out as well as in: a width stored under a wider range than the current one
     * would otherwise survive it, and the panes are only guaranteed usable inside the range.
     */
    val rightDrawerWidthFraction: StateFlow<Float> = uiPreferences.data
        .map { prefs ->
            (prefs[rightDrawerWidthKey] ?: SettingsDefaults.RIGHT_DRAWER_PERSISTENT_FRACTION)
                .coerceIn(
                    SettingsDefaults.RIGHT_DRAWER_MIN_FRACTION,
                    SettingsDefaults.RIGHT_DRAWER_MAX_FRACTION,
                )
        }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            SettingsDefaults.RIGHT_DRAWER_PERSISTENT_FRACTION,
        )

    fun setRightDrawerWidthFraction(fraction: Float) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                prefs[rightDrawerWidthKey] = fraction.coerceIn(
                    SettingsDefaults.RIGHT_DRAWER_MIN_FRACTION,
                    SettingsDefaults.RIGHT_DRAWER_MAX_FRACTION,
                )
            }
        }
    }

    private val editorDragMovesCursorKey = booleanPreferencesKey("editor_drag_moves_cursor")

    /** When true, a one-finger drag on the editor moves the text cursor (the view follows) instead of
     *  scrolling the content; long-press text selection is unaffected. */
    val editorDragMovesCursor: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[editorDragMovesCursorKey] ?: SettingsDefaults.EDITOR_DRAG_MOVES_CURSOR }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.EDITOR_DRAG_MOVES_CURSOR)

    fun setEditorDragMovesCursor(enabled: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[editorDragMovesCursorKey] = enabled }
        }
    }

    private val editorCursorDragVerticalKey = intPreferencesKey("editor_cursor_drag_vertical_level")
    private val editorCursorDragHorizontalKey = intPreferencesKey("editor_cursor_drag_horizontal_level")

    /** "Drag to move cursor" sensitivity per axis: 1 (slow/precise) … 5 (fast). Default 2. */
    val editorCursorDragVerticalLevel: StateFlow<Int> = uiPreferences.data
        .map { prefs -> (prefs[editorCursorDragVerticalKey] ?: SettingsDefaults.CURSOR_DRAG_LEVEL).coerceIn(1, 5) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.CURSOR_DRAG_LEVEL)

    val editorCursorDragHorizontalLevel: StateFlow<Int> = uiPreferences.data
        .map { prefs -> (prefs[editorCursorDragHorizontalKey] ?: SettingsDefaults.CURSOR_DRAG_LEVEL).coerceIn(1, 5) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.CURSOR_DRAG_LEVEL)

    fun setEditorCursorDragVerticalLevel(level: Int) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[editorCursorDragVerticalKey] = level.coerceIn(1, 5) }
        }
    }

    fun setEditorCursorDragHorizontalLevel(level: Int) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[editorCursorDragHorizontalKey] = level.coerceIn(1, 5) }
        }
    }

    private val restoreLastSessionKey = booleanPreferencesKey("restore_last_session")

    /** When true (default), the last open workspace/project + editor tabs (with unsaved changes) are
     *  reopened on launch, surviving a force-close or swipe-away from Recents. */
    val restoreLastSession: StateFlow<Boolean> = uiPreferences.data
        .map { prefs -> prefs[restoreLastSessionKey] ?: SettingsDefaults.RESTORE_LAST_SESSION }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.RESTORE_LAST_SESSION)

    fun setRestoreLastSession(enabled: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[restoreLastSessionKey] = enabled }
        }
        // Opting out should not leave a stale session blob behind on disk.
        if (!enabled) viewModelScope.launch(Dispatchers.IO) { sessionStore.clear() }
    }

    private val sessionStore = SessionStore(appContext)

    /** Gate that keeps incremental saves from clobbering the stored session before restore has read it. */
    @Volatile
    private var sessionSaveEnabled = false

    private val sessionSaveSignal = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    private fun scheduleSessionSave() {
        sessionSaveSignal.tryEmit(Unit)
    }

    /** Events pushed to the live extension WebView as `window.JCode._onEvent(name, jsonString)`.
     *  Declared BEFORE the init block: its collector emits during ViewModel construction. */
    private val _extensionEvents = MutableSharedFlow<Pair<String, String>>(extraBufferCapacity = 16)
    val extensionEvents: SharedFlow<Pair<String, String>> = _extensionEvents

    private val themeBundleKey = stringPreferencesKey("theme_bundle_id")

    /** App-wide selected theme bundle id; empty resolves to the default bundle. */
    val themeBundleId: StateFlow<String> = uiPreferences.data
        .map { prefs -> prefs[themeBundleKey].orEmpty() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "")

    fun setThemeBundle(id: String) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[themeBundleKey] = id }
        }
    }

    // The key predates the split into two sets and still holds the UI one, so upgrading keeps
    // whichever icon set was already chosen instead of silently resetting it to Material.
    private val uiIconSetKey = stringPreferencesKey("icon_bundle_id")

    /** App-wide selected UI icon set id; empty resolves to the default (Material) set. */
    val uiIconSetId: StateFlow<String> = uiPreferences.data
        .map { prefs -> prefs[uiIconSetKey].orEmpty() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "")

    fun setUiIconSet(id: String) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[uiIconSetKey] = id }
        }
    }

    private val fileIconSetKey = stringPreferencesKey("file_icon_set_id")

    /** App-wide selected file icon set id; empty means JCode's own folder/file glyphs. */
    val fileIconSetId: StateFlow<String> = uiPreferences.data
        .map { prefs -> prefs[fileIconSetKey].orEmpty() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "")

    fun setFileIconSet(id: String) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[fileIconSetKey] = id }
        }
    }

    /**
     * Icon sets provided by installed extensions, loaded off the main thread.
     *
     * Derived from [installedExtensions] rather than scanned separately, so installing or removing a
     * pack updates the Settings list and the live chrome in one step. `IconPackLoader` memoizes each
     * parse, so re-deriving on every extension refresh costs a map lookup per pack.
     */
    val installedUiIconSets: StateFlow<List<UiIconSet>> = _installedExtensions
        .map { extensions ->
            extensions.flatMap { ext ->
                ext.contributes.iconSets.uiIndexes.mapNotNull { index ->
                    IconPackLoader.uiIconSet(index, ext.id, ext.name, IconPackLayout.localId(index))
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** File/folder icon sets provided by installed extensions. There are no built-in ones. */
    val installedFileIconSets: StateFlow<List<FileIconSet>> = _installedExtensions
        .map { extensions ->
            extensions.flatMap { ext ->
                ext.contributes.iconSets.filesIndexes.mapNotNull { index ->
                    IconPackLoader.fileIconSet(index, ext.id, ext.name, IconPackLayout.localId(index))
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())


    private val formatterKey = stringPreferencesKey("formatter_id")

    /** App-wide formatter selection; "builtin" is the built-in formatter. Formatter extensions
     *  (type: formatter) appear as options once installed. */
    val formatterId: StateFlow<String> = uiPreferences.data
        .map { prefs -> prefs[formatterKey]?.takeIf { it.isNotBlank() } ?: "builtin" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "builtin")

    fun setFormatter(id: String) {
        viewModelScope.launch {
            uiPreferences.edit { prefs -> prefs[formatterKey] = id }
        }
    }

    // "Open web previews in" — which browser Build & Run / URL taps use. A global default plus a
    // per-project override (device-local: which browser apps exist is not portable project config).
    /** Installed browser apps, discovered once (the set rarely changes within a session). */
    val installedBrowsers: List<dev.blamspot.jcode.design.BrowserApp> by lazy { dev.blamspot.jcode.run.ProjectRunner.installedBrowsers(appContext) }

    private val webPreviewBrowserKey = stringPreferencesKey("web_preview_browser")

    /** Global default: SYSTEM (device default) | ASK (chooser) | a browser package name. */
    val webPreviewBrowser: StateFlow<String> = uiPreferences.data
        .map { prefs -> prefs[webPreviewBrowserKey]?.takeIf { it.isNotBlank() } ?: "SYSTEM" }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "SYSTEM")

    fun setWebPreviewBrowser(choice: String) {
        viewModelScope.launch { uiPreferences.edit { it[webPreviewBrowserKey] = choice } }
    }

    private val webPreviewBrowserProjectsKey = stringPreferencesKey("web_preview_browser_projects")

    /** Per-project overrides keyed by project id; absent = inherit the global default. */
    val webPreviewBrowserProjects: StateFlow<Map<String, String>> = uiPreferences.data
        .map { prefs -> parseStringMap(prefs[webPreviewBrowserProjectsKey]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    fun setProjectWebPreviewBrowser(projectKey: String, choice: String) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val obj = runCatching { JSONObject(prefs[webPreviewBrowserProjectsKey] ?: "{}") }.getOrDefault(JSONObject())
                // Blank/INHERIT means "follow the global default" — drop the override to keep the blob minimal.
                if (choice.isBlank()) obj.remove(projectKey) else obj.put(projectKey, choice)
                prefs[webPreviewBrowserProjectsKey] = obj.toString()
            }
        }
    }

    private fun parseStringMap(json: String?): Map<String, String> {
        if (json.isNullOrBlank()) return emptyMap()
        return runCatching {
            val obj = JSONObject(json)
            buildMap { obj.keys().forEach { k -> put(k, obj.optString(k)) } }
        }.getOrDefault(emptyMap())
    }

    // Per-extension activation mode (auto-start / on-demand / manual), keyed by extension id. Stored as a
    // small JSON object (only non-default entries) in one preference, mirroring how SessionStore persists
    // structured data with org.json. Absent id => ExtensionActivation.Default (OnDemand).
    private val extensionActivationKey = stringPreferencesKey("extension_activation_modes")

    val extensionActivations: StateFlow<Map<String, ExtensionActivation>> = uiPreferences.data
        .map { prefs -> parseActivations(prefs[extensionActivationKey]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    /** Installed extensions whose contributions are currently allowed to apply (i.e. not set to Manual).
     *  Drives language-pack resolution for highlighting/completions/formatting so Manual truly disables. */
    val activeLanguageExtensions: StateFlow<List<InstalledExtension>> =
        combine(installedExtensions, extensionActivations) { exts, modes ->
            exts.filter { it.enabledIn(modes) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private fun parseActivations(json: String?): Map<String, ExtensionActivation> {
        if (json.isNullOrBlank()) return emptyMap()
        return runCatching {
            val obj = JSONObject(json)
            buildMap {
                obj.keys().forEach { key -> put(key, ExtensionActivation.from(obj.optString(key))) }
            }
        }.getOrDefault(emptyMap())
    }

    fun setExtensionActivation(id: String, mode: ExtensionActivation) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val obj = runCatching { JSONObject(prefs[extensionActivationKey] ?: "{}") }.getOrDefault(JSONObject())
                if (mode == ExtensionActivation.Default) obj.remove(id) else obj.put(id, mode.name)
                prefs[extensionActivationKey] = obj.toString()
            }
        }
    }

    private fun clearExtensionActivation(id: String) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val obj = runCatching { JSONObject(prefs[extensionActivationKey] ?: "{}") }.getOrDefault(JSONObject())
                obj.remove(id)
                prefs[extensionActivationKey] = obj.toString()
            }
        }
    }

    // ----- Custom extension sources (user-added .vsix release repos) -------------------------------
    // An "extension source" is a GitHub repo URL whose releases publish `.vsix` files. JCode resolves
    // each repo's newest `.vsix` release and, for an extension installed from a source, folds an
    // "Update available" entry into the same Extensions list as the built-in marketplace. Managed on
    // the Extension Sources page (Extensions panel → Sources button). This is how a VSIX extension
    // like OpenChamber gets updated inside JCode — the host owns updates, the extension doesn't.

    private val extensionSourcesKey = stringPreferencesKey("extension_sources")

    /** User-added source repo URLs (JSON array). */
    val extensionSources: StateFlow<List<String>> = uiPreferences.data
        .map { prefs -> parseStringList(prefs[extensionSourcesKey]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    // Attribution: installed extension id -> the source URL it came from, so an update check knows
    // which repo to poll. JSON object; cleared on uninstall. Same shape as extensionActivations.
    private val extensionSourceOfIdKey = stringPreferencesKey("extension_source_of_id")

    val extensionSourceOfId: StateFlow<Map<String, String>> = uiPreferences.data
        .map { prefs -> parseStringMap(prefs[extensionSourceOfIdKey]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    /** Newest `.vsix` release resolved per source URL (in-memory; refreshed from GitHub). Absent =
     *  not fetched yet or none found. */
    private val _sourceReleases = MutableStateFlow<Map<String, ProviderRelease>>(emptyMap())
    val sourceReleases: StateFlow<Map<String, ProviderRelease>> = _sourceReleases.asStateFlow()

    private val _sourcesRefreshing = MutableStateFlow(false)
    val sourcesRefreshing: StateFlow<Boolean> = _sourcesRefreshing.asStateFlow()

    /**
     * The extensions the Extensions panel lists: the built-in marketplace index, plus a synthesized
     * entry per custom source — so a source's extension is offered in the same list as a marketplace
     * one, and an installed one badges "Update available" when its source publishes a newer release.
     * Keying the synthesized entry by the id the extension installs under makes the existing
     * `marketStatus`/`isUpdateAvailable` logic cover both with no UI change; its
     * [MarketplaceEntry.vsixAssetUrl] routes the install back to the source's release asset.
     */
    val marketplaceEntries: StateFlow<List<MarketplaceEntry>> =
        combine(_marketplaceEntries, _installedExtensions, extensionSourceOfId, _sourceReleases) {
            market, installed, attribution, releases ->
            val marketIds = market.mapTo(mutableSetOf()) { it.id }
            val installedById = installed.associateBy { it.id }
            val fromSources = releases.mapNotNull { (sourceUrl, release) ->
                val id = sourceExtensionId(sourceUrl, release, attribution)
                if (id in marketIds) return@mapNotNull null       // the built-in index already lists it
                val ext = installedById[id]
                // Installed and current: the installed extension is already its own row, and listing
                // the source too would double it.
                if (ext != null && !isUpdateAvailable(release.version, ext.version)) return@mapNotNull null
                MarketplaceEntry(
                    id = id,
                    name = ext?.name ?: release.displayName ?: sourceRepoName(sourceUrl) ?: id,
                    author = ext?.author ?: release.publisher,
                    authors = ext?.authors.orEmpty(),
                    // Everything a `.vsix` installs as is an app; before install there is nothing
                    // else to go on, and afterwards the installed record is authoritative anyway.
                    type = ext?.type ?: ExtensionType.App,
                    category = null,
                    subcategory = null,
                    version = release.version,
                    jext = null,
                    iconUrl = release.iconUrl,
                    description = ext?.description?.takeIf { it.isNotBlank() } ?: release.description,
                    longDescription = ext?.longDescription ?: release.description,
                    vsixAssetUrl = release.vsixAssetUrl,
                )
            }
            market + fromSources
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /**
     * The id a source's extension installs under: what a previous install from it was attributed to,
     * else what the repo's own manifest declares — which also matches a copy imported by hand, so
     * adding the source to a `.vsix` already installed starts tracking its updates. A repo that
     * exposes neither gets a stand-in keyed by the repo, so the source still lists and installs; the
     * real id takes over from the attribution recorded on that first install.
     */
    private fun sourceExtensionId(
        sourceUrl: String,
        release: ProviderRelease,
        attribution: Map<String, String>,
    ): String =
        attribution.entries.firstOrNull { it.value.equals(sourceUrl, ignoreCase = true) }?.key
            ?: release.extensionId
            ?: (SOURCE_EXTENSION_ID_PREFIX + (ProviderReleaseFetcher.parseRepo(sourceUrl) ?: sourceUrl))

    private fun sourceRepoName(sourceUrl: String): String? =
        ProviderReleaseFetcher.parseRepo(sourceUrl)?.substringAfterLast('/')

    private fun parseStringList(json: String?): List<String> {
        if (json.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = org.json.JSONArray(json)
            buildList { for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotBlank() }?.let(::add) }
        }.getOrDefault(emptyList())
    }

    /** Add a custom source (a GitHub repo URL whose releases publish `.vsix` files) and fetch it. */
    fun addExtensionSource(url: String) {
        openNativePackagesPage(0)
        viewModelScope.launch { emitMessage("The native official library is maintained by sui-code. Third-party packages can be imported locally after review.") }
    }

    /** Remove a custom source. Any extension installed from it stays installed; its attribution is
     *  kept so re-adding the source still recognizes the installed copy. */
    fun removeExtensionSource(url: String) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val current = parseStringList(prefs[extensionSourcesKey])
                prefs[extensionSourcesKey] =
                    org.json.JSONArray(current.filterNot { it.equals(url, ignoreCase = true) }).toString()
            }
            _sourceReleases.value = _sourceReleases.value - url
        }
    }

    /** Re-resolve the newest `.vsix` release for every configured source. */
    fun refreshExtensionSources() = refreshMarketplace()
    fun installFromSource(url: String) = openNativePackagesPage(0)

    fun openNativePackagesPage(section: Int) {
        require(section in 0..3)
        _bringEditorToFront.tryEmit(Unit)
        openDetailPage("sui-native-packages:$section",EditorPageKind.ExtensionSources) {
            if(section==3) "Languages" else "Packages"
        }
        if(section==3) viewModelScope.launch { distroService.checkSdkStatuses();distroService.checkLspStatuses();distroService.checkDebugEngineStatuses() }
    }
    fun openExtensionSourcesPage() = openNativePackagesPage(0)

    val workspaceConfig = configService.workspaceConfig
    val projectConfig = configService.projectConfig
    val workspaceConfigError = configService.workspaceError
    val projectConfigError = configService.projectError
    val effectiveConfig: StateFlow<EffectiveConfig> = configService.effectiveConfig
    val themeMode: StateFlow<ThemeMode> = effectiveConfig
        .map { ThemeMode.fromConfigId(it.theme.id) }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            ThemeMode.fromConfigId(effectiveConfig.value.theme.id),
        )
    val environmentState = distroService.environmentState
    val environments = distroService.environments
    val sdkCatalogState = distroService.sdkCatalogState
    val lspCatalogState = distroService.lspCatalogState
    val debugCatalogState = distroService.debugCatalogState
    val autoSetupProgress = distroService.autoSetupProgress

    /** Percentage + phase of the running toolchain install, for the manager pages' progress bar. */
    val catalogProgress = distroService.catalogProgress

    private val _sdkInstallRequestedId = MutableStateFlow<String?>(null)

    /** The SDK the user actually pressed Install on, which is not necessarily the one running: a
     *  required toolchain (the Android SDK pulls in its prerequisites, ~500 MB of JDK and build
     *  tools) installs first under its own id. The detail page reads this so it can keep showing
     *  progress — and say whose — instead of an unexplained spinner for the first several minutes. */
    val sdkInstallRequestedId: StateFlow<String?> = _sdkInstallRequestedId.asStateFlow()

    private val debugController = DebugController(distroService, viewModelScope)
    val debugState = debugController.state
    val debugCallStack = debugController.callStack
    val debugVariables = debugController.variables
    val debugOutput = debugController.output
    val debugLocation = debugController.currentLocation

    /** Breakpoints per host file path -> set of 0-based lines. Toggled from the editor gutter. */
    private val _breakpoints = MutableStateFlow<Map<String, Set<Int>>>(emptyMap())
    val breakpoints: StateFlow<Map<String, Set<Int>>> = _breakpoints.asStateFlow()

    /** Toggle a breakpoint at [line] (0-based) in the file at host [path]. */
    fun toggleBreakpoint(path: String, line: Int) {
        val next = _breakpoints.value.toMutableMap()
        val lines = next[path]?.toMutableSet() ?: mutableSetOf()
        if (!lines.add(line)) lines.remove(line)
        if (lines.isEmpty()) next.remove(path) else next[path] = lines
        _breakpoints.value = next
        debugController.onBreakpointsChanged(path, next[path].orEmpty())
    }

    /** Start debugging the given host file with a matching debug engine (debugpy for .py, …). */
    fun startDebug(hostPath: String) {
        // The adapter compiles and reads source off disk, so unsaved buffers are written first and
        // awaited — stepping through a file the editor has already moved past is worse than a pause
        // before the session starts. startDebugForConfig routes through here too, so every way of
        // starting a debug session saves. A buffer that cannot be written reports that itself; the
        // save failure cancels debugging so it cannot run stale source.
        viewModelScope.launch {
            if (!saveAllDirtyAwait()) { emitMessage(nativePackages.uiText("message.Debugcancelledfilescouldnotbesaved")); return@launch }
            debugController.startDebug(hostPath, deriveProjectDir(hostPath), _breakpoints.value)
        }
    }

    private fun deriveProjectDir(hostPath: String): String {
        val source=File(hostPath).canonicalFile
        val selected=(selectedProject.value?.fsPath as? FsPath.Local)?.file?.canonicalFile
        if(selected!=null && source.toPath().startsWith(selected.toPath())) return selected.path
        val markers=dev.suicode.nativehost.NativeLanguageServices.entries(nativePackages.rows.value) { }.flatMap { it.rootDetectors }.filter { it.matches(Regex("[A-Za-z0-9_.-]+")) }
        val internal=dev.blamspot.jcode.fs.InternalFiles.root(appContext.filesDir).canonicalFile.toPath()
        val projects=File(dev.blamspot.jcode.core.distro.WorkspaceHostPaths.projectsRoot).canonicalFile.toPath()
        val boundary=when { source.toPath().startsWith(internal) -> internal;source.toPath().startsWith(projects) -> projects;else -> source.parentFile?.toPath() ?: source.toPath() }
        var folder=source.parentFile
        while(folder!=null && folder.toPath().startsWith(boundary)) {
            if(markers.any { File(folder,it).exists() }) return folder.path
            folder=folder.parentFile
        }
        return source.parent ?: source.path
    }

    fun debugContinue() = debugController.resume()
    fun debugStepOver() = debugController.stepOver()
    fun debugStepInto() = debugController.stepInto()
    fun debugStepOut() = debugController.stepOut()
    fun debugPause() = debugController.pause()
    fun debugStop() = debugController.stop()
    fun debugEvaluate(
        expression: String,
        onResult: (dev.blamspot.jcode.core.debug.DapEvaluation?) -> Unit,
    ) = debugController.evaluate(expression, onResult)
    fun debugVariables(
        reference: Int,
        onResult: (List<dev.blamspot.jcode.core.debug.DapVariable>) -> Unit,
    ) = debugController.variables(reference, onResult)

    // ---- Issues (diagnostics bus) producers ----

    private val diagnosticsBus = dev.blamspot.jcode.core.lsp.LspModule.diagnosticsBus

    // ---- Language servers (LSP) ----

    private val lspController = dev.blamspot.jcode.lsp.LspController(
        distroService = distroService,
        scope = viewModelScope,
        diagnosticsBus = diagnosticsBus,
        documentText = ::openDocumentText,
        openDocumentPaths = {
            _editorGroup.value.tabs
                .filter { !it.isPage && it.filePath.path.isNotBlank() }
                .map { it.filePath.path }
        },
        isServerPaired = ::isLanguageServerPaired,
    )

    /**
     * Whether an installed extension pairs with [serverId] for [fileName].
     *
     * Two ways to pair, because Dev Packs predate the catalog ids: an explicit `requires.lsps` /
     * `suggests.lsps` entry naming the server, or a Dev Pack that claims the file's language — a pack
     * owning `.css` is what makes the CSS server that language's implementation. Without either, a
     * catalog match on the file extension alone is not enough to start a server.
     */
    private fun isLanguageServerPaired(serverId: String, fileName: String): Boolean =
        nativePackages.rows.value.any { row ->
            row.record.enabled && row.pack.kind == dev.suicode.packages.PackKind.KIT &&
                dev.suicode.packages.Capability.LSP in row.record.grants &&
                row.pack.declarations().any { component ->
                    component.type == "lsp" &&
                        component.descriptor["arguments"]?.let { args ->
                            val data = args as? kotlinx.serialization.json.JsonObject
                            (data?.get("serverId") as? kotlinx.serialization.json.JsonPrimitive)?.content == serverId
                        } == true
                } && row.pack.manifest["dependencies"]?.let { deps ->
                    (deps as? kotlinx.serialization.json.JsonArray)?.any { dep ->
                        val id = (((dep as? kotlinx.serialization.json.JsonObject)?.get("id")) as? kotlinx.serialization.json.JsonPrimitive)?.content
                        nativePackages.rows.value.any { basic ->
                            basic.record.id == id && basic.record.enabled && basic.pack.declarations().any { declaration ->
                                declaration.type == "language" &&
                                    (declaration.descriptor["extensions"] as? kotlinx.serialization.json.JsonArray)?.any { extension ->
                                        (extension as? kotlinx.serialization.json.JsonPrimitive)?.content == fileName.substringAfterLast('.', "")
                                    } == true
                            }
                        }
                    } == true
                } == true
        }

    /** Running language servers, surfaced in the status bar. */
    val lspServers = lspController.servers

    /** A catalog server an opened file needs but which isn't installed; drives the install prompt. */
    val lspMissingServer = lspController.missingServer

    /**
     * The live buffer for an open tab, as the language server needs to see it. Defensive because a
     * tab can close (and its snapshot be released) between the controller resolving a document and
     * reading it.
     */
    private fun openDocumentText(hostPath: String): String? = runCatching {
        val state = _editorGroup.value.tabs
            .firstOrNull { !it.isPage && it.filePath.path == hostPath }
            ?.editorState ?: return@runCatching null
        val snapshot = state.snapshot.value
        snapshot.readRangeAsUtf16(0, snapshot.byteLength)
    }.getOrNull()

    /** Definitions/references awaiting a pick; null when no picker is open. */
    private val _lspLocationPicker = MutableStateFlow<LspLocationPicker?>(null)
    val lspLocationPicker: StateFlow<LspLocationPicker?> = _lspLocationPicker.asStateFlow()

    /** A rename waiting on a new name from the dialog. */
    private val _lspRenameRequest = MutableStateFlow<LspRenameRequest?>(null)
    val lspRenameRequest: StateFlow<LspRenameRequest?> = _lspRenameRequest.asStateFlow()

    fun dismissLspLocationPicker() { _lspLocationPicker.value = null }

    fun dismissLspRename() { _lspRenameRequest.value = null }

    /**
     * Completions from the language server for the caret position, filtered to the typed prefix and
     * capped: a server answering a bare `.` returns every member in scope, which is more than a
     * phone-sized popup can usefully show.
     */
    /**
     * Semantic tokens for a DevTools page source, from a server the workspace already has running.
     *
     * Nothing here is guaranteed and nothing is reported: it is a colouring improvement offered
     * when the pieces happen to be in place. See
     * [dev.blamspot.jcode.lsp.LspController.detachedSemanticTokens].
     */
    suspend fun devtoolsSemanticTokens(fileName: String, text: String): List<dev.blamspot.jcode.lsp.SemanticToken> =
        runCatching { lspController.detachedSemanticTokens(fileName, text) }.getOrDefault(emptyList())

    suspend fun lspCompletions(
        hostPath: String,
        line: Int,
        character: Int,
        prefix: String,
    ): List<CompletionItem> {
        if (hostPath.isBlank()) return emptyList()
        val items = lspController.completions(hostPath, line, character).map { it.toEditorItem() }
        val matching = if (prefix.isBlank()) {
            items
        } else {
            items.filter { it.filterText.startsWith(prefix, ignoreCase = true) }
        }
        return matching.take(MAX_LSP_COMPLETIONS)
    }

    /** Editor context-menu language actions, resolved against the byte [offset] that was pressed. */
    fun editorLanguageAction(action: EditorLanguageAction, word: String, offset: Int) {
        if (action == EditorLanguageAction.FormatDocument) {
            formatActiveTab()
            return
        }
        val tab = _editorGroup.value.activeTab?.takeIf { !it.isPage } ?: return
        val state = tab.editorState ?: return
        val path = tab.filePath.path
        val (line, character) = state.snapshot.value.offsetToUtf16Position(offset)
        viewModelScope.launch {
            when (action) {
                EditorLanguageAction.GoToDefinition -> lspGoToDefinition(path, line, character, word)
                EditorLanguageAction.FindReferences -> lspFindReferences(path, line, character, word)
                EditorLanguageAction.RenameSymbol -> lspBeginRename(path, line, character, word)
                EditorLanguageAction.FormatDocument -> Unit // handled above
            }
        }
    }

    private suspend fun lspGoToDefinition(path: String, line: Int, character: Int, word: String) {
        if (!requireLanguageServer(path, LspFeature.Definition, "Go to Definition")) return
        val targets = lspController.definition(path, line, character)
        when (targets.size) {
            0 -> emitMessage(nativePackages.uiText("message.noDefinition", mapOf("symbol" to (word).toString())))
            1 -> openLspLocation(targets.first())
            else -> _lspLocationPicker.value =
                LspLocationPicker("Definitions of \"$word\"", targets.toEntries())
        }
    }

    private suspend fun lspFindReferences(path: String, line: Int, character: Int, word: String) {
        if (!requireLanguageServer(path, LspFeature.References, "Find References")) return
        val results = lspController.references(path, line, character)
        if (results.isEmpty()) {
            emitMessage(nativePackages.uiText("message.noReferences", mapOf("symbol" to (word).toString())))
            return
        }
        _lspLocationPicker.value = LspLocationPicker("References to \"$word\"", results.toEntries())
    }

    private suspend fun lspBeginRename(path: String, line: Int, character: Int, word: String) {
        if (!requireLanguageServer(path, LspFeature.Rename, "Rename Symbol")) return
        if (word.isBlank()) {
            emitMessage(nativePackages.uiText("message.Putthecursoronasymboltorename"))
            return
        }
        _lspRenameRequest.value = LspRenameRequest(path, line, character, word)
    }

    /** Second half of a rename: ask the server for the edits, then apply them. */
    fun confirmLspRename(newName: String) {
        val request = _lspRenameRequest.value ?: return
        _lspRenameRequest.value = null
        val trimmed = newName.trim()
        if (trimmed.isEmpty() || trimmed == request.symbol) return
        viewModelScope.launch {
            val edit = lspController.rename(request.path, request.line, request.character, trimmed)
            if (edit == null || edit.isEmpty) {
                emitMessage(nativePackages.uiText("message.cannotRename", mapOf("symbol" to (request.symbol).toString())))
                return@launch
            }
            val applied = applyWorkspaceEdit(edit)
            emitMessage(
                if (applied) {
                    "Renamed to \"$trimmed\" in ${edit.fileCount} " +
                        if (edit.fileCount == 1) "file" else "files"
                } else {
                    nativePackages.uiText("message.Renamefailed")
                },
            )
        }
    }

    fun openLspLocationEntry(entry: LspLocationEntry) {
        _lspLocationPicker.value = null
        viewModelScope.launch {
            openLspLocation(LocationResult(entry.path, entry.line, entry.character))
        }
    }

    private suspend fun openLspLocation(location: LocationResult) {
        if (!location.path.startsWith("/") && location.path.contains("://")) {
            val text = lspController.virtualDocument(location.path)
            if (text == null) { emitMessage(nativePackages.uiText("message.sourceLoadFailed", mapOf("path" to (location.path).toString()))); return }
            val digest = java.security.MessageDigest.getInstance("SHA-256").digest(location.path.toByteArray()).joinToString("") { "%02x".format(it) }
            val file = withContext(Dispatchers.IO) {
                File(getApplication<Application>().cacheDir,"language-sources/$digest/" + location.path.substringBefore('?').substringAfterLast('/').ifBlank { "Source.java" }.removeSuffix(".class")+".java").apply { parentFile!!.mkdirs();writeText(text) }
            }
            openLocalFile(file,line=location.line+1,column=location.character+1)
            _editorGroup.value.tabs.firstOrNull { it.filePath.path==file.path }?.editorState?.readOnly=true
            return
        }
        val file = File(location.path)
        if (!file.isFile) {
            emitMessage(nativePackages.uiText("message.fileMissing", mapOf("name" to (file.name).toString())))
            return
        }
        _bringEditorToFront.tryEmit(Unit)
        // openLocalFile takes 1-based coordinates; LSP counts from 0.
        openLocalFile(file, line = location.line + 1, column = location.character + 1)
    }

    private fun List<LocationResult>.toEntries(): List<LspLocationEntry> = map { location ->
        LspLocationEntry(
            path = location.path,
            line = location.line,
            character = location.character,
            preview = sourceLinePreview(location.path, location.line),
        )
    }

    /** The text of one line, preferring an open buffer over disk so unsaved edits show through. */
    private fun sourceLinePreview(path: String, line: Int): String = runCatching {
        val state = _editorGroup.value.tabs
            .firstOrNull { !it.isPage && it.filePath.path == path }
            ?.editorState
        val text = if (state != null) {
            val snapshot = state.snapshot.value
            if (line >= snapshot.lineCount) return@runCatching ""
            snapshot.lineText(line)
        } else {
            File(path).useLines { lines -> lines.drop(line).firstOrNull() } ?: ""
        }
        text.trim().take(PREVIEW_MAX_CHARS)
    }.getOrDefault("")

    /**
     * Explains why a language action can't run instead of silently doing nothing: the reason differs
     * between "no server for this file type", "not installed", "still starting" and "this server has
     * no such capability", and each has a different fix.
     */
    private suspend fun requireLanguageServer(
        path: String,
        feature: LspFeature,
        actionLabel: String,
    ): Boolean {
        val status = lspController.statusFor(path)
        if (status == null) {
            val name = File(path).name
            val descriptor = dev.blamspot.jcode.core.lsp.LspServerDescriptor.findForFile(name)
            val entry = descriptor?.let { LspServerCatalog.findById(it.id) }
            emitMessage(
                when {
                    descriptor == null -> "$actionLabel needs a language server; none supports $name"
                    // Unpaired: the server may well be installed, but no extension claims this
                    // language, so pointing at Toolchains would send the user to the wrong place.
                    !isLanguageServerPaired(descriptor.id, name) ->
                        "$actionLabel needs an enabled IDE Kit for $name; install one from Native Packages"
                    descriptor.id !in lspCatalogState.value.installedEntryIds ->
                        "$actionLabel needs ${entry?.name ?: descriptor.id}; install it from Toolchains"
                    else -> "$actionLabel needs the Linux environment to be ready"
                },
            )
            return false
        }
        if (status.state != LspState.READY) {
            emitMessage(
                when (status.state) {
                    LspState.ERROR -> "${status.name} failed to start${status.detail?.let { ": $it" } ?: ""}"
                    else -> "${status.name} is still starting"
                },
            )
            return false
        }
        if (!lspController.supports(path, feature)) {
            emitMessage("${status.name} doesn't support $actionLabel")
            return false
        }
        return true
    }

    /**
     * Apply a server-produced edit set. Open tabs go through [dev.blamspot.jcode.core.editor.EditorState] so
     * the change is undoable and the tab shows dirty; closed files are rewritten on disk.
     */
    private suspend fun applyWorkspaceEdit(edit: WorkspaceEditResult): Boolean = runCatching {
        edit.editsByPath.forEach { (path, edits) ->
            if (edits.isEmpty()) return@forEach
            val state = _editorGroup.value.tabs
                .firstOrNull { !it.isPage && it.filePath.path == path }
                ?.editorState
            if (state != null) applyEditsToBuffer(state, edits) else applyEditsToFile(File(path), edits)
        }
        notifyWorkspaceFilesChanged()
        true
    }.getOrElse {
        emitMessage(nativePackages.uiText("message.applyEditsFailed", mapOf("reason" to (it.message ?: "error").toString())))
        false
    }

    private suspend fun applyEditsToBuffer(
        state: dev.blamspot.jcode.core.editor.EditorState,
        edits: List<TextEditResult>,
    ) {
        val snapshot = state.snapshot.value
        // Applied last-first so an earlier edit's offsets are still valid when it is its turn.
        resolveEdits(edits) { line, character -> snapshot.utf16PositionToOffset(line, character) }
            .forEach { (start, end, text) -> state.applyEdit(EditTx.replace(start, end, text)) }
    }

    private fun applyEditsToFile(file: File, edits: List<TextEditResult>) {
        if (!file.isFile) return
        val original = file.readText()
        dev.blamspot.jcode.core.buffer.Buffer.fromText(original).use { buffer ->
            val snapshot = buffer.snapshot()
            val resolved = resolveEdits(edits) { line, character ->
                snapshot.utf16PositionToOffset(line, character)
            }
            var latest = snapshot
            resolved.forEach { (start, end, text) ->
                latest = buffer.applyEdit(EditTx.replace(start, end, text))
            }
            dev.blamspot.jcode.fs.SafeLocalFiles.write(file,latest.readRangeAsUtf16(0, latest.byteLength).toByteArray(Charsets.UTF_8))
        }
    }

    /** LSP (line, character) ranges -> descending byte ranges, so edits don't invalidate each other. */
    private fun resolveEdits(
        edits: List<TextEditResult>,
        toOffset: (line: Int, character: Int) -> Int,
    ): List<Triple<Int, Int, String>> = edits
        .map { edit ->
            val start = toOffset(edit.startLine, edit.startChar)
            val end = toOffset(edit.endLine, edit.endChar).coerceAtLeast(start)
            Triple(start, end, edit.newText)
        }
        .sortedByDescending { it.first }

    init {
        viewModelScope.launch {
            _editorGroup.collect { group ->
                val tab=group.activeTab?.takeIf { !it.isPage }
                if(tab!=null) { nativeSourceId=tab.id;nativePackages.setSource(tab.filePath.path) }
                else if(group.tabs.none { it.id==nativeSourceId }) { nativeSourceId=null;nativePackages.setSource(null) }
            }
        }
        fun runProjectTask(request: dev.suicode.packages.Request): dev.suicode.packages.Reply {
                val tab=nativeSourceTab()
                val project=(selectedProject.value?.fsPath as? FsPath.Local)?.file ?: tab?.filePath?.path?.let { File(deriveProjectDir(it)) }
                return if(project==null) dev.suicode.packages.Reply(false,"E_CONTEXT")
                else {
                    val source=tab?.filePath?.takeIf { it.canonicalFile.toPath().startsWith(project.canonicalFile.toPath()) } ?: project
                    val recipe=nativePackages.recipe(request.packageId,request.component,request.arguments.filterKeys { it.startsWith("input.") }.mapKeys { it.key.removePrefix("input.") })
                    val accepted=javaQuickRun.startTool(source,project,recipe) { saveAllDirtyAwait() }
                    dev.suicode.packages.Reply(accepted,if(accepted) "STARTING" else "E_BUSY")
                }
        }
        listOf(dev.suicode.packages.Operation.BUILD,dev.suicode.packages.Operation.TEST).forEach { operation ->
            nativePackages.bind(operation,dev.suicode.packages.CoreBackend(::runProjectTask))
        }
        nativePackages.bind(dev.suicode.packages.Operation.PROJECT_READ,dev.suicode.packages.CoreBackend { request ->
            val project=selectedProject.value
            if(project==null && request.arguments["action"]=="statistics") return@CoreBackend dev.suicode.packages.Reply(true,"NOT_APPLICABLE",mapOf("name" to "No Project selected", "files" to "N/A", "bytes" to "N/A", "reason" to "Internal Files can run independently. Open a Project for project statistics."))
            val root=(project?.fsPath as? FsPath.Local)?.file ?: dev.blamspot.jcode.fs.InternalFiles.root(appContext.filesDir)
            var count=0L;var bytes=0L
            if(request.arguments["action"]=="statistics") java.nio.file.Files.walkFileTree(root.toPath(),object: java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
                override fun visitFile(path: java.nio.file.Path,attrs: java.nio.file.attribute.BasicFileAttributes): java.nio.file.FileVisitResult {
                    if(attrs.isRegularFile) { count++;bytes+=attrs.size() }
                    return java.nio.file.FileVisitResult.CONTINUE
                }
            })
            dev.suicode.packages.Reply(true,"READ",mapOf("name" to (project?.name ?: "Internal Files"),"root" to root.path)+if(request.arguments["action"]=="statistics") mapOf("files" to count.toString(),"bytes" to bytes.toString()) else emptyMap())
        })
        nativePackages.bind(dev.suicode.packages.Operation.SIMPLE_RUN, dev.suicode.packages.CoreBackend { request ->
            val component=nativePackages.rows.value.firstOrNull { it.record.id==request.packageId }?.pack?.declarations()?.firstOrNull { it.id==request.component }
            if(component?.type=="command" || component?.type=="workflow") return@CoreBackend runProjectTask(request)
            val tab=nativeSourceTab()
            val provider=tab?.takeIf { !it.isPage }?.let { nativePackages.resolve(it.filePath.name) }
            if(provider==null || provider.pack.id!=request.packageId || provider.pack.digest!=request.digest || component?.descriptor?.get("languageId")?.jsonPrimitive?.content!=provider.languageId) dev.suicode.packages.Reply(false,"E_CONTEXT")
            else {
                val recipe=nativePackages.recipe(request.packageId,request.component)
                val accepted=javaQuickRun.startTool(tab!!.filePath,tab.filePath.parentFile!!,recipe) { saveTabAwait(tab) }
                dev.suicode.packages.Reply(accepted,if(accepted) "STARTING" else "E_BUSY")
            }
        })
        nativePackages.bind(dev.suicode.packages.Operation.LSP_START, dev.suicode.packages.CoreBackend {
            val tab = nativeSourceTab()
            if (tab == null || tab.isPage || !distroService.isRuntimeReady()) dev.suicode.packages.Reply(false,"E_CONTEXT")
            else {
                viewModelScope.launch { lspController.documentOpened(tab.filePath.path) }
                dev.suicode.packages.Reply(true,"STARTING")
            }
        })
        nativePackages.bind(dev.suicode.packages.Operation.FORMAT, dev.suicode.packages.CoreBackend {
            val tab = nativeSourceTab()
            if (tab == null || tab.isPage || !lspController.supports(tab.filePath.path,LspFeature.Formatting)) dev.suicode.packages.Reply(false,"E_UNAVAILABLE")
            else {
                viewModelScope.launch {
                    if (formatWithLanguageServer(tab)) emitMessage(nativePackages.uiText("message.formatted", mapOf("name" to (tab.title).toString())))
                    else emitMessage(nativePackages.uiText("message.Languageserverreturnednoformattingedits"))
                }
                dev.suicode.packages.Reply(true,"REQUESTED")
            }
        })
        nativePackages.bind(dev.suicode.packages.Operation.LINT, dev.suicode.packages.CoreBackend {
            val tab = nativeSourceTab()
            if (tab == null || tab.isPage) dev.suicode.packages.Reply(false,"E_CONTEXT")
            else {
                viewModelScope.launch { lspController.documentOpened(tab.filePath.path); lspController.documentChanged(tab.filePath.path) }
                dev.suicode.packages.Reply(true,"REQUESTED")
            }
        })
        nativePackages.bind(dev.suicode.packages.Operation.DAP_START, dev.suicode.packages.CoreBackend { request ->
            val action=request.arguments["action"] ?: "start"
            if(action=="state") dev.suicode.packages.Reply(true,"READ",mapOf("state" to if(debugController.ownedBy(request.packageId)) debugController.state.value.name else "INACTIVE"))
            else if(action!="start") {
                if(!debugController.ownedBy(request.packageId)) dev.suicode.packages.Reply(false,"E_CONTEXT")
                else if(action !in setOf("continue","pause","next","stepIn","stepOut","stop")) dev.suicode.packages.Reply(false,"E_COMPONENT")
                else {
                    viewModelScope.launch(Dispatchers.Main.immediate) {
                        when(action) { "continue" -> debugController.resume();"pause" -> debugController.pause();"next" -> debugController.stepOver();"stepIn" -> debugController.stepInto();"stepOut" -> debugController.stepOut();"stop" -> debugController.stop() }
                    }
                    dev.suicode.packages.Reply(true,"REQUESTED")
                }
            } else {
                val tab=nativeSourceTab()
                val engine=tab?.let { debugController.debugEngineIdFor(it.filePath.path) }?.let { dev.blamspot.jcode.core.distro.DebugEngineCatalog.findById(it) }
                if(tab==null || engine?.ownerPackage!=request.packageId) dev.suicode.packages.Reply(false,"E_CONTEXT")
                else { startDebug(tab.filePath.path);dev.suicode.packages.Reply(true,"STARTING") }
            }
        })
        debugController.resolveKitPlan = { engine,source,project ->
            dev.suicode.nativehost.NativeDebugPlans.resolve(nativePackages,distroService,engine,source,project) { path,command,arguments -> lspController.executeCommand(path,command,arguments) }
        }
        // Code actions and some servers' rename flows push edits instead of returning them.
        lspController.onApplyEdit = { edit ->
            withContext(Dispatchers.Main) {
                val allowed=edit.editsByPath.keys.all { path ->
                    nativePackages.rows.value.any { row ->
                        row.record.enabled && dev.suicode.packages.Capability.FILE_WRITE in row.record.grants &&
                            row.pack.declarations().any { component ->
                                component.type=="lsp" && component.descriptor["arguments"]?.let { args ->
                                    val id=(((args as? kotlinx.serialization.json.JsonObject)?.get("serverId")) as? kotlinx.serialization.json.JsonPrimitive)?.content
                                    id!=null && isLanguageServerPaired(id,File(path).name)
                                }==true
                            }
                    }
                }
                if(allowed) applyWorkspaceEdit(edit) else { emitMessage("IDE Kit edit rejected: file.write permission or language scope is missing");false }
            }
        }
        // Installing (or removing) a Dev Pack changes which servers are paired, so the files already
        // open have to be re-evaluated rather than waiting for the user to reopen them.
        viewModelScope.launch {
            nativePackages.rows.map { rows -> rows.map { it.record } }.distinctUntilChanged().collect {
                refreshInstalledExtensions()
                lspController.shutdownAll()
                dev.suicode.nativehost.NativeLanguageServices.refreshAndCheck(nativePackages,distroService) { error -> _messages.tryEmit(error) }
                lspController.retryOpenDocuments()
            }
        }
        // .jcode YAML config parse errors are real project issues; mirror them onto the bus.
        viewModelScope.launch {
            configService.workspaceError.collect { err ->
                publishConfigDiagnostic("config-workspace", configService.workspaceConfigPath, err)
            }
        }
        viewModelScope.launch {
            configService.projectError.collect { err ->
                publishConfigDiagnostic("config-project", configService.projectConfigPath, err)
            }
        }
    }

    private fun publishConfigDiagnostic(source: String, path: String?, error: String?) {
        if (error == null || path == null) {
            diagnosticsBus.clearSource(source)
            return
        }
        // snakeyaml errors carry "line N, column M" (1-based); default to the file top otherwise.
        val pos = Regex("""line (\d+), column (\d+)""").find(error)
        val line = ((pos?.groupValues?.get(1)?.toIntOrNull() ?: 1) - 1).coerceAtLeast(0)
        val col = ((pos?.groupValues?.get(2)?.toIntOrNull() ?: 1) - 1).coerceAtLeast(0)
        val message = error.lineSequence().firstOrNull { it.isNotBlank() }?.trim() ?: error
        diagnosticsBus.updateSourceDiagnostics(
            source,
            mapOf(
                path to listOf(
                    LspDiagnostic(line, col, line, col, LspDiagnosticSeverity.ERROR, message, "jcode-config", null),
                ),
            ),
        )
    }

    /**
     * On-open/on-save syntax check for the flagship script languages: a one-shot compile inside the
     * distro (no artifacts written), its errors published to the Issues bus. Silent no-op when the
     * runtime isn't ready, the file lives outside /workspace, or the language has no checker.
     */
    private fun queueSyntaxCheck(file: File) {
        val projectsRoot = dev.blamspot.jcode.core.distro.WorkspaceHostPaths.projectsRoot.trimEnd('/')
        if (!file.path.startsWith("$projectsRoot/")) return
        val guest = hostToGuestPath(file)
        val command = when (file.extension.lowercase()) {
            "py", "pyw" ->
                "python3 -c \"import sys; compile(open(sys.argv[1]).read(), sys.argv[1], 'exec')\" '$guest'"
            "js", "mjs", "cjs" ->
                "command -v node >/dev/null 2>&1 || exit 0; node --check '$guest'"
            else -> return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val result = runCatching { distroService.exec(command, timeoutMs = 30_000L) }.getOrNull() ?: return@launch
            if (result.internalError != null) return@launch // runtime not ready: leave issues untouched
            val diagnostics = if (result.succeeded) emptyList() else parseSyntaxErrors(result.stderr, guest)
            diagnosticsBus.updateDiagnostics("syntax", file.path, diagnostics)
        }
    }

    /** Pull (line, message) out of python/node syntax-error stderr for [guestPath]. */
    private fun parseSyntaxErrors(stderr: String, guestPath: String): List<LspDiagnostic> {
        if (stderr.isBlank()) return emptyList()
        val lines = stderr.lineSequence().map { it.trimEnd() }.filter { it.isNotBlank() }.toList()
        // python: File "<path>", line N — node: <path>:N at the very first line.
        val lineNo = lines.firstNotNullOfOrNull { l ->
            Regex("""File "${Regex.escape(guestPath)}", line (\d+)""").find(l)?.groupValues?.get(1)?.toIntOrNull()
        } ?: lines.firstNotNullOfOrNull { l ->
            Regex("""^${Regex.escape(guestPath)}:(\d+)""").find(l)?.groupValues?.get(1)?.toIntOrNull()
        } ?: 1
        val message = lines.lastOrNull { Regex("""^\w*(Error|Warning)\b""").containsMatchIn(it) }
            ?: lines.last()
        return listOf(
            LspDiagnostic(
                startLine = (lineNo - 1).coerceAtLeast(0),
                startCol = 0,
                endLine = (lineNo - 1).coerceAtLeast(0),
                endCol = 0,
                severity = LspDiagnosticSeverity.ERROR,
                message = message.take(300),
                source = "syntax",
                code = null,
            ),
        )
    }

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages = _messages.asSharedFlow()

    private val _updateInfo = MutableStateFlow<UpdateInfo?>(null)
    /** Latest GitHub-release check result, or null until the first successful check. */
    val updateInfo = _updateInfo.asStateFlow()
    private val _updateChecking = MutableStateFlow(false)
    val updateChecking = _updateChecking.asStateFlow()

    /** Query GitHub for the latest release and update [updateInfo]. Runs once on startup and on
     *  demand from Settings; a failed/offline check leaves the previous result untouched. */
    fun checkForUpdate() {
        viewModelScope.launch { emitMessage("sui-code builds are delivered through the Fork's verified Actions artifacts; the upstream app updater is disabled.") }
    }

    /** In-app updater state (download progress + install result), driven by [AppUpdateInstaller]. */
    val updateInstallState = AppUpdateInstaller.state

    /** Download + install the latest release APK in-app. No-op when the release published no `.apk`
     *  asset — the UI then falls back to opening the release page. */
    fun installUpdate(context: android.content.Context) {
        val apkUrl = _updateInfo.value?.apkUrl ?: return
        val appContext = context.applicationContext
        viewModelScope.launch {
            AppUpdateInstaller.downloadAndInstall(appContext, apkUrl) {
                try {
                    prepareMigrationForUpdate { detail -> _envBackupStatus.value = detail }
                } finally {
                    _envBackupStatus.value = null
                }
            }
        }
    }

    fun resetUpdateInstall() = AppUpdateInstaller.reset()

    /**
     * Install an update whose data could not be carried across.
     *
     * The new install starts empty and this one is left untouched, so nothing is destroyed by
     * choosing it — but the environment does not follow, which is why it is a choice and not a
     * fallback taken silently.
     */
    fun installUpdateWithoutMigration(apkPath: String) {
        val appContext = getApplication<Application>().applicationContext
        viewModelScope.launch { AppUpdateInstaller.installDownloaded(appContext, apkPath) }
    }

    /** On returning to the foreground, clear a stuck in-app-update "Installing…" state left behind when
     *  the user dismisses the system installer without completing it (see [AppUpdateInstaller.recoverIfStuck]). */
    fun onAppResumed() {
        viewModelScope.launch { AppUpdateInstaller.recoverIfStuck() }
    }

    init {
        checkForUpdate()
    }

    /** Emitted when a file is opened from the terminal, so the shell can surface the editor. */
    private val _bringEditorToFront = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val bringEditorToFront = _bringEditorToFront.asSharedFlow()

    init {
        viewModelScope.launch { runCatching { nativePackages.restore() }.onFailure { emitMessage(it.message ?: "Native package restore failed") } }
        viewModelScope.launch { refreshInstalledExtensions() }

        viewModelScope.launch {
            currentWorkspace.collectLatest { workspace ->
                val currentSelection = _selectedProjectId.value
                if (workspace?.projects?.none { it.id == currentSelection } != false) {
                    _selectedProjectId.value = workspace?.projects?.firstOrNull()?.id
                }
            }
        }

        viewModelScope.launch {
            combine(currentWorkspace, selectedProject) { workspace, project ->
                workspace to project
            }.collectLatest { (workspace, project) ->
                val workspaceRoot = workspace?.rootPath?.let(::File)
                val projectRoot = (project?.fsPath as? FsPath.Local)?.file
                configService.bindLocalConfigFiles(workspaceRoot, projectRoot)
            }
        }

        // Feed the Global-settings font-size default into the config merge; setGlobalEditorFontSize
        // re-publishes effectiveConfig, so the collector below live-updates open editors.
        viewModelScope.launch {
            editorFontSizeGlobal.collect { configService.setGlobalEditorFontSize(it) }
        }
        viewModelScope.launch {
            editorWordWrap.collect { configService.setGlobalEditorWordWrap(it) }
        }

        // The ONLY thing that starts diagnostic recording: it follows the user's opt-in and stops
        // the moment they switch it back off.
        viewModelScope.launch {
            diagnosticsPrefs.collect { prefs ->
                DiagnosticLog.configure(
                    context = appContext,
                    enabled = prefs.enabled,
                    level = prefs.level,
                    captureSystemLog = prefs.captureSystemLog,
                    captureCrashes = prefs.captureCrashes,
                )
            }
        }

        viewModelScope.launch {
            effectiveConfig.collectLatest { applyEffectiveConfigToOpenTabs(it) }
        }

        viewModelScope.launch {
            combine(
                currentWorkspace,
                selectedProject,
                effectiveConfig.map { it.distro }.distinctUntilChanged(),
            ) { workspace, project, distro ->
                Triple(workspace, project, distro)
            }.collectLatest { (workspace, project, distro) ->
                withContext(Dispatchers.IO) {
                    val projectHostPath = (project?.fsPath as? FsPath.Local)?.file?.absolutePath
                    // Bind every local project of the workspace so a multi-repo extension (Source Control)
                    // can reach each repo at its guest target; the selected project stays the primary bind.
                    val projectBinds = workspace?.projects.orEmpty().mapNotNull { p ->
                        ((p.fsPath as? FsPath.Local)?.file?.absolutePath)?.let { it to p.distroBindTarget }
                    }
                    distroService.updateRuntimeConfig(
                        distroConfig = distro,
                        projectHostPath = projectHostPath,
                        projectTargetPath = project?.distroBindTarget,
                        projectBinds = projectBinds,
                    )
                    distroService.refreshEnvironment()
                }
            }
        }

        // Restore the previous session (workspace/project + tabs + unsaved edits) on cold launch, then
        // enable incremental persistence. Runs once per process: init fires only when the ViewModel is
        // freshly built, which is exactly the cold-launch / post-process-death case we restore for.
        viewModelScope.launch { restoreSessionOnLaunch() }

        // Debounced session writer: coalesce bursts of edits/tab changes into one disk write.
        viewModelScope.launch {
            sessionSaveSignal.collectLatest {
                delay(700)
                persistSession()
            }
        }
        // Structural changes (tab open/close/switch, dirty-dot flips) and project/workspace switches.
        viewModelScope.launch { editorGroup.collect { scheduleSessionSave() } }
        viewModelScope.launch { selectedProject.collect { scheduleSessionSave() } }

        // Push the focused-file context to the live extension WebView (Extension API `activeFile`
        // event); deduped so tab-internal churn doesn't spam the bridge.
        viewModelScope.launch {
            var last: String? = null
            editorGroup.collect {
                val json = activeFileEventJson()
                if (json != last) {
                    last = json
                    _extensionEvents.tryEmit("activeFile" to json)
                }
            }
        }
    }

    data class NewItemRequest(
        val name: String,
        val isWorkspace: Boolean,
        val templateId: String?,
        /** Values the user picked for the template's declared inputs, keyed by input id. */
        val inputs: Map<String, String> = emptyMap(),
    )

    fun requestNew() {
        templateScaffolder.reset()
        _showNewItemDialog.value = true
    }

    fun dismissNewDialog() {
        _showNewItemDialog.value = false
        templateScaffolder.reset()
    }

    // ---- Extension-contributed shell actions (e.g. the SCM extension's Clone / Remote Repo) ----

    /** An action an installed extension contributes to a host surface; tapping opens that extension's
     *  own view (route == the action id) in the editor area. */
    data class ShellContribution(
        val extId: String,
        val id: String,
        val label: String,
        val icon: String? = null,
        val fileExtensions: List<String> = emptyList(),
        val targets: List<String> = emptyList(),
    )

    /** Actions active extensions contribute to the empty-editor start screen (their required tools met). */
    val contributedEditorStartActions: StateFlow<List<ShellContribution>> =
        combine(installedExtensions, extensionActivations, distroService.sdkCatalogState) { exts, acts, sdk ->
            availableContributions(exts, acts, sdk) { it.editorStartActions }
        }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5_000L), emptyList())

    /** Actions active extensions contribute to the left-drawer "Open Folder" dropdown. */
    val contributedDrawerActions: StateFlow<List<ShellContribution>> =
        combine(installedExtensions, extensionActivations, distroService.sdkCatalogState) { exts, acts, sdk ->
            availableContributions(exts, acts, sdk) { it.drawerActions }
        }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5_000L), emptyList())

    /** Actions active extensions contribute to the editor's long-press context menu. The shell filters
     *  them per active file via [ShellContribution.fileExtensions]. */
    val contributedEditorContextActions: StateFlow<List<ShellContribution>> =
        combine(installedExtensions, extensionActivations, distroService.sdkCatalogState) { exts, acts, sdk ->
            availableContributions(exts, acts, sdk) { it.editorContextActions }
        }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5_000L), emptyList())

    /** Actions active extensions contribute to the explorer's file/folder context menu. The explorer
     *  filters them per row via [ShellContribution.fileExtensions] and [ShellContribution.targets]. */
    val contributedExplorerContextActions: StateFlow<List<ShellContribution>> =
        combine(installedExtensions, extensionActivations, distroService.sdkCatalogState) { exts, acts, sdk ->
            availableContributions(exts, acts, sdk) { it.explorerContextActions }
        }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5_000L), emptyList())

    /**
     * Managers extensions contribute to the Toolchains panel.
     *
     * Not gated on `requires.sdks` the way the other surfaces are, and deliberately: a manager for a
     * toolchain is most useful *before* that toolchain is installed, which is exactly when the gate
     * would hide it. Android's SDK Manager is how you install the Android SDK, so requiring the
     * Android SDK to see it would be a door locked from the inside.
     */
    val contributedToolchainActions: StateFlow<List<ShellContribution>> =
        combine(installedExtensions, extensionActivations) { exts, acts ->
            exts.filter { it.enabledIn(acts) }
                .flatMap { ext ->
                    ext.contributes.toolchainActions.map { ShellContribution(ext.id, it.id, it.label, it.icon) }
                }
                .distinctBy { it.extId + ":" + it.id }
        }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5_000L), emptyList())

    /**
     * Republish the debug adapters installed extensions bring, so the Debug Engine manager and the
     * DAP launcher both see them.
     *
     * Keyed on installed, not on activation: an adapter is catalogue data, not a running plugin, and
     * a pack set to Manual should still offer its debugger rather than hiding it. `{{extensionDir}}`
     * resolves here, where the install directory is known, so a pack can ship its adapter and install
     * it by copying instead of downloading.
     */
    private fun publishContributedDebugEngines(exts: List<InstalledExtension>) {
        val engines = exts.flatMap { ext ->
            val dir = ext.dir.absolutePath
            ext.contributes.debugEngines.map { engine ->
                fun resolve(command: String) = command.replace("{{extensionDir}}", dir)
                engine.copy(
                    installCommand = resolve(engine.installCommand),
                    verifyCommand = resolve(engine.verifyCommand),
                    uninstallCommand = resolve(engine.uninstallCommand),
                    adapterCommand = resolve(engine.adapterCommand),
                    updateCheckCommand = resolve(engine.updateCheckCommand),
                )
            }
        }
        val ids = engines.map { it.id }.toSet()
        if (ids == contributedDebugEngineIds) return
        contributedDebugEngineIds = ids
        dev.blamspot.jcode.core.distro.DebugEngineCatalog.setContributed(engines)
        // The manager renders a snapshot taken when the catalogue was last refreshed, so installing
        // a pack would otherwise leave its debugger invisible until something else forced a reload.
        // Only on an actual change: the probe runs verify commands in the distro.
        viewModelScope.launch { distroService.refreshDebugEngineCatalog() }
    }

    /** What [publishContributedDebugEngines] last published, so an unchanged list costs no probe. */
    private var contributedDebugEngineIds: Set<String>? = null

    /** Build/run presets active extensions contribute (required toolchains met), offered in the Run
     *  panel's Add pickers — each in the segment its `kind` names — when the project contains all of
     *  a preset's required files. */
    val contributedRunConfigPresets: StateFlow<List<ProjectRunner.ExtensionRunPreset>> =
        combine(installedExtensions, extensionActivations, distroService.sdkCatalogState) { exts, acts, sdk ->
            exts.filter { it.enabledIn(acts) }
                .filter { ext -> ext.requires.sdks.all { it in sdk.installedEntryIds } }
                .flatMap { ext -> ext.contributes.runConfigPresets.map { ProjectRunner.ExtensionRunPreset(ext.name, it) } }
        }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5_000L), emptyList())

    private fun availableContributions(
        exts: List<InstalledExtension>,
        acts: Map<String, ExtensionActivation>,
        sdk: dev.blamspot.jcode.core.distro.SdkCatalogState,
        surface: (dev.blamspot.jcode.feature.marketplace.ExtensionContributions) -> List<dev.blamspot.jcode.feature.marketplace.ContributedAction>,
    ): List<ShellContribution> =
        exts.filter { it.enabledIn(acts) }
            .filter { ext -> ext.requires.sdks.all { it in sdk.installedEntryIds } }
            .flatMap { ext ->
                surface(ext.contributes).map { ShellContribution(ext.id, it.id, it.label, it.icon, it.fileExtensions, it.targets) }
            }
            .distinctBy { it.extId + ":" + it.id }

    /** Open the extension view a contributed action points at (route == the action id). */
    fun openContributedView(c: ShellContribution) {
        openExtensionViewPage(c.extId, c.id, c.label)
    }

    /** The last editor context-menu tap per extension, pulled (once) by a freshly-opened extension
     *  page via `workbench.pendingContextAction` — WebViews created by the tap miss the pushed event. */
    private val pendingContextActions = ConcurrentHashMap<String, String>()

    /** Deliver an editor context-menu tap exactly once, then open/focus the extension's view at the
     *  action's route: if that view is already open its live WebView gets a pushed `contextAction`
     *  event; otherwise the payload is stashed for the freshly-created page to pull on boot. */
    fun handleEditorContextAction(c: ShellContribution, word: String) {
        val group = _editorGroup.value
        val tab = group.tabs.firstOrNull { it.id == group.activeTabId && !it.isPage }
        val json = JSONObject().apply {
            put("extensionId", c.extId)
            put("actionId", c.id)
            put("word", word)
            if (tab != null) {
                put("path", hostToGuestPath(tab.filePath))
                put("name", tab.filePath.name)
                put("dirty", tab.isDirty)
            }
        }.toString()
        val viewTabId = EXT_APP_PREFIX + c.extId + "#" + c.id
        if (group.tabs.any { it.id == viewTabId }) {
            _extensionEvents.tryEmit("contextAction" to json)
        } else {
            pendingContextActions[c.extId] = json
        }
        openExtensionViewPage(c.extId, c.id, c.label)
    }

    /** Extension ids with a live background web host (the persistent SCM WebView) — those get
     *  explorer taps as a pushed `explorerAction` event instead of a page open. Registered by the
     *  compose layer that owns the host WebViews. */
    val liveExtensionHosts: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /** Deliver an explorer file/folder context-menu tap. An extension with a live background host
     *  handles it silently via the pushed `explorerAction` event. When its host is still booting,
     *  stash the tap for the boot-time pull instead. Extensions without a background host get the
     *  editor pattern — stash for pull on boot and open the extension's view at the action's route. */
    fun handleExplorerContextAction(c: ShellContribution, hostPath: File, isDirectory: Boolean) {
        val json = JSONObject().apply {
            put("extensionId", c.extId)
            put("actionId", c.id)
            put("path", hostToGuestPath(hostPath))
            put("name", hostPath.name)
            put("isDirectory", isDirectory)
        }.toString()
        val hostExpected = installedExtensions.value.firstOrNull { it.id == c.extId }?.contributes?.explorerDecorations == true
        when {
            c.extId in liveExtensionHosts -> _extensionEvents.tryEmit("explorerAction" to json)
            hostExpected -> pendingContextActions[c.extId] = json
            else -> {
                val viewTabId = EXT_APP_PREFIX + c.extId + "#" + c.id
                if (_editorGroup.value.tabs.any { it.id == viewTabId }) {
                    _extensionEvents.tryEmit("contextAction" to json)
                } else {
                    pendingContextActions[c.extId] = json
                }
                openExtensionViewPage(c.extId, c.id, c.label)
            }
        }
    }

    /** "Something under the project changed on disk" hint (saves, explorer file ops, explorer
     *  Refresh) so decoration-pushing extensions re-run their status checks (debounced ext-side). */
    fun notifyWorkspaceFilesChanged() {
        _extensionEvents.tryEmit("filesChanged" to "{}")
    }

    /** Resolve the post-open prompt shown after a folder was opened inside a User Workspace. */
    fun resolvePostClone(open: Boolean) {
        val project = _postClonePrompt.value ?: return
        _postClonePrompt.value = null
        if (open) _selectedProjectId.value = project.id
        else viewModelScope.launch { emitMessage("Added '${project.name}' to the workspace.") }
    }

    /** Host side of the guest /sources mount — the staging dir extensions materialize folders into
     *  (e.g. the SCM extension's clones) before handing them over via `workbench.addFolder`. */
    private fun sourcesRoot(): File = dev.blamspot.jcode.core.distro.WorkspaceHostPaths.sourcesRoot(appContext.filesDir)

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = listOf("KB", "MB", "GB", "TB")
        var value = bytes.toDouble() / 1024
        var unit = 0
        while (value >= 1024 && unit < units.lastIndex) {
            value /= 1024
            unit++
        }
        return String.format(java.util.Locale.ROOT, if (value >= 100) "%.0f %s" else "%.1f %s", value, units[unit])
    }

    fun createNewItem(request: NewItemRequest) {
        viewModelScope.launch {
            if(request.isWorkspace) { emitMessage(nativePackages.uiText("project.createFolderHint"));return@launch }
            if(!saveAllDirtyAwait()) { emitMessage(nativePackages.uiText("project.saveFailed"));return@launch }
            val name=request.name.trim().ifBlank { if(request.isWorkspace) "untitled-workspace" else "untitled-project" }
            val nativeTemplate=if(request.isWorkspace) null else nativePackages.templates().firstOrNull { it.id==request.templateId }
            if(!request.isWorkspace && request.templateId!=null && request.templateId!="empty" && nativeTemplate==null) {
                emitMessage(nativePackages.uiText("project.templateUnavailable"));return@launch
            }
            if(request.isWorkspace) {
                clearEditorTabs()
                val node=workspaceManager.createNode(name,WorkspaceNodeType.Workspace,null)
                workspaceManager.enterWorkspaceFolder(node);_showNewItemDialog.value=false
                emitMessage("Workspace '${node.name}' created");return@launch
            }
            resetDefaultWorkspaceProject()
            val project=workspaceManager.createNode(name,WorkspaceNodeType.Project,nativeTemplate?.id)
            _selectedProjectId.value=project.id;_showNewItemDialog.value=false
            try {
                if(nativeTemplate!=null) nativePackages.applyTemplate(nativeTemplate,(project.fsPath as? FsPath.Local)?.file ?: error("Native templates require local storage"))
                notifyWorkspaceFilesChanged()
                emitMessage(nativePackages.uiText("project.created", mapOf("name" to (project.name).toString(), "template" to (nativeTemplate?.let { " · ${it.title}" } ?: "").toString())))
            } catch(e: Exception) { emitMessage(nativePackages.uiText("message.templateFailed", mapOf("reason" to (e.message ?: "").toString()))) }
        }
    }

    /**
     * Open a folder the user picked. Picks already on app-private ext4 storage (the "JCode Projects"
     * DocumentsProvider, or an existing project dir) open in place. Anything else — primary storage,
     * cloud, third-party SAF — is copied onto /sources first (the runtime can't bind-mount it
     * otherwise); [importExternalFolder] scans it and refuses an empty or oversized folder.
     */
    fun openExternalFolder(path: FsPath) {
        viewModelScope.launch {
            val resolved = workspaceManager.resolveManageable(path)
            if (workspaceManager.isManagedRoot(resolved)) {
                emitMessage("That folder is the JCode Projects root — pick a project or workspace folder inside it.")
                return@launch
            }
            if (workspaceManager.isOnManagedStorage(resolved)) {
                openManagedFolder(resolved)
            } else {
                importExternalFolder(resolved)
            }
        }
    }

    private suspend fun openManagedFolder(resolved: FsPath) {
        when {
            workspaceManager.isWorkspaceFolder(resolved) &&
                workspaceManager.enterFolderAsWorkspace(resolved) != null -> clearEditorTabs()

            // Inside a User Workspace, "add existing folder" always means adding a project to this
            // workspace — never prompt to make the pick a (nested) workspace.
            workspaceManager.folderNeedsType(resolved) && breadcrumb.value.size <= 1 ->
                _openFolderTypePrompt.value = PendingFolderType.OpenInPlace(resolved)

            else -> {
                resetDefaultWorkspaceProject()
                val project = workspaceManager.addFolder(resolved)
                _selectedProjectId.value = project.id
                emitMessage(nativePackages.uiText("message.opened", mapOf("name" to (project.name).toString())))
            }
        }
    }

    /** Scan an off-ext4 pick and, if it isn't empty and fits, copy it into /sources then adopt it. A
     *  progress modal follows the scan then the copy (see [_importProgress]). */
    private suspend fun importExternalFolder(source: FsPath) {
        val label = folderDisplayName(appContext, source)
        _importProgress.value = ImportProgress(label, ImportPhase.Scanning)
        val staged = try {
            val scan = runCatching { scanFolderForImport(appContext, source) }.getOrElse {
                emitMessage(nativePackages.uiText("message.readFailed", mapOf("name" to (label).toString(), "reason" to (it.message ?: "unknown error").toString())))
                return
            }
            if (scan.fileCount == 0) {
                emitMessage(nativePackages.uiText("message.emptyImport", mapOf("name" to (label).toString())))
                return
            }
            val sources = sourcesRoot().apply { mkdirs() }
            if (scan.totalBytes + IMPORT_FREE_SPACE_HEADROOM_BYTES > sources.usableSpace) {
                emitMessage(
                    "'$label' is too large to import — needs ${formatBytes(scan.totalBytes)}, " +
                        "only ${formatBytes(sources.usableSpace)} free.",
                )
                return
            }
            if (!saveAllDirtyAwait()) {
                emitMessage(nativePackages.uiText("message.Saveorcloseopenfilesbeforeimportinga"))
                return
            }
            _importProgress.value = ImportProgress(label, ImportPhase.Copying, done = 0, total = scan.fileCount)
            runCatching {
                copyIntoSources(source, label) { done ->
                    _importProgress.value = ImportProgress(label, ImportPhase.Copying, done, scan.fileCount)
                }
            }.getOrElse {
                emitMessage(nativePackages.uiText("message.importFailed", mapOf("reason" to (it.message ?: "unknown error").toString())))
                return
            }
        } finally {
            _importProgress.value = null
        }
        val stagedPath = FsPath.Local(staged)
        when {
            workspaceManager.isWorkspaceFolder(stagedPath) ->
                adoptStagedGuarded(staged, WorkspaceNodeType.Workspace)?.let { emitMessage("Imported Workspace '${it.name}'.") }

            workspaceManager.folderNeedsType(stagedPath) && breadcrumb.value.size <= 1 ->
                _openFolderTypePrompt.value = PendingFolderType.AdoptStaged(staged)

            else ->
                adoptStagedGuarded(staged, WorkspaceNodeType.Project)?.let { emitMessage(nativePackages.uiText("message.importedFolder", mapOf("name" to (it.name).toString()))) }
        }
    }

    /** [adoptStagedFolder] with the save-guard re-checked immediately before adoption: the import copy
     *  can run long enough for the user to dirty an open buffer, and adoption clears editor tabs without
     *  saving. On an unsaveable buffer the staged copy is discarded (already messaged) and null returned. */
    private suspend fun adoptStagedGuarded(staged: File, nodeType: WorkspaceNodeType): Project? {
        if (!saveAllDirtyAwait()) {
            emitMessage(nativePackages.uiText("message.Saveorcloseopenfilesbeforeimportinga"))
            withContext(Dispatchers.IO) { staged.deleteRecursively() }
            return null
        }
        return adoptStagedFolder(staged, nodeType)
    }

    /** Copy [source] into a hidden /sources temp dir, then atomically rename to a unique final name. */
    private suspend fun copyIntoSources(source: FsPath, label: String, onProgress: (Int) -> Unit): File = withContext(Dispatchers.IO) {
        val sources = sourcesRoot().apply { mkdirs() }
        // Reclaim temp dirs orphaned by a crash mid-copy (safe: only our own ".import-" prefix).
        sources.listFiles { f -> f.isDirectory && f.name.startsWith(".import-") }?.forEach { it.deleteRecursively() }
        val tmp = File(sources, ".import-${System.nanoTime()}")
        try {
            copyFolderToLocal(appContext, source, sources, tmp.name, onProgress)
            val base = workspaceManager.sanitizedFolderName(label)
            var dest = File(sources, base)
            var suffix = 1
            while (dest.exists()) dest = File(sources, "$base-${suffix++}")
            if (!tmp.renameTo(dest)) error("Cannot place the imported folder in staging")
            dest
        } catch (t: Throwable) {
            tmp.deleteRecursively()
            throw t
        }
    }

    /**
     * Move a staged /sources folder into the active workspace (or the Default Workspace) as [nodeType],
     * switching/entering as needed. Shared by the SCM clone bridge (`workbench.addFolder`) and the
     * SAF-import path. The caller must have flushed unsaved buffers first (adoption clears editor tabs).
     */
    private suspend fun adoptStagedFolder(staged: File, nodeType: WorkspaceNodeType): Project {
        val defId = workspaceManager.ensureDefaultWorkspaceId()
        return when (nodeType) {
            WorkspaceNodeType.Workspace -> {
                clearEditorTabs()
                workspaceManager.restoreWorkspace(defId)
                val node = workspaceManager.adoptFolderIn(defId, staged, WorkspaceNodeType.Workspace)
                workspaceManager.enterWorkspaceFolder(node)
                node
            }

            WorkspaceNodeType.Project -> {
                val targetWs = workspaceManager.currentWorkspace.value?.id ?: defId
                workspaceManager.restoreWorkspace(targetWs)
                if (targetWs == defId) resetDefaultWorkspaceProject()
                val project = workspaceManager.adoptFolderIn(targetWs, staged, WorkspaceNodeType.Project)
                _selectedProjectId.value = project.id
                project
            }
        }
    }

    fun resolveOpenFolderType(isWorkspace: Boolean) {
        val pending = _openFolderTypePrompt.value ?: return
        _openFolderTypePrompt.value = null
        val nodeType = if (isWorkspace) WorkspaceNodeType.Workspace else WorkspaceNodeType.Project
        viewModelScope.launch {
            when (pending) {
                is PendingFolderType.OpenInPlace -> {
                    val path = pending.path
                    if (isWorkspace && workspaceManager.enterFolderAsWorkspace(path) != null) {
                        clearEditorTabs()
                        return@launch
                    }
                    resetDefaultWorkspaceProject()
                    val project = workspaceManager.addFolderWithType(path, nodeType)
                    _selectedProjectId.value = project.id
                    emitMessage("Opened ${if (isWorkspace) "Workspace" else "Project"} '${project.name}'.")
                }

                is PendingFolderType.AdoptStaged -> {
                    if (!pending.staged.isDirectory) {
                        emitMessage(nativePackages.uiText("message.Theimportedfolderisnolongeravailable"))
                        return@launch
                    }
                    adoptStagedGuarded(pending.staged, nodeType)?.let {
                        emitMessage("Imported ${if (isWorkspace) "Workspace" else "Project"} '${it.name}'.")
                    }
                }
            }
        }
    }

    fun dismissOpenFolderPrompt() {
        val pending = _openFolderTypePrompt.value
        _openFolderTypePrompt.value = null
        // An imported-but-unclassified folder would otherwise linger in /sources; drop it on cancel.
        if (pending is PendingFolderType.AdoptStaged) {
            viewModelScope.launch(Dispatchers.IO) { pending.staged.deleteRecursively() }
        }
    }

    /** Recently opened folders (most-recent first) for the empty-editor "Recent" list. */
    val recents: StateFlow<List<RecentEntity>> = workspaceManager.recents

    /** Re-open a recent folder; [openExternalFolder] enters it as a workspace or opens it as a project. */
    fun openRecent(recent: RecentEntity) {
        val path = when (recent.kind) {
            ProjectKind.Local -> FsPath.Local(File(recent.uri))
            ProjectKind.Saf -> FsPath.Saf(Uri.parse(recent.uri))
        }
        openExternalFolder(path)
    }

    fun removeProject(projectId: Long) {
        viewModelScope.launch {
            workspaceManager.removeProject(projectId)
            emitMessage(nativePackages.uiText("message.RemovedfromtheprojectlistFilesremainin"))
        }
    }

    fun removeRecent(uri: String) { viewModelScope.launch { workspaceManager.removeRecent(uri) } }
    fun trashProject(project: Project) {
        viewModelScope.launch {
            try {
                javaQuickRun.stop();debugController.stop();lspController.shutdownAll()
                check(project.fsPath is FsPath.Local) { "Manage external SAF project deletion through the authorized file provider" }
                WorkspaceServiceLocator.trash(appContext).put(appContext,project.fsPath,project.name,(project.fsPath as FsPath.Local).file.path,dev.blamspot.jcode.fs.TrashSource.Explorer)
                workspaceManager.removeProject(project.id)
                workspaceManager.removeRecent(project.location)
                emitMessage(nativePackages.uiText("message.ProjectfilesmovedtoTrashRestorefromFiles"))
            } catch(e: Exception) { emitMessage(nativePackages.uiText("message.projectDeleteStopped", mapOf("reason" to (e.message ?: "").toString()))) }
        }
    }

    fun selectProject(projectId: Long) {
        _selectedProjectId.value = projectId
    }

    /** Roster tap / "Open": a Workspace is entered (its projects show); a Project is selected. */
    fun openProject(project: Project) {
        if (project.nodeType == WorkspaceNodeType.Workspace) {
            viewModelScope.launch {
                clearEditorTabs()
                workspaceManager.enterWorkspaceFolder(project)
            }
        } else {
            _selectedProjectId.value = project.id
        }
    }

    /** Leave the current User Workspace and return to the Default Workspace (the first crumb). */
    fun closeWorkspace() {
        val defaultId = breadcrumb.value.firstOrNull()?.id ?: return
        viewModelScope.launch {
            clearEditorTabs()
            workspaceManager.navigateToWorkspace(defaultId)
            // currentWorkspace is DB-derived; wait for it to reflect the switch so the immediate
            // session save records the default workspace, not the one just closed.
            withTimeoutOrNull(2_000) { currentWorkspace.first { it?.id == defaultId } }
            persistSession()
        }
    }

    /**
     * Close the project open in the Default Workspace: clear the editor and unregister the Default
     * Workspace's project(s) (folders kept) → clean welcome screen. Terminal sessions are torn down
     * by the UI layer (it owns their lifecycle).
     */
    fun closeProject() {
        viewModelScope.launch {
            clearEditorTabs()
            clearDefaultWorkspaceProjects()
            persistSession()
            emitMessage(nativePackages.uiText("message.Projectclosed"))
        }
    }

    private fun clearEditorTabs() {
        val tabs = _editorGroup.value.tabs
        // Language servers are rooted in the project being left, so none of them survives the switch.
        lspController.shutdownAll()
        tabs.filterNot { it.isPage }.forEach {
            it.editorState?.close()
            untrackDirty(it.id)
        }
        // Page tabs (e.g. Settings) are app-level, not project content: keep them across project switches.
        _editorGroup.value = tabs.filter { it.isPage }
            .fold(EditorGroup.create()) { group, tab -> group.withTabAdded(tab) }
        diagnosticsBus.clearSource("syntax")
    }

    /** The Default Workspace holds a single open project; unregister whatever it currently has. */
    private suspend fun clearDefaultWorkspaceProjects() {
        if (breadcrumb.value.size > 1) return
        currentWorkspace.value?.projects.orEmpty().forEach { workspaceManager.removeProject(it.id) }
    }

    /** Single-slot Default: before opening/creating a project there, clear the current one. */
    private suspend fun resetDefaultWorkspaceProject() {
        if (breadcrumb.value.size > 1) return
        clearEditorTabs()
        clearDefaultWorkspaceProjects()
    }

    fun renameProject(projectId: Long, newName: String) {
        viewModelScope.launch {
            try {
                val ok=workspaceManager.renameProject(projectId,newName)
                emitMessage(if(ok) nativePackages.uiText("message.renamed", mapOf("name" to (newName).toString())) else nativePackages.uiText("message.Renamefaileddestinationexistsortheprojectis"))
            } catch(e: Exception) { emitMessage(nativePackages.uiText("message.renameRejected", mapOf("reason" to (e.message ?: "").toString()))) }
        }
    }

    /** Copy a local project/recent dir out to a user-picked SAF folder ("Export to storage") so it's
     *  browsable in a file manager / other apps. A one-shot snapshot: `node_modules` (large and
     *  regenerable) is skipped. Projects otherwise live on app-private ext4 (see WorkspaceHostPaths);
     *  the DocumentsProvider gives a live view, this gives a real on-disk copy. A null/non-directory
     *  [source] (e.g. a SAF project with no local dir) is rejected with a message. */
    fun exportDirTo(name: String, source: File?, dest: Uri) {
        if (source == null || !source.isDirectory) {
            viewModelScope.launch { emitMessage(nativePackages.uiText("message.exportNotLocal", mapOf("name" to (name).toString()))) }
            return
        }
        viewModelScope.launch {
            emitMessage(nativePackages.uiText("message.exporting", mapOf("name" to (name).toString())))
            val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.ROOT).format(java.util.Date())
            runCatching { copyLocalTreeToDocumentTree(appContext, source, dest, "$name-$stamp") }
                .onSuccess { emitMessage(nativePackages.uiText("message.exported", mapOf("count" to (it).toString(), "name" to (name).toString()))) }
                .onFailure { emitMessage(nativePackages.uiText("message.exportFailed", mapOf("reason" to (it.message ?: "unknown error").toString()))) }
        }
    }

    // A null value clears the override: the field is dropped from the scope's .jcode YAML and the
    // effective value falls back down the project -> workspace -> defaults chain.
    fun updateEditorFontSize(scope: ConfigScope, fontSize: Float?) {
        viewModelScope.launch {
            if (!ensureScopeAvailable(scope)) return@launch
            configService.updateEditorConfig(scope) { it.copy(fontSize = fontSize?.coerceIn(8f, 72f)) }
        }
    }

    fun updateEditorTabSize(scope: ConfigScope, tabSize: Int?) {
        viewModelScope.launch {
            if (!ensureScopeAvailable(scope)) return@launch
            configService.updateEditorConfig(scope) { it.copy(tabSize = tabSize?.coerceIn(1, 16)) }
        }
    }

    fun updateEditorLigatures(scope: ConfigScope, enabled: Boolean?) {
        viewModelScope.launch {
            if (!ensureScopeAvailable(scope)) return@launch
            configService.updateEditorConfig(scope) { it.copy(ligatures = enabled) }
        }
    }

    /** Project/workspace .jcode override of the tab-coloring mode ([TabColoring] name; null inherits). */
    fun updateEditorTabColoring(scope: ConfigScope, value: String?) {
        viewModelScope.launch {
            if (!ensureScopeAvailable(scope)) return@launch
            configService.updateEditorConfig(scope) { it.copy(tabColoring = value) }
        }
    }

    // ---- Editor tab colors ------------------------------------------------------------------------
    // Effective mode = .jcode override (project<-workspace) if set, else the app-level default.
    val effectiveTabColoring: StateFlow<TabColoring> =
        combine(effectiveConfig, tabColoringMode) { eff, global ->
            eff.editor.tabColoring?.let { runCatching { TabColoring.valueOf(it) }.getOrNull() } ?: global
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsDefaults.TAB_COLORING)

    private val _editorTabColors = MutableStateFlow<Map<String, Color>>(emptyMap())
    /** Absolute-file-path -> accent color for the currently open file tabs (empty when Disabled). */
    val editorTabColors: StateFlow<Map<String, Color>> = _editorTabColors.asStateFlow()

    // Session caches so a generated color is stable across recomposes and matches what gets persisted.
    private val ephemeralTabColors = mutableMapOf<String, Int>() // absPath -> argb (Random mode)
    private val sessionGenFile = mutableMapOf<String, Int>()     // relPath -> argb (RandomRemember, pre-persist)
    private val sessionGenDir = mutableMapOf<String, Int>()      // relDir -> argb (DirectoryBased, pre-persist)

    private data class TabColorInputs(
        val group: EditorGroup,
        val project: Project?,
        val mode: TabColoring,
        val storedFiles: Map<String, String>,
        val storedDirs: Map<String, String>,
    )

    init {
        viewModelScope.launch {
            combine(
                _editorGroup,
                selectedProject,
                effectiveTabColoring,
                configService.projectConfig,
            ) { group, project, mode, cfg ->
                TabColorInputs(group, project, mode, cfg?.tabColors.orEmpty(), cfg?.tabDirColors.orEmpty())
            }.collect { recomputeTabColors(it) }
        }
    }

    private var lastColorRoot: String? = null

    private suspend fun recomputeTabColors(inp: TabColorInputs) {
        val root = (inp.project?.fsPath as? FsPath.Local)?.file
        // The session caches hold project-relative scratch colors; drop them on project switch so a
        // same-named file in another project doesn't reuse the previous project's generated color.
        val rootPath = root?.absolutePath
        if (rootPath != lastColorRoot) {
            lastColorRoot = rootPath
            ephemeralTabColors.clear()
            sessionGenFile.clear()
            sessionGenDir.clear()
        }
        if (inp.mode == TabColoring.Disabled || root == null) {
            if (_editorTabColors.value.isNotEmpty()) _editorTabColors.value = emptyMap()
            return
        }
        val out = LinkedHashMap<String, Color>()
        var newFiles: MutableMap<String, String>? = null
        var newDirs: MutableMap<String, String>? = null
        for (tab in inp.group.tabs) {
            if (tab.isPage) continue
            val abs = tab.filePath.path
            val rel = relativeTabKey(root, tab.filePath) ?: continue
            val stored = inp.storedFiles[rel]
            if (stored != null) {
                tabColorFromHex(stored)?.let { out[abs] = it }
                continue
            }
            when (inp.mode) {
                TabColoring.RandomRemember -> {
                    val argb = sessionGenFile.getOrPut(rel) { randomTabColor().toArgb() }
                    out[abs] = Color(argb)
                    (newFiles ?: LinkedHashMap<String, String>().also { newFiles = it })[rel] = tabColorToHex(Color(argb))
                }
                TabColoring.Random -> {
                    out[abs] = Color(ephemeralTabColors.getOrPut(abs) { randomTabColor().toArgb() })
                }
                TabColoring.DirectoryBased -> {
                    val dir = rel.substringBeforeLast('/', "")
                    val storedDir = inp.storedDirs[dir]
                    if (storedDir != null) {
                        tabColorFromHex(storedDir)?.let { out[abs] = it }
                    } else {
                        val argb = sessionGenDir.getOrPut(dir) { randomTabColor().toArgb() }
                        out[abs] = Color(argb)
                        (newDirs ?: LinkedHashMap<String, String>().also { newDirs = it })[dir] = tabColorToHex(Color(argb))
                    }
                }
                TabColoring.Disabled -> Unit
            }
        }
        _editorTabColors.value = out
        // Persist freshly generated colors once; updateProjectTabColorMaps no-ops if unchanged, so the
        // reload this triggers re-enters here with the entries already stored and stops. A write
        // failure must not tear down the collector, so swallow it (colors just stay session-only).
        if (newFiles != null || newDirs != null) {
            runCatching {
                configService.updateProjectTabColorMaps { files, dirs ->
                    (files + newFiles.orEmpty()) to (dirs + newDirs.orEmpty())
                }
            }
        }
    }

    /** Manually set (hex) or clear (null) a file tab's color; persists to the project .jcode. */
    fun setTabColor(tabId: String, hex: String?) {
        val tab = _editorGroup.value.tabs.find { it.id == tabId } ?: return
        viewModelScope.launch {
            if (!ensureScopeAvailable(ConfigScope.Project)) return@launch
            val root = (selectedProject.value?.fsPath as? FsPath.Local)?.file ?: return@launch
            val rel = relativeTabKey(root, tab.filePath)
                ?: run { emitMessage(nativePackages.uiText("message.Cantcolorafileoutsidetheproject")); return@launch }
            configService.updateProjectTabColorMaps { files, dirs ->
                (if (hex == null) files - rel else files + (rel to hex)) to dirs
            }
        }
    }

    private fun relativeTabKey(root: java.io.File, file: java.io.File): String? =
        runCatching { file.relativeTo(root).invariantSeparatorsPath }
            .getOrNull()?.takeIf { it.isNotEmpty() && !it.startsWith("..") }

    fun setThemeMode(mode: ThemeMode?, scope: ConfigScope = ConfigScope.Workspace) {
        viewModelScope.launch {
            if (!ensureScopeAvailable(scope)) return@launch
            configService.updateThemeConfig(scope) { it.copy(id = mode?.configId) }
            // A reset must clear the override wherever it lives: a (hand-written) project
            // theme.id wins the effective resolution, so leaving it would make the reset a
            // visible no-op. Only touched when present, so no project .jcode is created.
            if (mode == null && scope == ConfigScope.Workspace &&
                projectConfig.value?.theme?.id != null && ensureScopeAvailable(ConfigScope.Project)
            ) {
                configService.updateThemeConfig(ConfigScope.Project) { it.copy(id = null) }
            }
        }
    }

    fun updateExplorerViewMode(scope: ConfigScope, viewMode: String?) {
        viewModelScope.launch {
            if (!ensureScopeAvailable(scope)) return@launch
            configService.updateExplorerConfig(scope) { it.copy(viewMode = viewMode) }
        }
    }

    // --- Multi-environment ("docker-style") management ---

    /**
     * Switching environments restarts the app. A shell is bound to the rootfs it was spawned against
     * for life (proot's `-r`), so without a restart the workbench is left half on the old environment
     * — the state that made an installed toolchain look missing from an open terminal. Editor tabs and
     * unsaved buffers survive via [restartApp]'s session flush; foreground processes do not, so those
     * are confirmed first.
     */
    fun setActiveEnvironment(environmentId: String) {
        if (environmentId == distroService.environmentState.value.runtime.selectedDistro.id) return
        val running = TerminalSessionHost.existingManager()?.sessions?.values
            ?.mapNotNull { it.foreground }
            .orEmpty()
        if (running.isEmpty()) applyEnvironmentSwitch(environmentId)
        else _pendingEnvironmentSwitch.value = PendingEnvironmentSwitch(environmentId, running)
    }

    /** An environment switch held back because live processes would be killed by the restart. */
    data class PendingEnvironmentSwitch(val environmentId: String, val running: List<String>)

    private val _pendingEnvironmentSwitch = MutableStateFlow<PendingEnvironmentSwitch?>(null)
    val pendingEnvironmentSwitch: StateFlow<PendingEnvironmentSwitch?> =
        _pendingEnvironmentSwitch.asStateFlow()

    fun confirmEnvironmentSwitch() {
        val pending = _pendingEnvironmentSwitch.value ?: return
        _pendingEnvironmentSwitch.value = null
        applyEnvironmentSwitch(pending.environmentId)
    }

    fun cancelEnvironmentSwitch() {
        _pendingEnvironmentSwitch.value = null
    }

    private fun applyEnvironmentSwitch(environmentId: String) {
        viewModelScope.launch {
            distroService.setActiveEnvironmentAwaitingPersist(environmentId)
            restartApp()
        }
    }

    fun deleteEnvironment(environmentId: String) {
        // IO: switches the active distro and re-derives its state, which can exec into the rootfs.
        viewModelScope.launch(Dispatchers.IO) {
            val label = environmentId
            val removed = distroService.deleteEnvironment(environmentId)
            emitMessage(if (removed) "Removed environment '$label'." else "Could not remove '$label'.")
        }
    }

    fun createEnvironment(profile: DistroProfile) {
        viewModelScope.launch(Dispatchers.IO) {
            // Hold a foreground session so Android won't kill the app during the long download/extract.
            val session = SessionRegistry.registerSession(
                context = getApplication(),
                kind = BackendSessionKind.JOB,
                name = "environment:create:${profile.id}",
            )
            try {
                distroService.createEnvironment(profile).collect { /* progress surfaced via environmentState */ }
            } finally {
                session.close()
            }
        }
    }

    fun openWorkspaceConfigFile() {
        viewModelScope.launch {
            val file = configService.ensureConfigFile(ConfigScope.Workspace)
            if (file == null) {
                emitMessage(nativePackages.uiText("message.Workspaceconfigisunavailable"))
                return@launch
            }
            openLocalFile(file)
        }
    }

    fun openProjectConfigFile() {
        viewModelScope.launch {
            val file = configService.ensureConfigFile(ConfigScope.Project)
            if (file == null) {
                emitMessage(nativePackages.uiText("message.Projectoverridesrequirealocalproject"))
                return@launch
            }
            openLocalFile(file)
        }
    }

    fun refreshEnvironment() {
        viewModelScope.launch(Dispatchers.IO) {
            distroService.refreshEnvironment()
        }
    }

    fun selectWizardDistro(profile: DistroProfile) {
        distroService.setSelectedDistro(profile)
    }

    fun deferFirstRunEnvironmentSetup() {
        viewModelScope.launch {
            distroService.setFirstRunSetupDeferred(true)
        }
    }

    /** Storage permission was granted mid-onboarding: re-anchor storage on the shared /JCode root. */
    fun onStorageAccessGranted() {
        viewModelScope.launch {
            workspaceManager.refreshStorageRoots()
        }
        // A migration bundle lives in shared storage, so it is unreadable until this moment — and on
        // a fresh install this moment always comes AFTER the first look for one. Without re-checking
        // here the offer never appears for the person it exists for: someone who just moved.
        refreshMigrationBundle()
    }

    fun runAutoSetup() {
        viewModelScope.launch(Dispatchers.IO) {
            // Register a foreground session so Android won't kill the app during long bootstrap
            val session = SessionRegistry.registerSession(
                context = getApplication(),
                kind = BackendSessionKind.JOB,
                name = "environment:auto-setup",
            )
            try {
                distroService.runAllPendingSteps()
            } finally {
                session.close()
            }
        }
    }

    private val _systemPackagesUpdating = MutableStateFlow(false)

    /** True while an opt-in `apt-get update && upgrade` is running (drives the Settings button state). */
    val systemPackagesUpdating: StateFlow<Boolean> = _systemPackagesUpdating.asStateFlow()

    /** Opt-in "Update system packages": runs `apt-get update && apt-get upgrade` (self-healing, streamed
     *  to the Setup terminal). Deliberately never automatic — an upgrade can be large/slow under proot. */
    fun updateSystemPackages() {
        if (_systemPackagesUpdating.value) return
        viewModelScope.launch(Dispatchers.IO) {
            _systemPackagesUpdating.value = true
            val session = SessionRegistry.registerSession(
                context = getApplication(),
                kind = BackendSessionKind.JOB,
                name = "environment:update-packages",
            )
            try {
                _messages.tryEmit("Updating system packages… (see the Setup terminal for progress)")
                val result = distroService.updateSystemPackages()
                _messages.tryEmit(
                    if (result.succeeded) {
                        "System packages up to date."
                    } else {
                        val reason = result.internalError
                            ?: result.stderr.lineSequence().firstOrNull { it.isNotBlank() }
                            ?: "see the Setup terminal"
                        "Package update failed: $reason"
                    },
                )
            } finally {
                session.close()
                _systemPackagesUpdating.value = false
            }
        }
    }

    fun installSdkCatalogEntry(entryId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val entry = distroService.sdkCatalogState.value.entries.firstOrNull { it.id == entryId }
            _sdkInstallRequestedId.value = entryId
            try {
                if (entry != null && !installRequiredSdks(entry.requiredSdks, entry.name)) return@launch
                runCatalogInstall("sdk", entryId) {
                    distroService.runSdkCatalogAction(entryId, SdkCatalogAction.Install)
                }
            } finally {
                _sdkInstallRequestedId.value = null
            }
        }
    }

    fun uninstallSdkCatalogEntry(entryId: String) {
        runSdkCatalogAction(entryId, SdkCatalogAction.Uninstall)
    }

    /** Install a specific [version] of a catalog entry (from the detail-page version picker). */
    fun installSdkCatalogVersion(entryId: String, version: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val entry = distroService.sdkCatalogState.value.entries.firstOrNull { it.id == entryId }
            if (entry != null && !installRequiredSdks(entry.requiredSdks, entry.name)) return@launch
            runCatalogInstall("sdk", entryId) {
                distroService.runSdkCatalogAction(entryId, SdkCatalogAction.Install, version = version)
            }
        }
    }

    /** Remove one installed [version] of a multi-version catalog entry (from the version list). */
    fun uninstallSdkCatalogVersion(entryId: String, version: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val session = SessionRegistry.registerSession(
                context = getApplication(),
                kind = BackendSessionKind.JOB,
                name = "sdk:uninstall:$entryId",
            )
            try {
                distroService.runSdkCatalogAction(entryId, SdkCatalogAction.Uninstall, version = version)
            } finally {
                session.close()
            }
        }
    }

    /** Make one installed [version] of a multi-version catalog entry the active one (the one on PATH). */
    fun useSdkCatalogVersion(entryId: String, version: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val session = SessionRegistry.registerSession(
                context = getApplication(),
                kind = BackendSessionKind.JOB,
                name = "sdk:use:$entryId",
            )
            try {
                distroService.runSdkCatalogAction(entryId, SdkCatalogAction.Use, version = version)
            } finally {
                session.close()
            }
        }
    }

    fun installLspCatalogEntry(entryId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val entry = LspServerCatalog.findById(entryId)
            if (entry != null && !installRequiredSdks(entry.requiredSdks, entry.name)) return@launch
            runCatalogInstall("lsp", entryId) {
                distroService.runLspCatalogAction(entryId, LspCatalogAction.Install)
            }
        }
    }

    fun uninstallLspCatalogEntry(entryId: String) {
        runLspCatalogAction(entryId, LspCatalogAction.Uninstall)
    }

    fun installDebugEngine(entryId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val entry = DebugEngineCatalog.findById(entryId)
            if (entry != null && !installRequiredSdks(entry.requiredSdks, entry.name)) return@launch
            runCatalogInstall("debug", entryId) {
                distroService.runDebugEngineCatalogAction(entryId, DebugEngineAction.Install)
            }
        }
    }

    fun uninstallDebugEngine(entryId: String) {
        runDebugCatalogAction(entryId, DebugEngineAction.Uninstall)
    }

    fun openFile(node: FsNode) {
        if (node.kind != FsKind.File) return
        viewModelScope.launch {
            when (val path = node.path) {
                is FsPath.Local -> openLocalFile(path.file)
                is FsPath.Saf -> openSafFile(node)
            }
        }
    }

    /**
     * Open a file referenced by a single tap in a terminal: a guest `/workspace/...` path, an absolute
     * host path, or a path relative to the open project. A trailing `:line`/`:line:col` is stripped.
     * No-op if the token doesn't resolve to an existing file.
     */
    fun openFileByGuestPath(token: String) {
        val raw = token.trim().trimEnd('.', ',', ')', ']', '}', ';', '"', '\'')
        if (raw.isEmpty()) return
        // A trailing `:line` or `:line:col` (1-based, as compilers/grep emit) becomes the focus target.
        var pathPart = raw
        var line: Int? = null
        var column: Int? = null
        Regex("""^(.*?):(\d+)(?::(\d+))?$""").find(raw)?.let { m ->
            pathPart = m.groupValues[1]
            line = m.groupValues[2].toIntOrNull()
            column = m.groupValues[3].toIntOrNull()
        }
        val file = resolveHostFile(pathPart) ?: return
        if (!file.isFile) return
        _bringEditorToFront.tryEmit(Unit)
        viewModelScope.launch { openLocalFile(file, line, column) }
    }

    private fun resolveHostFile(path: String): File? {
        val projectsRoot = dev.blamspot.jcode.core.distro.WorkspaceHostPaths.projectsRoot.trimEnd('/')
        return when {
            path == "/workspace" -> null
            path.startsWith("/workspace/") -> File(projectsRoot + path.removePrefix("/workspace"))
            path.startsWith("/") -> File(path) // absolute host path
            else -> {
                val base = (selectedProject.value?.fsPath as? FsPath.Local)?.file ?: return null
                File(base, path) // relative to the open project
            }
        }
    }

    /**
     * Which project a host path belongs to, as a name and a root.
     *
     * Read off the path rather than taken from the open project: a workspace can hold several
     * repositories, and the one an extension is acting on is not necessarily the one on screen.
     */
    private fun owningProject(file: File): Pair<String, String?> {
        val projectsRoot = dev.blamspot.jcode.core.distro.WorkspaceHostPaths.projectsRoot.trimEnd('/')
        val inside = file.absolutePath.removePrefix("$projectsRoot/")
        if (inside != file.absolutePath) {
            val name = inside.substringBefore('/')
            if (name.isNotBlank()) return name to "$projectsRoot/$name"
        }
        val open = selectedProject.value
        return open?.name.orEmpty() to (open?.fsPath as? FsPath.Local)?.file?.absolutePath
    }

    /** Save a clipboard image pasted into the terminal under the active project and return its guest
     *  /workspace path (or null if there's no open project or the write fails). Called on the main
     *  thread from the terminal paste action; images are small (screenshots) so the write is inline. */
    fun savePastedImage(uri: android.net.Uri): String? {
        val projectDir = (selectedProject.value?.fsPath as? FsPath.Local)?.file ?: return null
        return runCatching {
            val dir = File(projectDir, ".jcode/pasted-images").apply { mkdirs() }
            val file = File(dir, "paste-${System.currentTimeMillis()}.png")
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                val bitmap = android.graphics.BitmapFactory.decodeStream(input) ?: return null
                file.outputStream().use { out ->
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
                }
            } ?: return null
            dev.blamspot.jcode.core.distro.WorkspaceHostPaths.hostToGuest(file.absolutePath)
        }.getOrNull()
    }

    /** Resolve a template input's live options by running its optionsCommand in the runtime; returns
     *  the distinct non-blank stdout lines (e.g. installed .NET SDK monikers), or empty on any failure
     *  or when the runtime isn't ready — the caller then falls back to the template's static options. */
    suspend fun runTemplateOptionsCommand(command: String): List<String> {
        if (command.isBlank() || !distroService.isRuntimeReady()) return emptyList()
        return runCatching {
            distroService.exec(command, user = "root", raw = true).stdout
                .lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.distinct().toList()
        }.getOrDefault(emptyList())
    }

    /** Open (or focus) the in-editor Settings page as an editor tab. */
    fun openSettingsPage() {
        _bringEditorToFront.tryEmit(Unit)
        val existing = _editorGroup.value.tabs.firstOrNull { it.pageKind == EditorPageKind.Settings }
        if (existing != null) {
            _editorGroup.value = _editorGroup.value.withActiveTabChanged(existing.id)
            return
        }
        val tab = EditorTab.page(SETTINGS_TAB_ID, "Settings", EditorPageKind.Settings)
        _editorGroup.value = _editorGroup.value.withTabAdded(tab)
    }

    /** Open (or focus) the Trash as an editor tab. */
    fun openTrashPage() {
        _bringEditorToFront.tryEmit(Unit)
        val existing = _editorGroup.value.tabs.firstOrNull { it.pageKind == EditorPageKind.Trash }
        if (existing != null) {
            _editorGroup.value = _editorGroup.value.withActiveTabChanged(existing.id)
            return
        }
        _editorGroup.value = _editorGroup.value.withTabAdded(
            EditorTab.page(TRASH_TAB_ID, "Trash", EditorPageKind.Trash),
        )
    }

    fun openEnvironmentPage() {
        _bringEditorToFront.tryEmit(Unit)
        val existing = _editorGroup.value.tabs.firstOrNull { it.pageKind == EditorPageKind.Environment }
        if (existing != null) {
            _editorGroup.value = _editorGroup.value.withActiveTabChanged(existing.id)
            return
        }
        val tab = EditorTab.page(ENVIRONMENT_TAB_ID, "Environment", EditorPageKind.Environment)
        _editorGroup.value = _editorGroup.value.withTabAdded(tab)
    }

    /** Open (or focus) an installed extension's bundled web frontend as a full-screen in-editor page.
     *  Only reachable through [openExtensionViewPage]'s blank-view case now that the Extension detail
     *  screen no longer offers a "Manage" button. */
    private fun openExtensionAppPage(extensionId: String) {
        openDetailPage(EXT_APP_PREFIX + extensionId, EditorPageKind.ExtensionApp) {
            _installedExtensions.value.firstOrNull { it.id == extensionId }?.name ?: "App"
        }
    }

    /** Open an extension's web frontend at a named view (loaded as `#view`) as a full editor page and
     *  bring the editor to front — used by the `workbench.openView` Extension API. By default one
     *  ExtensionApp tab exists at a time (opening a view replaces the previous one, matching the SCM
     *  diff-peek pattern); [coexist] opts into a genuine additional tab (Mermaid "View in New Tab"). */
    fun openExtensionViewPage(extensionId: String, view: String, title: String? = null, coexist: Boolean = false) {
        _bringEditorToFront.tryEmit(Unit)
        val ext = _installedExtensions.value.firstOrNull { it.id == extensionId }
        val viewLabel = viewLabel(view)
        // A blank view IS the app/root view — focus the existing app tab instead of minting a
        // distinct `<id>#` tab that renders identically and collides with it on the render key.
        if (view.isBlank()) { openExtensionAppPage(extensionId); return }
        val tabId = EXT_APP_PREFIX + extensionId + "#" + view
        val titleOf: () -> String = {
            title?.takeIf { it.isNotBlank() } ?: listOfNotNull(ext?.name, viewLabel).joinToString(" · ").ifBlank { "View" }
        }
        if (coexist) openExtensionPage(tabId, titleOf) else openDetailPage(tabId, EditorPageKind.ExtensionApp, titleOf)
    }

    /**
     * A readable name for an extension route.
     *
     * The route is the extension's own string and the workbench does not know its grammar, but
     * `<kind>:<arg>:<arg>` is the convention and the last argument is what the page is about — so the
     * label is the kind plus the tail of that argument, with percent-decoding undoing whatever the
     * route did to fit a path into one segment. Without it a tab reads
     * `Diff:w:%2Fworkspace%2Fscmtest:docs%2Fnotes.md`, which does name the file it is showing, to
     * anyone willing to decode it themselves.
     *
     * `Uri.decode` rather than `URLDecoder`: the routes are written by `encodeURIComponent`, which
     * never emits `+` for a space, so a `+` in the id is a literal one and `URLDecoder` would eat it.
     */
    private fun viewLabel(view: String): String? = when {
        view.isBlank() -> null
        view == "github" -> "GitHub"
        !view.contains(':') -> view.replaceFirstChar { it.uppercaseChar() }
        else -> {
            val kind = view.substringBefore(':').replaceFirstChar { it.uppercaseChar() }
            val subject = runCatching { Uri.decode(view.substringAfterLast(':')) }
                .getOrDefault(view.substringAfterLast(':'))
                .trimEnd('/')
                .substringAfterLast('/')
            // A subject that already opens with its own kind says it once: a stash route named
            // "stash@{0}" was rendering as "Stash · stash@{0}", which reads as a stutter rather
            // than as a name.
            when {
                subject.isBlank() -> kind
                subject.startsWith(kind, ignoreCase = true) -> subject
                else -> "$kind · $subject"
            }
        }
    }

    /** Open/focus an ExtensionApp page WITHOUT evicting other extension pages, so distinct routes
     *  (e.g. a Mermaid document preview and a single chart opened from "View in New Tab") coexist as
     *  separate tabs. Same id → refocus (no reload); new id → added beside the others. Only reached
     *  when the caller explicitly opts into coexistence (see [openExtensionViewPage]). */
    private fun openExtensionPage(tabId: String, title: () -> String) {
        val group = _editorGroup.value
        val existing = group.tabs.firstOrNull { it.id == tabId }
        _editorGroup.value = if (existing != null) {
            group.withActiveTabChanged(existing.id)
        } else {
            group.withTabAdded(EditorTab.page(tabId, title(), EditorPageKind.ExtensionApp))
        }
    }

    /**
     * Open (or focus) an editor tab for a webview panel an imported `.vsix` created.
     *
     * Panels coexist rather than replacing each other: an extension can hold several at once (a
     * session opened in the editor alongside its Agent Manager), and VS Code shows them as separate
     * tabs. The panel itself lives in the extension's session, so this only surfaces it — closing the
     * tab leaves it running, and the extension revealing it again reopens this tab.
     */
    fun openVsixPanelPage(extensionId: String, handle: String, title: String) {
        _bringEditorToFront.tryEmit(Unit)
        val tabId = VSIX_PANEL_PREFIX + extensionId + "#" + handle
        val group = _editorGroup.value
        val existing = group.tabs.firstOrNull { it.id == tabId }
        _editorGroup.value = if (existing != null) {
            group.withActiveTabChanged(existing.id)
        } else {
            group.withTabAdded(EditorTab.page(tabId, title, EditorPageKind.VsixPanel))
        }
    }

    /** Run a command in the Linux runtime for an extension frontend; returns a JSON result payload.
     *  Runs as root: manager extensions (SQL Client, VM Manager) need privilege to install/run software. */
    suspend fun runtimeExecJson(command: String, timeoutMs: Long): String {
        val result = distroService.exec(command, timeoutMs = timeoutMs, user = "root")
        return JSONObject().apply {
            put("stdout", result.stdout)
            put("stderr", result.stderr)
            put("exitCode", result.exitCode ?: -1)
            result.internalError?.let { put("error", it) }
        }.toString()
    }

    // --- Extension API v1: versioned request envelope + pushed events over the WebView bridge ---
    // Requests arrive as {"type":"family.verb","payload":{...}} via JCodeNative.request and are
    // answered through window.JCode._onResult as {"ok":true,"data":{}} | {"ok":false,"error":""}.
    // Route families ("exec", "fs", "workbench") are capability-gated: an extension must declare a
    // family under its manifest's api.capabilities AND the user must not have revoked it.

    /** Per-extension capability DENIALS (granted-by-default), keyed by extension id — same
     *  org.json-blob DataStore pattern as [extensionActivationKey]. */
    private val extensionCapabilityKey = stringPreferencesKey("extension_capability_denials")

    val extensionCapabilityDenials: StateFlow<Map<String, Set<String>>> = uiPreferences.data
        .map { prefs -> parseCapabilityDenials(prefs[extensionCapabilityKey]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    private fun parseCapabilityDenials(json: String?): Map<String, Set<String>> {
        if (json.isNullOrBlank()) return emptyMap()
        return runCatching {
            val obj = JSONObject(json)
            buildMap {
                obj.keys().forEach { ext ->
                    val arr = obj.optJSONArray(ext) ?: return@forEach
                    put(ext, buildSet { for (i in 0 until arr.length()) add(arr.optString(i)) })
                }
            }
        }.getOrDefault(emptyMap())
    }

    fun setExtensionCapability(extensionId: String, capability: String, granted: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val obj = runCatching { JSONObject(prefs[extensionCapabilityKey] ?: "{}") }.getOrDefault(JSONObject())
                val denied = buildSet {
                    obj.optJSONArray(extensionId)?.let { arr -> for (i in 0 until arr.length()) add(arr.optString(i)) }
                }.toMutableSet()
                if (granted) denied.remove(capability) else denied.add(capability)
                if (denied.isEmpty()) obj.remove(extensionId)
                else obj.put(extensionId, org.json.JSONArray().apply { denied.forEach { put(it) } })
                prefs[extensionCapabilityKey] = obj.toString()
            }
        }
    }

    private fun capabilityGranted(ext: InstalledExtension, capability: String): Boolean =
        capability in ext.apiCapabilities &&
            capability !in (extensionCapabilityDenials.value[ext.id] ?: emptySet())

    // Per-extension "keep running in background": whether an extension's chat/app WebView survives
    // its panel closing. ENABLED-by-default; stored as the set of ids the user has DISABLED (same
    // org.json-array-in-one-key pattern as the other per-extension settings).
    private val extensionKeepAliveKey = stringPreferencesKey("extension_keepalive_disabled")

    val extensionKeepAliveDisabled: StateFlow<Set<String>> = uiPreferences.data
        .map { prefs -> parseIdSet(prefs[extensionKeepAliveKey]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    private fun parseIdSet(json: String?): Set<String> {
        if (json.isNullOrBlank()) return emptySet()
        return runCatching {
            val arr = org.json.JSONArray(json)
            buildSet { for (i in 0 until arr.length()) add(arr.optString(i)) }
        }.getOrDefault(emptySet())
    }

    fun setExtensionKeepAlive(extensionId: String, enabled: Boolean) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val disabled = parseIdSet(prefs[extensionKeepAliveKey]).toMutableSet()
                if (enabled) disabled.remove(extensionId) else disabled.add(extensionId)
                prefs[extensionKeepAliveKey] =
                    org.json.JSONArray().apply { disabled.forEach { put(it) } }.toString()
            }
        }
    }

    // Generic per-extension settings (the manifest `settings:` block), keyed extensionId -> {key: value}.
    // Stored as one nested JSON object; the config.* API + the settings screen read/write through here.
    private val extensionSettingsKey = stringPreferencesKey("extension_settings")

    val extensionSettings: StateFlow<Map<String, Map<String, String>>> = uiPreferences.data
        .map { prefs -> parseExtensionSettings(prefs[extensionSettingsKey]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    private fun parseExtensionSettings(json: String?): Map<String, Map<String, String>> {
        if (json.isNullOrBlank()) return emptyMap()
        return runCatching {
            val root = JSONObject(json)
            buildMap {
                root.keys().forEach { extId ->
                    val obj = root.optJSONObject(extId) ?: return@forEach
                    put(extId, buildMap { obj.keys().forEach { k -> put(k, obj.optString(k)) } })
                }
            }
        }.getOrDefault(emptyMap())
    }

    /**
     * True when an installed extension says this kind of file opens in its view rather than as text.
     *
     * Only for a file type that *is* the thing the view shows — see [NativeClaim.opensInPreviewSetting]
     * — and only while the setting it names allows it. Applied when a tab is created, so a restored
     * session keeps whichever view it was left in rather than being flipped back.
     */
    private fun opensInExtensionView(file: File): Boolean =
        installedExtensions.value.any { ext ->
            ext.nativeModules.any { module ->
                module.claims.any { claim ->
                    val setting = claim.opensInPreviewSetting ?: return@any false
                    claim.matches(file) && resolvedExtensionSetting(ext, setting) != "false"
                }
            }
        }

    /** A setting's saved value, or its manifest default, or "". Used by config.* (caller-scoped). */
    private fun resolvedExtensionSetting(ext: InstalledExtension, key: String): String {
        extensionSettings.value[ext.id]?.get(key)?.let { return it }
        return ext.settings.firstOrNull { it.key == key }?.default ?: ""
    }

    /**
     * Where the virtual device belongs: the right drawer, an editor tab, or nowhere at all.
     *
     * The pack that provides the device declares the choice as one of its own settings, because it
     * is a fact about *that* extension and belongs on its settings screen — JCode only reads it and
     * routes. A flow rather than a lookup: changing it has to move the device while somebody is
     * looking at it, not at the next launch.
     */
    val virtualDeviceSurface: StateFlow<VirtualDeviceSurface> =
        combine(installedExtensions, extensionSettings) { installed, saved ->
            val pack = installed.firstOrNull { it.nativeGuestModule() != null }
                ?: return@combine VirtualDeviceSurface.None
            val value = saved[pack.id]?.get(DEVICE_SURFACE_KEY)
                ?: pack.settings.firstOrNull { it.key == DEVICE_SURFACE_KEY }?.default
            if (value == DEVICE_SURFACE_DRAWER) VirtualDeviceSurface.Drawer else VirtualDeviceSurface.Tab
        }.stateIn(viewModelScope, SharingStarted.Eagerly, VirtualDeviceSurface.None)

    /**
     * When true, an Android run config built for the container starts its APK inside JCode's own
     * process (no install, no adb) once the build finishes — see [VirtualDeviceBridge]. It is
     * also what runs the device's adb daemon, since there is nothing to serve without a device.
     *
     * The pack that provides the device declares it, the same way it declares which surface the
     * device opens on: it is a fact about *that* extension, it should leave with the extension,
     * and JCode only reads it. A switch in JCode's own settings for a device JCode does not
     * contain was a setting that outlived what it configured.
     */
    val runInVirtualDevice: StateFlow<Boolean> =
        combine(installedExtensions, extensionSettings) { installed, saved ->
            val pack = installed.firstOrNull { it.nativeGuestModule() != null }
                ?: return@combine false
            val value = saved[pack.id]?.get(RUN_IN_DEVICE_KEY)
                ?: pack.settings.firstOrNull { it.key == RUN_IN_DEVICE_KEY }?.default
            value == "true" || value == "1"
        }.stateIn(viewModelScope, SharingStarted.Eagerly, SettingsDefaults.RUN_IN_VIRTUAL_DEVICE)



    // A second init block, deliberately: it collects [runInVirtualDevice], which is declared above
    // but well below the main init block — referencing it from there reads an uninitialised field
    // and crashes the ViewModel's construction.
    init {
        // JCode's own adbd runs only while the setting is on: it is an authenticated listener on
        // loopback, and there is no reason to hold a port open for a feature that is switched off.
        viewModelScope.launch {
            runInVirtualDevice.collect { enabled ->
                if (enabled) startVirtualDeviceAdb() else stopVirtualDeviceAdb()
            }
        }
    }

    /** Same resolution, looked up by id — for the settings screen, which has no [InstalledExtension]. */
    fun extensionSettingValue(extensionId: String, key: String): String {
        extensionSettings.value[extensionId]?.get(key)?.let { return it }
        return installedExtensions.value.firstOrNull { it.id == extensionId }
            ?.settings?.firstOrNull { it.key == key }?.default ?: ""
    }

    /**
     * Suggestions for an autocomplete setting, from the command the manifest declares for it.
     *
     * `{{extensionDir}}` becomes the extension's own directory and `{{someKey}}` the current value of
     * any of its other settings, so a manifest can point at a script it ships and hand that script
     * whatever the rest of the form says — the tool that was picked, typically. What a tool's models
     * are called is the extension's business; JCode only runs the command and splits the lines.
     *
     * Everything about this is best-effort. The command runs in the guest, the tool it asks may not
     * be installed, and it is answering a text field that accepts anything typed into it — so a
     * failure is an empty list, not an error worth interrupting the settings screen for.
     */
    suspend fun extensionSettingSuggestions(extensionId: String, key: String): List<String> {
        val ext = installedExtensions.value.firstOrNull { it.id == extensionId } ?: return emptyList()
        val raw = ext.settings.firstOrNull { it.key == key }?.suggestCommand?.takeIf { it.isNotBlank() }
            ?: return emptyList()
        val command = SUGGEST_PLACEHOLDER.replace(raw) { m ->
            when (val name = m.groupValues[1]) {
                "extensionDir" -> ext.dir.absolutePath
                else -> resolvedExtensionSetting(ext, name)
            }
        }
        val result = runCatching {
            distroService.exec(command, timeoutMs = SUGGEST_TIMEOUT_MS, user = "root", raw = true)
        }.getOrNull() ?: return emptyList()
        if (result.exitCode != 0) return emptyList()
        return result.stdout.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .take(SUGGEST_LIMIT)
            .toList()
    }

    fun setExtensionSetting(extensionId: String, key: String, value: String) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val root = runCatching { JSONObject(prefs[extensionSettingsKey] ?: "{}") }.getOrDefault(JSONObject())
                val obj = root.optJSONObject(extensionId) ?: JSONObject()
                obj.put(key, value)
                root.put(extensionId, obj)
                prefs[extensionSettingsKey] = root.toString()
            }
            // Notify the live extension WebView so it can reload without a manual refresh.
            _extensionEvents.tryEmit(
                "config" to JSONObject().put("extensionId", extensionId).put("key", key).put("value", value).toString(),
            )
        }
    }

    // Per-project "hidden files (by-injected)" — the SCM extension pushes each project's .gitignore
    // patterns here (workbench.setHiddenInjected); the Explorer merges them per the hide mode. Kept
    // separate from extension_settings and the user's by-line list so injected entries stay separable.
    private val hiddenInjectedKey = stringPreferencesKey("explorer_hidden_injected")

    val hiddenInjected: StateFlow<Map<String, List<String>>> = uiPreferences.data
        .map { prefs -> parseHiddenInjected(prefs[hiddenInjectedKey]) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    private fun parseHiddenInjected(json: String?): Map<String, List<String>> {
        if (json.isNullOrBlank()) return emptyMap()
        return runCatching {
            val root = JSONObject(json)
            buildMap {
                root.keys().forEach { pid ->
                    val arr = root.optJSONArray(pid) ?: return@forEach
                    put(pid, (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() })
                }
            }
        }.getOrDefault(emptyMap())
    }

    fun setHiddenInjected(projectId: String, patterns: List<String>) {
        viewModelScope.launch {
            uiPreferences.edit { prefs ->
                val root = runCatching { JSONObject(prefs[hiddenInjectedKey] ?: "{}") }.getOrDefault(JSONObject())
                root.put(projectId, org.json.JSONArray(patterns))
                prefs[hiddenInjectedKey] = root.toString()
            }
        }
    }

    /** The `activeFile` event/query payload: guest (/workspace) path of the focused file tab, or {}. */
    private fun activeFileEventJson(): String {
        val tab = _editorGroup.value.tabs.firstOrNull { it.id == _editorGroup.value.activeTabId && !it.isPage }
        return JSONObject().apply {
            if (tab != null) {
                put("path", hostToGuestPath(tab.filePath))
                put("name", tab.filePath.name)
                put("dirty", tab.isDirty)
            }
        }.toString()
    }

    /**
     * Host file → the guest path the runtime actually mounts it at. A file inside a workspace project
     * resolves through that project's bind (host dir → distroBindTarget), so nested multi-project
     * workspaces map correctly (e.g. /…/multii/beta/x → /workspace/beta/x, which is where exec.run
     * mounts it — not hostToGuestPath's whole-root guess). Files outside any project fall back to the
     * whole projects-root → /workspace mapping (what the interactive terminal binds), else the raw path.
     */
    private fun hostToGuestPath(file: File): String {
        val p = file.absolutePath
        currentWorkspace.value?.projects.orEmpty().forEach { proj ->
            val projHost = (proj.fsPath as? FsPath.Local)?.file?.absolutePath?.trimEnd('/') ?: return@forEach
            if (p == projHost || p.startsWith("$projHost/")) {
                return proj.distroBindTarget.trimEnd('/') + p.removePrefix(projHost)
            }
        }
        // Whole projects-root -> /workspace (prefix-boundary safe: won't rewrite a sibling like
        // "<root>X"); returns p unchanged if it isn't under the projects root.
        return dev.blamspot.jcode.core.distro.WorkspaceHostPaths.hostToGuest(p)
    }

    /** [hostToGuestPath]'s inverse plus the matched project: a guest path in the PER-PROJECT bind view
     *  (what exec.run mounts, so what extensions report) → the project it lives in and its host path.
     *  resolveHostFile is wrong here — it inverts the terminal's whole-root view, which diverges from
     *  the bind view for nested workspaces and sanitized bind names. */
    private fun guestToHostInProject(guestPath: String): Pair<Project, File>? {
        val g = guestPath.trimEnd('/')
        currentWorkspace.value?.projects.orEmpty().forEach { proj ->
            val bind = proj.distroBindTarget.trimEnd('/')
            val projHost = (proj.fsPath as? FsPath.Local)?.file ?: return@forEach
            if (g == bind || g.startsWith("$bind/")) {
                return proj to File(projHost.absolutePath.trimEnd('/') + g.removePrefix(bind))
            }
        }
        return null
    }

    /** Per-file VCS decorations pushed by extensions (`workbench.setExplorerDecorations`), keyed
     *  projectId → repo guest root → decoration set. In-memory only: git status is recomputed by the
     *  extension on every project open, so persisting would only ever show stale letters. */
    private val _explorerScmDecorations = MutableStateFlow<Map<String, Map<String, ScmRepoDecorations>>>(emptyMap())

    /** Flattened per-project view for the explorer: host absolute path → status / submodule set. */
    val explorerScmDecorations: StateFlow<Map<String, ScmProjectDecorations>> =
        _explorerScmDecorations.map { byProject ->
            byProject.mapValues { (_, repos) ->
                ScmProjectDecorations(
                    status = repos.values.flatMap { it.status.entries }.associate { it.key to it.value },
                    submodules = repos.values.flatMap { it.submodules }.toSet(),
                )
            }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    data class ScmRepoDecorations(val status: Map<String, String>, val submodules: Set<String>)
    data class ScmProjectDecorations(val status: Map<String, String>, val submodules: Set<String>)

    /** Drop all pushed decorations — called when the providing extension's host is torn down
     *  (uninstall/update/project switch), so the explorer never shows frozen stale badges. */
    fun clearExplorerScmDecorations() {
        _explorerScmDecorations.value = emptyMap()
    }

    /** Entry point for JCodeNative.request. Logs the request/response to the Extension Dev tools when
     *  the caller is a dev (unsigned sideloaded) extension, then delegates to [extensionApiRequestImpl]. */
    suspend fun extensionApiRequest(ext: InstalledExtension, envelopeJson: String): String {
        val isDevExt = dev.blamspot.jcode.workbench.ExtensionDevLog.isDev(ext.id)
        if (isDevExt) dev.blamspot.jcode.workbench.ExtensionDevLog.log(
            dev.blamspot.jcode.workbench.ExtensionDevLogEntry.Kind.Request, ext.id, "→ $envelopeJson",
        )
        val result = extensionApiRequestImpl(ext, envelopeJson)
        if (isDevExt) {
            val ok = runCatching { JSONObject(result).optBoolean("ok", true) }.getOrDefault(true)
            dev.blamspot.jcode.workbench.ExtensionDevLog.log(
                if (ok) dev.blamspot.jcode.workbench.ExtensionDevLogEntry.Kind.Response
                else dev.blamspot.jcode.workbench.ExtensionDevLogEntry.Kind.Error,
                ext.id, "← $result",
            )
        }
        return result
    }

    private suspend fun extensionApiRequestImpl(ext: InstalledExtension, envelopeJson: String): String {
        val req = runCatching { JSONObject(envelopeJson) }.getOrNull()
            ?: return apiError("malformed request envelope")
        val type = req.optString("type")
        val payload = req.optJSONObject("payload") ?: JSONObject()
        if (ext.apiMinVersion > EXTENSION_API_VERSION) {
            return apiError("extension requires API v${ext.apiMinVersion}; this JCode has v$EXTENSION_API_VERSION")
        }
        val family = type.substringBefore('.')
        // "service.*" (long-lived runtime servers) is an exec-level privilege — gate it on "exec".
        val requiredCapability = if (family == "service") "exec" else family
        if (family != "api" && !capabilityGranted(ext, requiredCapability)) {
            return apiError("capability '$requiredCapability' is not declared by ${ext.id} or was revoked by the user")
        }
        // An extension opening one of ITS OWN views in the editor — needs the caller id, which the
        // stateless dispatch below doesn't have.
        if (type == "workbench.openView") {
            openExtensionViewPage(
                ext.id,
                payload.optString("view"),
                payload.optString("title").ifBlank { null },
                coexist = payload.optBoolean("newTab", false),
            )
            return apiOk(JSONObject())
        }
        // The last editor context-menu tap targeting this extension, if any — consumed on read. Pages
        // opened BY the tap pull it on boot; already-open pages get the pushed `contextAction` event.
        if (type == "workbench.pendingContextAction") {
            val pending = pendingContextActions.remove(ext.id)
            return apiOk(JSONObject().apply { if (pending != null) put("action", JSONObject(pending)) })
        }
        // Explorer decorations are writable only by extensions that declare the contribution — the
        // generic `workbench` capability must not let any extension forge another's VCS badges.
        if (type == "workbench.setExplorerDecorations" && !ext.contributes.explorerDecorations) {
            return apiError("extension does not contribute explorerDecorations")
        }
        // Per-extension settings (config.*) are scoped to the caller — resolved from its declared
        // `settings:` defaults overlaid with the user's saved values. Also handled here for ext.id.
        if (family == "config") {
            return when (type) {
                "config.all" -> apiOk(
                    JSONObject().apply {
                        ext.settings.forEach { s -> put(s.key, resolvedExtensionSetting(ext, s.key)) }
                    },
                )
                "config.get" -> apiOk(JSONObject().put("value", resolvedExtensionSetting(ext, payload.optString("key"))))
                "config.set" -> {
                    val key = payload.optString("key")
                    if (key.isBlank()) apiError("key required")
                    else {
                        setExtensionSetting(ext.id, key, payload.opt("value")?.toString().orEmpty())
                        apiOk(JSONObject())
                    }
                }
                else -> apiError("unknown request type: $type")
            }
        }
        return runCatching { dispatchExtensionApi(type, payload, ext.id) }
            .getOrElse { apiError(it.message ?: "internal error") }
    }

    private suspend fun dispatchExtensionApi(type: String, p: JSONObject, callerExtId: String): String = when (type) {
        "api.hello" -> apiOk(
            JSONObject()
                .put("apiVersion", EXTENSION_API_VERSION)
                .put("jcodeVersion", BuildConfig.VERSION_NAME),
        )

        "exec.run" -> {
            val command = p.optString("command")
            require(command.isNotBlank()) { "command required" }
            val timeout = p.optLong("timeoutMs", 60_000L)
            val workdir = p.optString("workdir").ifBlank { null }
            val user = p.optString("user").ifBlank { "root" }
            val env = p.optJSONObject("env")
                ?.let { o -> buildMap { o.keys().forEach { put(it, o.optString(it)) } } }
                .orEmpty()
            val r = if (workdir != null) {
                distroService.exec(command, workdir = workdir, env = env, timeoutMs = timeout, user = user, raw = true)
            } else {
                distroService.exec(command, env = env, timeoutMs = timeout, user = user, raw = true)
            }
            apiOk(
                JSONObject().apply {
                    put("stdout", r.stdout)
                    put("stderr", r.stderr)
                    put("exitCode", r.exitCode ?: -1)
                    r.internalError?.let { put("error", it) }
                },
            )
        }

        "fs.read" -> {
            val f = resolveHostFile(p.optString("path"))
            require(f != null && f.isFile) { "not a readable file: ${p.optString("path")}" }
            require(f.length() <= 2_000_000) { "file too large for fs.read (>2MB); use exec.run" }
            apiOk(JSONObject().put("content", f.readText()))
        }

        "fs.write" -> {
            val f = resolveHostFile(p.optString("path"))
            require(f != null) { "unresolvable path: ${p.optString("path")}" }
            f.parentFile?.mkdirs()
            f.writeText(p.optString("content"))
            apiOk(JSONObject())
        }

        "fs.list" -> {
            val f = resolveHostFile(p.optString("path"))
            require(f != null && f.isDirectory) { "not a directory: ${p.optString("path")}" }
            val entries = org.json.JSONArray()
            f.listFiles()?.sortedBy { it.name.lowercase() }?.forEach { c ->
                entries.put(
                    JSONObject()
                        .put("name", c.name)
                        .put("dir", c.isDirectory)
                        .put("size", if (c.isFile) c.length() else 0),
                )
            }
            apiOk(JSONObject().put("entries", entries))
        }

        "workbench.openFile" -> {
            val f = resolveHostFile(p.optString("path"))
            require(f != null && f.isFile) { "not an openable file: ${p.optString("path")}" }
            _bringEditorToFront.tryEmit(Unit)
            openLocalFile(f, p.optInt("line", 0).takeIf { it > 0 }, p.optInt("column", 0).takeIf { it > 0 })
            apiOk(JSONObject())
        }

        "workbench.notify" -> {
            emitMessage(p.optString("message").take(300))
            apiOk(JSONObject())
        }

        // The workbench's bin, offered to extensions so a destructive action of theirs can be as
        // recoverable as one of the Explorer's — Source Control's "Discard" is the case it exists
        // for. The setting is honoured here rather than by the caller: whether a delete is kept is
        // the user's decision about JCode, not a decision each extension gets to make for itself.
        "workbench.trash" -> {
            val paths = p.optJSONArray("paths")
            val enabled = trashEnabled.value
            var moved = 0
            if (enabled && paths != null) {
                for (i in 0 until paths.length()) {
                    val file = resolveHostFile(paths.optString(i))?.takeIf { it.exists() } ?: continue
                    val (name, root) = owningProject(file)
                    runCatching {
                        trash.put(appContext, FsPath.Local(file), name, root, TrashSource.SourceControl)
                    }.onSuccess { moved++ }
                }
            }
            apiOk(JSONObject().put("moved", moved).put("enabled", enabled))
        }

        "workbench.openUrl" -> {
            val url = p.optString("url")
            require(url.startsWith("http://") || url.startsWith("https://")) { "http(s) URLs only" }
            // Honor the user's global web-preview browser choice (was hardcoded to SYSTEM).
            val choice = webPreviewBrowser.value
            if (choice == dev.blamspot.jcode.design.WebPreviewBrowsers.BUILTIN) {
                dev.blamspot.jcode.workbench.BuiltinBrowser.requestOpen(url)
            } else {
                ProjectRunner.openInBrowser(appContext, url, choice)
            }
            apiOk(JSONObject())
        }

        // Register a top-level folder (already created on disk under the guest /workspace mount) as a
        // Project and open it. `destinationId` chooses the target workspace: "default"/absent = the
        // Default Workspace (opens immediately), a workspace id = that User Workspace (switches to it
        // and prompts open-vs-add). Absent id registers under whatever workspace is currently open.
        "workbench.openFolder" -> {
            val name = p.optString("name").trim().trimEnd('/')
            require(name.isNotBlank()) { "name required" }
            // One path segment. The folder is the caller's to have created, but the name reaches
            // the workspace root as a file name, so it may not walk out of it.
            require(name == File(name).name && name.trim('.').isNotEmpty()) {
                "name must be a single folder name"
            }
            val defId = workspaceManager.ensureDefaultWorkspaceId()
            val destId = p.optString("destinationId").trim()
            val currentId = workspaceManager.currentWorkspace.value?.id ?: defId
            val targetWs = when {
                destId.isBlank() -> currentId
                destId == "default" -> defId
                else -> destId.toLongOrNull()?.takeIf { workspaceManager.workspaceExists(it) } ?: defId
            }
            // Opening clears the current editor tabs; flush unsaved buffers first and refuse rather
            // than silently discarding work a dialog never guarded.
            require(saveAllDirtyAwait()) { "unsaved changes could not be saved — save or close open files first" }
            // Make the target the current context (rebuilds the breadcrumb: Default root + target) so
            // resetDefaultWorkspaceProject's single-slot check and project selection resolve correctly.
            workspaceManager.restoreWorkspace(targetWs)
            if (targetWs == defId) {
                resetDefaultWorkspaceProject()
                val project = workspaceManager.createNodeIn(defId, name, WorkspaceNodeType.Project, null)
                _selectedProjectId.value = project.id
                apiOk(JSONObject().put("name", project.name).put("opened", true))
            } else {
                val project = workspaceManager.createNodeIn(targetWs, name, WorkspaceNodeType.Project, null)
                _postClonePrompt.value = project
                apiOk(JSONObject().put("name", project.name).put("opened", false))
            }
        }

        // Adopt a folder an extension materialized under the guest /sources staging mount (e.g. the
        // SCM extension's clones) into the workbench. `type` "project" moves it into the current
        // workspace and opens it; "workspace" moves it into the projects root, stamps it as a User
        // Workspace, and enters it (top-level folders become projects). The folder physically leaves
        // /sources, so the staging dir only ever holds not-yet-classified material.
        //
        // Omitting `type` means "you decide": a folder carrying its own `.jcode` type (a repo that
        // ships one) is adopted as what it declares, and one that declares nothing is left staged and
        // reported as `needsType` — the host has no dialog for this, so the extension that staged the
        // folder asks and calls back with an explicit type. Discarding is likewise the extension's
        // business: it just deletes the staged folder in the runtime.
        "workbench.addFolder" -> {
            val guest = p.optString("path").trim().trimEnd('/')
            val prefix = dev.blamspot.jcode.core.distro.WorkspaceHostPaths.SOURCES_GUEST + "/"
            require(guest.startsWith(prefix)) { "path must be under ${dev.blamspot.jcode.core.distro.WorkspaceHostPaths.SOURCES_GUEST}" }
            val name = guest.removePrefix(prefix)
            require(name.isNotBlank() && !name.contains('/') && !name.startsWith(".")) {
                "path must name a top-level sources folder"
            }
            val staged = File(sourcesRoot(), name)
            require(staged.isDirectory) { "no staged folder named '$name'" }
            val stagedPath = FsPath.Local(staged)
            val requested = p.optString("type").trim()
            val nodeType = when {
                requested.equals("workspace", ignoreCase = true) -> WorkspaceNodeType.Workspace
                requested.equals("project", ignoreCase = true) -> WorkspaceNodeType.Project
                workspaceManager.folderNeedsType(stagedPath) -> null
                workspaceManager.isWorkspaceFolder(stagedPath) -> WorkspaceNodeType.Workspace
                else -> WorkspaceNodeType.Project
            }
            when (nodeType) {
                null -> apiOk(JSONObject().put("needsType", true))
                else -> {
                    // Adoption clears the current editor tabs; flush unsaved buffers first and refuse
                    // rather than silently discarding work a dialog never guarded.
                    require(saveAllDirtyAwait()) { "unsaved changes could not be saved — save or close open files first" }
                    val node = adoptStagedFolder(staged, nodeType)
                    apiOk(JSONObject().put("name", node.name).put("workspace", nodeType == WorkspaceNodeType.Workspace))
                }
            }
        }

        // Close the editor tab hosting the caller's own `#view` page (from workbench.openView), so an
        // extension can dismiss its UI once the flow it drives is finished.
        "workbench.closeView" -> {
            val tabId = EXT_APP_PREFIX + callerExtId + "#" + p.optString("view").trim()
            val existed = _editorGroup.value.tabs.any { it.id == tabId }
            closeTabsNow(setOf(tabId), activate = null)
            apiOk(JSONObject().put("closed", existed))
        }

        "service.start" -> {
            val id = p.optString("id").ifBlank { "service" }
            val command = p.optString("command")
            require(command.isNotBlank()) { "command required" }
            val started = startRuntimeService(
                extId = callerExtId,
                id = id,
                command = command,
                user = p.optString("user").ifBlank { "root" },
                extraPath = p.optString("extraPath"),
            )
            apiOk(JSONObject().put("running", started).put("id", id))
        }

        "service.stop" -> {
            stopRuntimeService(callerExtId, p.optString("id").ifBlank { "service" })
            apiOk(JSONObject())
        }

        "service.status" -> {
            val id = p.optString("id").ifBlank { "service" }
            apiOk(JSONObject().put("running", runtimeServices[svcKey(callerExtId, id)]?.isAlive == true).put("id", id))
        }

        "workbench.activeFile" -> apiOk(JSONObject(activeFileEventJson()))

        // The SCM extension injects a project's .gitignore patterns as the Explorer's "by-injected"
        // hide list. `path` is the project/repo guest path; matched to a project by its bind target.
        "workbench.setHiddenInjected" -> {
            val guestPath = p.optString("path").trim().trimEnd('/')
            val arr = p.optJSONArray("patterns")
            val patterns = if (arr != null) (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() } else emptyList()
            val proj = currentWorkspace.value?.projects.orEmpty().firstOrNull { pr ->
                val g = pr.distroBindTarget.trimEnd('/')
                guestPath == g || guestPath.startsWith("$g/") || g.startsWith("$guestPath/")
            }
            if (proj != null) setHiddenInjected(proj.id.toString(), patterns)
            apiOk(JSONObject().put("matched", proj != null))
        }

        "workbench.projectInfo" -> apiOk(
            JSONObject().apply {
                selectedProject.value?.let { proj ->
                    put("name", proj.name)
                    // distroBindTarget is the guest path the project is actually mounted at for exec.run
                    // (hostToGuestPath assumes the terminal's whole-root bind, which exec does not use).
                    if (proj.fsPath is FsPath.Local) put("path", proj.distroBindTarget)
                }
                currentWorkspace.value?.let { put("workspace", it.name) }
            },
        )

        // Per-file VCS decorations for the Explorer (status letters + submodule dirs). `path` is a repo
        // guest root; entry paths are relative to it. One push replaces that repo's whole slice under
        // its project, so a repo going clean clears its letters.
        "workbench.setExplorerDecorations" -> {
            val repoGuest = p.optString("path").trim().trimEnd('/')
            val resolved = if (repoGuest.isNotEmpty() && !repoGuest.split('/').contains("..")) {
                guestToHostInProject(repoGuest)
            } else {
                null
            }
            if (resolved != null) {
                val (proj, repoHost) = resolved
                val repoRoot = repoHost.absolutePath.trimEnd('/')
                fun hostOf(rel: String): String? = rel.trim().trim('/').takeIf { it.isNotEmpty() && !it.split('/').contains("..") }
                    ?.let { "$repoRoot/$it" }
                val status = buildMap {
                    val arr = p.optJSONArray("decorations") ?: org.json.JSONArray()
                    for (i in 0 until minOf(arr.length(), MAX_EXPLORER_DECORATIONS)) {
                        val d = arr.optJSONObject(i) ?: continue
                        val code = d.optString("status").trim().takeIf { it.isNotEmpty() } ?: continue
                        hostOf(d.optString("path"))?.let { put(it, code.take(2)) }
                    }
                }
                val submodules = buildSet {
                    val arr = p.optJSONArray("submodules") ?: org.json.JSONArray()
                    for (i in 0 until minOf(arr.length(), MAX_EXPLORER_DECORATIONS)) {
                        hostOf(arr.optString(i))?.let(::add)
                    }
                }
                _explorerScmDecorations.update { byProject ->
                    val pid = proj.id.toString()
                    val repos = byProject[pid].orEmpty() + (repoGuest to ScmRepoDecorations(status, submodules))
                    byProject + (pid to repos)
                }
            }
            apiOk(JSONObject().put("matched", resolved != null))
        }

        // Every project folder in the open workspace, as guest mount paths — lets a multi-repo extension
        // (e.g. Source Control) enumerate and switch between repositories. Each project's guest path is its
        // distroBindTarget (where the runtime mounts it); SAF projects have no local dir and are skipped.
        "workbench.workspaceFolders" -> apiOk(
            JSONObject().apply {
                val folders = org.json.JSONArray()
                currentWorkspace.value?.projects.orEmpty().forEach { proj ->
                    if (proj.fsPath is FsPath.Local) {
                        folders.put(
                            JSONObject()
                                .put("name", proj.name)
                                .put("path", proj.distroBindTarget),
                        )
                    }
                }
                put("folders", folders)
                currentWorkspace.value?.let { put("workspace", it.name) }
            },
        )

        else -> throw IllegalArgumentException("unknown request type: $type")
    }

    private fun apiOk(data: JSONObject): String =
        JSONObject().put("ok", true).put("data", data).toString()

    private fun apiError(message: String): String =
        JSONObject().put("ok", false).put("error", message).toString()

    // Long-lived runtime services (e.g. the opencode agent server behind the OpenChamber Chat UI).
    // A one-shot exec.run can't host a server: proot --kill-on-exit reaps the tree the moment the
    // launcher exec returns. spawnStdioProcess gives a piped proot Process the JVM holds open, so the
    // server survives until we destroy() it (which reaps its tree). Keyed by "<extId> <serviceId>"
    // (extension ids never contain spaces) so services can be listed + reaped per owning extension
    // for the Task Manager "Background extensions" section.
    private val runtimeServices = ConcurrentHashMap<String, Process>()

    private fun svcKey(extId: String, id: String) = "$extId $id"

    /** Start (or confirm running) a long-lived server inside the runtime. Idempotent per (ext, id). */
    fun startRuntimeService(extId: String, id: String, command: String, user: String = "root", extraPath: String = ""): Boolean {
        val key = svcKey(extId, id)
        runtimeServices[key]?.let { if (it.isAlive) return true else runtimeServices.remove(key) }
        val process = distroService.spawnStdioProcess(
            command = command,
            userOverride = user,
            extraPath = extraPath,
            owner = extId,
        ) ?: return false
        runtimeServices[key] = process
        // Drain stdout/stderr so the OS pipe buffers never fill and block the server. Kept as daemon
        // threads (mirrors DebugController's stderr drainer); output is discarded (server has its own log).
        Thread { runCatching { process.inputStream.bufferedReader().forEachLine { } } }
            .apply { isDaemon = true }.start()
        Thread { runCatching { process.errorStream.bufferedReader().forEachLine { } } }
            .apply { isDaemon = true }.start()
        return true
    }

    /**
     * Spawn a long-lived process in the Linux runtime with its stdio attached, for callers that need
     * to talk to it rather than just start it — the `.vsix` extension host speaks JSON over stdin
     * and stdout. Unlike [startRuntimeService] the caller owns the process and must destroy it.
     */
    fun spawnRuntimeProcess(extId: String, command: String): Process? =
        distroService.spawnStdioProcess(
            command = command,
            userOverride = "root",
            owner = extId,
        )

    fun stopRuntimeService(extId: String, id: String) {
        runtimeServices.remove(svcKey(extId, id))?.let { GuestProcessTree.destroy(it) }
    }

    /** Destroy every runtime service started by [extId], and anything it forked. */
    private fun reapExtensionServices(extId: String) {
        val prefix = "$extId "
        runtimeServices.keys.filter { it.startsWith(prefix) }.forEach { key ->
            runtimeServices.remove(key)?.let { GuestProcessTree.destroy(it) }
        }
    }

    /** Reap every runtime service (called on project/workspace close and ViewModel teardown). */
    fun stopAllRuntimeServices() {
        javaQuickRun.stop()
        runtimeServices.values.forEach { GuestProcessTree.destroy(it) }
        runtimeServices.clear()
    }

    /**
     * Fully restart the app: save the session, stop the Linux runtime (proot/terminals/services), then
     * relaunch a fresh process. Used for changes that only apply at startup (e.g. hardware acceleration),
     * which a mere Activity recreate can't pick up. The fresh task is started while this (foreground)
     * process is still alive — so it isn't blocked by background-activity-launch rules — and the launch
     * request survives the immediate [Runtime.exit], which the system carries out in a new process.
     */
    fun restartApp() {
        if(distroService.kitInstallationActive || distroService.nativeEnvironmentManager.state.value.installing) {
            viewModelScope.launch { emitMessage(nativePackages.uiText("message.Finishorsafelycancelpackageinstallationbeforerestarting")) }
            return
        }
        if (distroService.nativeEnvironmentManager.state.value.installing) {
            distroService.nativeEnvironmentManager.cancel()
            viewModelScope.launch { emitMessage(nativePackages.uiText("message.Restartpostponedwaitforaptdpkgtoreach")) }
            return
        }
        runCatching { flushSessionNow() }
        runCatching { stopAllRuntimeServices() }
        runCatching { dev.blamspot.jcode.workbench.ScmWebViewHolder.destroyAll() }
        val ctx = getApplication<Application>()
        ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)?.component?.let { component ->
            ctx.startActivity(android.content.Intent.makeRestartActivityTask(component))
        }
        Runtime.getRuntime().exit(0)
    }

    // --- Background extensions (Task Manager "Background extensions" section) -----------------------
    // A "background extension" is one running a persistent WebView host (the SCM sidebar or OpenChamber
    // Chat) and/or a service.start server. Stop reaps its services and tears down its host; the SCM
    // host re-attaches whenever a project is open, so it is additionally SUSPENDED to stay down until
    // the user starts it again (the Chat host restarts on its own when the tab is reopened).

    data class BackgroundExtensionInfo(
        val id: String,
        val name: String,
        val hasHost: Boolean,
        val serviceCount: Int,
        val suspended: Boolean,
        /** A virtual device this extension is running: a `:guest` process, and what is in it. */
        val hasDevice: Boolean = false,
        /** The device's adb daemon, which is the extension's too. */
        val hasAdb: Boolean = false,
        /** Guest processes the extension owns — its host, and whatever that started. */
        val processCount: Int = 0,
    )

    private val _suspendedBackgroundExtensions = MutableStateFlow<Set<String>>(emptySet())

    /** SCM hosts the user stopped; the shell gates SCM host re-attach on this so it stays down. */
    val suspendedBackgroundExtensions: StateFlow<Set<String>> = _suspendedBackgroundExtensions.asStateFlow()

    /** True while the device's own pack is stopped: the drawer takes its panel down and the tab with it. */
    val virtualDeviceStopped: StateFlow<Boolean> =
        combine(installedExtensions, _suspendedBackgroundExtensions) { installed, suspended ->
            installed.firstOrNull { it.nativeGuestModule() != null }?.id in suspended
        }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    /** Undo that -- for the Start button, and for anything asking for the device again. */
    fun resumeVirtualDevice() {
        val pack = installedExtensions.value.firstOrNull { it.nativeGuestModule() != null } ?: return
        _suspendedBackgroundExtensions.update { it - pack.id }
    }

    /** Snapshot of every extension doing background work, for the Task Manager (polled, not reactive). */
    fun backgroundExtensionSnapshot(deviceRunning: Boolean = false): List<BackgroundExtensionInfo> {
        val scmIds = dev.blamspot.jcode.workbench.ScmWebViewHolder.ids().toSet()
        val vsixIds = dev.blamspot.jcode.workbench.VsixViewHolder.ids().toSet()
        val serviceCounts = runtimeServices.keys.groupingBy { it.substringBefore(' ') }.eachCount()
        // Everything running in the runtime on some extension's behalf, however deeply it forked.
        val processCounts = GuestProcessTree.ownerCounts()
        val suspended = _suspendedBackgroundExtensions.value
        val names = installedExtensions.value.associate { it.id to it.name }
        // The pack that provides the virtual device does background work of a kind this list did
        // not know about: it has no WebView host and starts no `service.start` server, so it never
        // appeared here at all -- while a running device is a whole `:guest` process, an adb
        // daemon, and a proot tree of `adb`, `sh` and `sleep` that the Processes list below shows
        // as six anonymous rows nobody could connect to the pack they belong to.
        val devicePack = installedExtensions.value.firstOrNull { it.nativeGuestModule() != null }
        val hasDevice = devicePack != null && deviceRunning
        val adbRunning = devicePack != null && virtualDeviceAdbRunning
        val deviceId = devicePack?.id?.takeIf { hasDevice || adbRunning }
        return (scmIds + vsixIds + serviceCounts.keys + processCounts.keys + suspended + listOfNotNull(deviceId)).map { id ->
            BackgroundExtensionInfo(
                id = id,
                name = names[id] ?: id,
                hasHost = id in scmIds || id in vsixIds,
                serviceCount = serviceCounts[id] ?: 0,
                suspended = id in suspended,
                hasDevice = id == deviceId && hasDevice,
                hasAdb = id == deviceId && adbRunning,
                processCount = processCounts[id] ?: 0,
            )
        }.sortedBy { it.name.lowercase() }
    }

    /** Stop a background extension: reap its runtime services and tear down its host. A live SCM host
     *  is suspended (it would otherwise re-attach on the next project open); a `.vsix` session is
     *  destroyed and restarts when its drawer tab is reopened. Runs on the main thread (WebView.destroy). */
    fun stopBackgroundExtension(id: String) {
        viewModelScope.launch(Dispatchers.Main) {
            reapExtensionServices(id)
            // A pack that provides the device is also running the device: turning it off here has
            // to take the `:guest` process and the adb that serves it, or the row says stopped and
            // the processes below carry on. `shutdown` rather than a kill -- the device has a door.
            if (installedExtensions.value.firstOrNull { it.id == id }?.nativeGuestModule() != null) {
                VirtualDeviceBridge.shutdown(loadIfNeeded = true)
                stopVirtualDeviceAdb()
                // Suspended as well as stopped, or it comes straight back: the drawer's device
                // panel is what *builds* the device, so a panel still on screen rebuilds what was
                // just stopped. Suspension takes the panel away with it; the row keeps a Start.
                _suspendedBackgroundExtensions.update { it + id }
            }
            if (id in liveExtensionHosts || dev.blamspot.jcode.workbench.ScmWebViewHolder.get(id) != null) {
                _suspendedBackgroundExtensions.update { it + id }
                liveExtensionHosts.remove(id)
                clearExplorerScmDecorations()
                // The shell's ScmBackgroundHost tears the WebView down once scmHostExt drops to null.
            }
            if (dev.blamspot.jcode.workbench.VsixViewHolder.get(id) != null) {
                dev.blamspot.jcode.workbench.VsixViewHolder.destroy(id)
            }
            // Last word. Each teardown above ends the tree it holds a launcher for, but a tree whose
            // launcher was lost — a session replaced without being disposed, a process that forked
            // its way out — is only reachable by the tag it carries. Stop means stopped.
            sweepOwnedProcesses(id)
        }
    }

    /**
     * Kill anything still running on [extId]'s behalf, after its hosts and services have been ended.
     *
     * Delayed and off the main thread: a tree torn down properly is already going away, and killing
     * what is mid-exit would only race it. What is still there a few seconds later is a leak.
     */
    private fun sweepOwnedProcesses(extId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            delay(SWEEP_DELAY_MS)
            GuestProcessTree.pidsOwnedBy(extId).forEach {
                runCatching { android.system.Os.kill(it, android.system.OsConstants.SIGKILL) }
            }
        }
    }

    /** Resume a stopped SCM host: lift the suspension so it re-attaches on the next recomposition. */
    fun startBackgroundExtension(id: String) {
        _suspendedBackgroundExtensions.update { it - id }
    }

    override fun onCleared() {
        javaQuickRun.stop()
        nativePackages.detach()
        stopAllRuntimeServices()
        lspController.shutdownAll()
        // shutdown(), where this used to merely close the session: the ViewModel going away means the
        // workbench is, and leaving a `:guest` process behind for a workbench that no longer exists
        // is what BackendService already tears down on the same exit.
        VirtualDeviceBridge.shutdown()
        adbBridge.stop()
        super.onCleared()
    }

    /** Open (or focus) the Extension Settings page (per-extension settings + permissions). */
    fun openExtensionPermissionsPage() {
        _bringEditorToFront.tryEmit(Unit)
        val existing = _editorGroup.value.tabs.firstOrNull { it.pageKind == EditorPageKind.ExtensionPermissions }
        if (existing != null) {
            _editorGroup.value = _editorGroup.value.withActiveTabChanged(existing.id)
            return
        }
        val tab = EditorTab.page(EXT_PERMISSIONS_TAB_ID, "Extension Settings", EditorPageKind.ExtensionPermissions)
        _editorGroup.value = _editorGroup.value.withTabAdded(tab)
    }

    /** Open the detail page for a single SDK entry. Reuses one SDK-detail tab (replaces any other). */
    fun openSdkDetailPage(entryId: String) {
        openDetailPage(SDK_DETAIL_PREFIX + entryId, EditorPageKind.SdkDetail) {
            distroService.sdkCatalogState.value.entries.firstOrNull { it.id == entryId }?.name ?: entryId
        }
        val entry = distroService.sdkCatalogState.value.entries.firstOrNull { it.id == entryId }
        if (entry?.versionsScript?.isNotBlank() == true) {
            viewModelScope.launch(Dispatchers.IO) { distroService.fetchCatalogVersions(entryId) }
        }
    }

    /** Open the detail page for a single language server. Reuses one LSP-detail tab (replaces any other). */
    fun openLspDetailPage(entryId: String) {
        openDetailPage(LSP_DETAIL_PREFIX + entryId, EditorPageKind.LspDetail) {
            distroService.lspCatalogState.value.entries.firstOrNull { it.id == entryId }?.name ?: entryId
        }
    }

    /** Open/focus a per-type detail tab: focus if already open, else replace any other tab of [kind]. */
    private fun openDetailPage(tabId: String, kind: EditorPageKind, title: () -> String) {
        _bringEditorToFront.tryEmit(Unit)
        var group = _editorGroup.value
        val existing = group.tabs.firstOrNull { it.id == tabId }
        if (existing != null) {
            _editorGroup.value = group.withActiveTabChanged(existing.id)
            return
        }
        group.tabs.filter { it.pageKind == kind }.forEach { group = group.withTabRemoved(it.id) }
        _editorGroup.value = group.withTabAdded(EditorTab.page(tabId, title(), kind))
    }

    /**
     * Open (or focus) the single built-in browser editor tab. The URL is carried by
     * [dev.blamspot.jcode.workbench.BuiltinBrowser] (set via its `requestOpen`), so callers that already
     * requested a navigation only need to surface the tab.
     */
    fun openBrowserTab() {
        val group = _editorGroup.value
        val existing = group.tabs.firstOrNull { it.id == BROWSER_TAB_ID }
        _editorGroup.value = if (existing != null) {
            group.withActiveTabChanged(existing.id)
        } else {
            group.withTabAdded(EditorTab.page(BROWSER_TAB_ID, "Browser", EditorPageKind.Browser))
        }
    }

    /** Open (or focus) the Android device page — the adb pairing wizard for this phone. */
    fun openAndroidDevicePage() {
        openDetailPage(ANDROID_DEVICE_TAB_ID, EditorPageKind.AndroidDevice) { "Android Device" }
    }

    /** Open (or focus) the device sandbox tab. The APK, and the name the tab wears for it, are the
     *  Android Dev Pack's — it asks for this through [VirtualDeviceBridge], like the browser's URL. */
    fun openAppSandboxTab() {
        val title = VirtualDeviceBridge.deviceTabTitle?.takeIf { it.isNotBlank() } ?: "Device sandbox"
        openDetailPage(APP_SANDBOX_TAB_ID, EditorPageKind.AppSandbox) { title }
        // A second request can name a different APK — `adb shell am start` does — and the tab is
        // reused, so the name it is wearing has to move with it.
        _editorGroup.value.tabs.firstOrNull { it.id == APP_SANDBOX_TAB_ID && it.title != title }
            ?.let { _editorGroup.value = _editorGroup.value.withTabUpdated(it.copy(title = title)) }
    }

    /**
     * Open (or focus) the virtual device's hardware bench.
     *
     * A tab beside the device rather than a panel over it: the tools are watched *while* an app runs
     * on the device, and anything drawn over the device's screen would be in `screencap` where it
     * would read as something the guest put there.
     */
    fun openVirtualHardwareTab() {
        openDetailPage(VIRTUAL_HARDWARE_TAB_ID, EditorPageKind.VirtualHardware) { "Device hardware" }
    }

    /** Turn the device off once its editor tab is gone — process and all, not merely unbound. Page
     *  tabs get no close callback, so the shell calls this whenever the tab list changes. */
    fun pruneAppSandbox() {
        // Only while the tab is where the device lives. With `deviceSurface: drawer` there is never
        // an AppSandbox tab, so the absence of one is not a statement about the device — and read as
        // one it said "off" on *every* editor change. Measured: opening the drawer's Device panel
        // ended the `:guest` process a moment later, and the panel then sat on "Starting the app…"
        // for a device nothing was starting.
        if (virtualDeviceSurface.value == VirtualDeviceSurface.Drawer) return
        if (_editorGroup.value.tabs.none { it.pageKind == EditorPageKind.AppSandbox }) VirtualDeviceBridge.shutdown()
    }

    /**
     * Run `adb pair <target> <code>` in the Linux runtime for the pairing wizard. Returns null once the
     * command exits 0, otherwise the failure text.
     *
     * It runs as the DEFAULT runtime user and NEVER as root: adb keeps its identity in
     * `$HOME/.android/adbkey`, so a root run would start a second adb server holding a second, unpaired
     * key — the pairing would apply to a server the bridge never talks to, and the two servers would
     * then fight over port 5037. The code is passed straight to the one-shot script and never stored.
     */
    suspend fun pairAdbDevice(target: String, code: String): String? {
        val digits = code.filter(Char::isDigit)
        if (digits.isEmpty()) return "Enter the 6-digit pairing code shown on this device."
        if (!ADB_TARGET_RE.matches(target)) return "\"$target\" is not a valid host:port."
        val result = setupTerminalRunner.run(
            label = "adb pair $target",
            script = "adb pair '$target' '$digits'",
            workdir = null,
            asUser = distroService.environmentState.value.runtime.user,
            timeoutMs = ADB_PAIR_TIMEOUT_MS,
        ) ?: return "Could not start the Setup terminal — is the Linux environment installed?"
        if (result.exitCode == 0) return null
        return result.internalError
            ?: "adb pair failed (exit ${result.exitCode ?: -1}) — check the code and port, then retry. " +
            "The pairing dialog must still be open."
    }

    /** Full status re-check (installed + update-available) for the SDK catalog; runs async, no-op if already running. */
    fun checkSdkStatuses() {
        viewModelScope.launch(Dispatchers.IO) { distroService.checkSdkStatuses() }
    }

    /** Full status re-check (installed + update-available) for the LSP catalog; runs async, no-op if already running. */
    fun checkLspStatuses() {
        viewModelScope.launch(Dispatchers.IO) { distroService.checkLspStatuses() }
    }

    fun checkDebugEngineStatuses() {
        viewModelScope.launch(Dispatchers.IO) { distroService.checkDebugEngineStatuses() }
    }

    /**
     * Re-install (upgrade) every SDK / language server / debug engine the last check flagged as
     * updatable, then re-check so the "Update available" markers clear. Deps are already present, so
     * this re-runs each tool's install command directly through the shared Setup terminal.
     */
    /** Open the detail page for a single debug engine. Reuses one debug-detail tab (replaces any other). */
    fun openDebugEngineDetailPage(entryId: String) {
        openDetailPage(DEBUG_ENGINE_DETAIL_PREFIX + entryId, EditorPageKind.DebugEngineDetail) {
            distroService.debugCatalogState.value.entries.firstOrNull { it.id == entryId }?.name ?: entryId
        }
    }

    /** Open the detail page for a single extension. Reuses one extension-detail tab (replaces any other). */
    fun openExtensionDetailPage(extensionId: String) {
        // Only one detail tab exists at a time, so this snapshot belongs to the tab about to open.
        _detailExtensionSnapshot.value = _installedExtensions.value.firstOrNull { it.id == extensionId }
        openDetailPage(EXT_DETAIL_PREFIX + extensionId, EditorPageKind.ExtensionDetail) {
            _installedExtensions.value.firstOrNull { it.id == extensionId }?.name
                ?: marketplaceEntries.value.firstOrNull { it.id == extensionId }?.name
                ?: extensionId
        }
    }

    // The extension the open detail tab is about, as it was while installed. An extension with no
    // marketplace or source entry behind it — an imported `.vsix` — has nothing left to render from
    // once it is uninstalled, and the page would blank out under the user who just pressed Uninstall.
    // Holding the last-known record keeps the page showing what it was, with its actions off, until
    // the tab is closed.
    private val _detailExtensionSnapshot = MutableStateFlow<InstalledExtension?>(null)

    /** The extension the open detail tab is about, or null when no such tab is open. */
    private fun openExtensionDetailId(): String? =
        _editorGroup.value.tabs
            .firstOrNull { it.pageKind == EditorPageKind.ExtensionDetail }
            ?.id?.removePrefix(EXT_DETAIL_PREFIX)

    /** The open detail tab's extension once it is no longer installed; null while it still is. */
    val uninstalledDetailExtension: StateFlow<InstalledExtension?> =
        combine(_detailExtensionSnapshot, _installedExtensions) { snapshot, installed ->
            snapshot?.takeIf { gone -> installed.none { it.id == gone.id } }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _runConfigVersion = MutableStateFlow(0)
    /** Bumped when a run config is saved so the Run panel re-reads `.jcode/run.yaml`. */
    val runConfigVersion: StateFlow<Int> = _runConfigVersion.asStateFlow()

    /** Open the structured Build & Run configuration page for [project]. Reuses one config tab. */
    /** Open the run-config editor for [index] (null = a new config). */
    fun openRunConfigPage(project: Project, index: Int?) {
        val suffix = index?.toString() ?: "new"
        openDetailPage(RUN_CONFIG_PREFIX + project.id + "#" + suffix, EditorPageKind.RunConfig) {
            if (index == null) "New run — ${project.name}" else "Run: ${project.name}"
        }
    }

    /** Open the build-task editor for [index] (null = a new task). */
    fun openBuildConfigPage(project: Project, index: Int?) {
        val suffix = index?.toString() ?: "new"
        openDetailPage(BUILD_CONFIG_PREFIX + project.id + "#" + suffix, EditorPageKind.BuildConfig) {
            if (index == null) "New build — ${project.name}" else "Build: ${project.name}"
        }
    }

    /** Close every open config-editor tab whose id starts with [prefix] (positional indices shift on
     *  insert/delete, so a stale tab must not be left bound to a moved config). */
    private fun closeConfigEditorTabs(prefix: String) {
        val ids = _editorGroup.value.tabs.map { it.id }.filter { it.startsWith(prefix) }.toSet()
        if (ids.isNotEmpty()) closeTabsNow(ids, activate = null)
    }

    /** Upsert one run config at [index] (null appends) into the project's `.jcode/run.yaml`. */
    fun saveRunConfig(project: Project, index: Int?, config: dev.blamspot.jcode.core.config.RunConfig) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { dev.blamspot.jcode.run.ProjectRunner.upsertRun(project, index, config) }
                .onSuccess {
                    _runConfigVersion.value++
                    // A "New" tab holds index=null forever, so re-saving would keep appending; close it
                    // after the first save (re-open via Configure to edit the now-saved config in place).
                    if (index == null) withContext(Dispatchers.Main) { closeTabsNow(setOf(RUN_CONFIG_PREFIX + project.id + "#new"), activate = null) }
                    _messages.tryEmit("Saved run config for ${project.name}")
                }
                .onFailure { _messages.tryEmit("Failed to save run config: ${it.message ?: "error"}") }
        }
    }

    /** Append all of [configs] to the project's `.jcode/run.yaml` in one write (a framework file-pick
     *  in the "Add run config" dialog creates every config that file offers at once). */
    fun saveRunConfigs(project: Project, configs: List<dev.blamspot.jcode.core.config.RunConfig>) {
        if (configs.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { dev.blamspot.jcode.run.ProjectRunner.upsertRuns(project, configs) }
                .onSuccess {
                    _runConfigVersion.value++
                    _messages.tryEmit("Saved run config for ${project.name}")
                }
                .onFailure { _messages.tryEmit("Failed to save run config: ${it.message ?: "error"}") }
        }
    }

    /** Upsert one build task at [index] (null appends). */
    fun saveBuildConfig(project: Project, index: Int?, config: dev.blamspot.jcode.core.config.BuildConfig) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { dev.blamspot.jcode.run.ProjectRunner.upsertBuild(project, index, config) }
                .onSuccess {
                    _runConfigVersion.value++
                    if (index == null) withContext(Dispatchers.Main) { closeTabsNow(setOf(BUILD_CONFIG_PREFIX + project.id + "#new"), activate = null) }
                    _messages.tryEmit("Saved build task for ${project.name}")
                }
                .onFailure { _messages.tryEmit("Failed to save build task: ${it.message ?: "error"}") }
        }
    }

    fun deleteRunConfig(project: Project, index: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { dev.blamspot.jcode.run.ProjectRunner.deleteRun(project, index) }.onSuccess {
                _runConfigVersion.value++
                // Every later config shifts down one, so any open run-config editor's index is now stale.
                withContext(Dispatchers.Main) { closeConfigEditorTabs(RUN_CONFIG_PREFIX + project.id + "#") }
                _messages.tryEmit("Deleted run config")
            }
        }
    }

    fun deleteBuildConfig(project: Project, index: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { dev.blamspot.jcode.run.ProjectRunner.deleteBuild(project, index) }.onSuccess {
                _runConfigVersion.value++
                withContext(Dispatchers.Main) { closeConfigEditorTabs(BUILD_CONFIG_PREFIX + project.id + "#") }
                _messages.tryEmit("Deleted build task")
            }
        }
    }

    /** Launch the DAP debugger on [config]'s debug entry (a guest source path). */
    fun startDebugForConfig(project: Project, config: dev.blamspot.jcode.core.config.RunConfig) {
        val host = deriveDebugEntryHost(project, config)
        if (host == null) {
            _messages.tryEmit(
                "Nothing debuggable in '${config.name}'. Open a .py/.js/.ts/.cs file, tap a line's gutter to " +
                    "set a breakpoint, then tap Debug.",
            )
            return
        }
        startDebug(host)
    }

    /** Catalog id of the engine that would debug [hostPath]. Matching the catalog's `extensions` in
     *  the UI cannot resolve `.kt`, which only maps to an engine inside an Android app project. */
    fun debugEngineIdFor(hostPath: String): String? = debugController.debugEngineIdFor(hostPath)

    /**
     * Resolve the source file the Debug action launches under the debugger — VS-style "just debug it",
     * no manual field. Priority: the config's explicit [RunConfig.debugEntry], then a source file named
     * in a run command (`node dbg.js`, `python3 app/main.py`), then the active editor tab. Only files
     * whose language has a built-in DAP engine qualify. Returns a host absolute path, or null.
     */
    private fun deriveDebugEntryHost(project: Project, config: dev.blamspot.jcode.core.config.RunConfig): String? {
        val projHost = (project.fsPath as? FsPath.Local)?.file
        val bind = project.distroBindTarget.trimEnd('/')

        fun hostOf(guestOrRel: String): File? {
            val s = guestOrRel.trim()
            if (s.isBlank()) return null
            return if (s.startsWith("/")) {
                guestToHostInProject(s)?.second ?: projHost?.let { File(it, s.removePrefix(bind).trimStart('/')) }
            } else {
                projHost?.let { File(it, s.removePrefix("./")) }
            }
        }

        // 1. Explicit debug entry (guest path).
        hostOf(config.debugEntry)?.takeIf { it.isFile }?.let { return it.absolutePath }

        // 2. A source file named in any run command.
        val rx = Regex("""(?:\./)?[\w./-]+\.(?:py|pyw|js|jsx|ts|tsx|mjs|cjs|cs|c|cpp|cc|rs|kt|java)""")
        for (t in config.terminals) {
            for (m in rx.findAll(t.command)) {
                hostOf(m.value)?.takeIf { it.isFile && debugController.canDebugFile(it.absolutePath) }
                    ?.let { return it.absolutePath }
            }
        }

        // 3. The active editor file, if its language has a debug engine.
        _editorGroup.value.activeTab?.filePath?.path
            ?.takeIf { it.isNotBlank() && debugController.canDebugFile(it) }
            ?.let { return it }

        return null
    }

    fun selectEditorTab(tabId: String) {
        _editorGroup.value = _editorGroup.value.withActiveTabChanged(tabId)
        requestSyncOpenFilesFromDisk()
    }

    /**
     * A file's current text as a native extension should see it: the **editor's** copy when the file
     * is open, the disk's otherwise.
     *
     * The distinction is the whole point. A designer handed the disk copy of a file with unsaved
     * edits would render something the user is not looking at, and their next visual edit would
     * write that stale text back over what they had typed.
     */
    fun readOpenFileText(path: String): String? {
        val tab = _editorGroup.value.tabs.firstOrNull { it.filePath.path == path && it.editorState != null }
        tab?.editorState?.let { state ->
            val snapshot = state.snapshot.value
            return runCatching { String(snapshot.readRange(0, snapshot.byteLength), Charsets.UTF_8) }.getOrNull()
        }
        return runCatching { File(path).takeIf { it.isFile }?.readText() }.getOrNull()
    }

    /**
     * Replace a file's text through the open editor buffer, so one visual edit is one edit.
     *
     * Deliberately NOT a disk write: going through the buffer is what keeps the source view, the
     * dirty marker, undo and Save all describing the same document. Writing the file directly would
     * leave the open buffer holding the pre-edit text, and the user's next keystroke would save that
     * over the change they just made in the designer.
     *
     * A file that is not open has no buffer to route through and is written directly — there is
     * nothing to get out of step with.
     */
    fun replaceFileText(path: String, text: String) {
        val tab = _editorGroup.value.tabs.firstOrNull { it.filePath.path == path && it.editorState != null }
        val state = tab?.editorState
        if (state == null) {
            viewModelScope.launch(Dispatchers.IO) {
                runCatching { File(path).writeText(text) }
                    .onFailure { emitMessage(nativePackages.uiText("message.writeFailed", mapOf("name" to (File(path).name).toString(), "reason" to (it.message ?: "error").toString()))) }
            }
            return
        }
        // As an edit, not a load. `replaceAll` is the open/revert path: it leaves the buffer clean
        // and clears undo, so routing a designer edit through it left the tab showing no unsaved
        // marker for a change that very much was unsaved — and threw away the editor's history.
        viewModelScope.launch { state.replaceAllAsEdit(text) }
    }

    /** Flip a file tab between the source editor and its rendered preview (Markdown). */
    fun toggleTabPreview(tabId: String) {
        val current = _editorGroup.value.tabs.firstOrNull { it.id == tabId } ?: return
        if (current.editorState == null) return
        _editorGroup.value = _editorGroup.value.withTabUpdated(current.copy(previewMode = !current.previewMode))
    }

    // Closing tabs with unsaved changes routes through a Save/Discard/Close-Saved prompt first; the
    // dialog (shown in JCodeApp) reads this and calls back into [resolveEditorClose].
    private val _pendingEditorClose = MutableStateFlow<PendingEditorClose?>(null)
    val pendingEditorClose: StateFlow<PendingEditorClose?> = _pendingEditorClose.asStateFlow()
    // The (target tab ids, tab to activate afterward) captured while the prompt is up.
    private var pendingEditorCloseTargets: Pair<Set<String>, String?>? = null

    fun closeEditorTab(tabId: String) = requestCloseEditorTabs(setOf(tabId), activate = null)

    /** Toggle a tab's pinned flag and re-sort so pinned tabs lead (stable — relative order kept). */
    fun toggleEditorTabPinned(tabId: String) {
        val group = _editorGroup.value
        val tab = group.tabs.firstOrNull { it.id == tabId } ?: return
        val reordered = group.tabs
            .map { if (it.id == tabId) it.copy(pinned = !tab.pinned) else it }
            .sortedBy { !it.pinned }
        _editorGroup.value = group.copy(tabs = reordered)
    }

    /** Close every tab except [tabId] and any pinned tabs; [tabId] becomes active. */
    fun closeOtherEditorTabs(tabId: String) {
        val targets = _editorGroup.value.tabs.filter { it.id != tabId && !it.pinned }.mapTo(HashSet()) { it.id }
        requestCloseEditorTabs(targets, activate = tabId)
    }

    /** Close every unpinned tab positioned to the right of [tabId]; [tabId] becomes active. */
    fun closeEditorTabsToRight(tabId: String) {
        val tabs = _editorGroup.value.tabs
        val anchor = tabs.indexOfFirst { it.id == tabId }
        if (anchor < 0) return
        val targets = tabs.filterIndexed { index, tab -> index > anchor && !tab.pinned }.mapTo(HashSet()) { it.id }
        requestCloseEditorTabs(targets, activate = tabId)
    }

    /** Close [ids] immediately unless some carry unsaved changes, in which case raise the prompt. */
    private fun requestCloseEditorTabs(ids: Set<String>, activate: String?) {
        val targets = _editorGroup.value.tabs.filter { it.id in ids }
        if (targets.isEmpty()) return
        val dirty = targets.filter { it.isDirty }
        if (dirty.isEmpty()) {
            closeTabsNow(ids, activate)
            return
        }
        pendingEditorCloseTargets = ids to activate
        _pendingEditorClose.value = PendingEditorClose(
            dirtyTitles = dirty.map { it.title },
            savedCount = targets.count { !it.isDirty },
        )
    }

    /** Resolve the unsaved-changes prompt for the pending tab-close set. */
    fun resolveEditorClose(choice: EditorCloseChoice) {
        val (ids, activate) = pendingEditorCloseTargets ?: run { _pendingEditorClose.value = null; return }
        _pendingEditorClose.value = null
        pendingEditorCloseTargets = null
        when (choice) {
            EditorCloseChoice.CANCEL -> Unit // keep everything open
            EditorCloseChoice.DISCARD -> closeTabsNow(ids, activate)
            EditorCloseChoice.CLOSE_SAVED -> {
                val clean = _editorGroup.value.tabs.filter { it.id in ids && !it.isDirty }.mapTo(HashSet()) { it.id }
                closeTabsNow(clean, activate)
            }
            EditorCloseChoice.SAVE -> viewModelScope.launch {
                val dirty = _editorGroup.value.tabs.filter { it.id in ids && it.isDirty && it.editorState != null }
                dirty.forEach { saveTabAwait(it) }
                // Close every target tab now clean; any that couldn't be saved (e.g. no path) stay open.
                val closable = _editorGroup.value.tabs.filter { it.id in ids && !it.isDirty }.mapTo(HashSet()) { it.id }
                closeTabsNow(closable, activate)
            }
        }
    }

    private fun closeTabsNow(ids: Set<String>, activate: String?) {
        if (ids.isEmpty()) return
        val group = _editorGroup.value
        val doomed = group.tabs.filter { it.id in ids }
        if (doomed.isEmpty()) return
        doomed.forEach { tab ->
            if (!tab.isPage) lspController.documentClosed(tab.filePath.path)
            tab.editorState?.close()
            untrackDirty(tab.id)
            diskSignatures.remove(tab.id)
            // Closing the tab is what dismisses an uninstalled extension's page for good.
            if (tab.pageKind == EditorPageKind.ExtensionDetail) _detailExtensionSnapshot.value = null
        }
        val remaining = group.tabs.filterNot { it.id in ids }
        val newActive = when {
            activate != null && remaining.any { it.id == activate } -> activate
            remaining.any { it.id == group.activeTabId } -> group.activeTabId
            else -> remaining.lastOrNull()?.id
        }
        _editorGroup.value = group.copy(tabs = remaining, activeTabId = newActive)
    }

    /** Per-tab collectors that mirror each editor's dirty flag onto its [EditorTab] for the tab dot. */
    private val dirtyJobs = mutableMapOf<String, Job>()

    private fun trackDirty(tab: EditorTab) {
        val state = tab.editorState ?: return
        val tabId = tab.id
        dirtyJobs.remove(tabId)?.cancel()
        dirtyJobs[tabId] = viewModelScope.launch {
            launch {
                state.dirty.collect { dirty ->
                    val current = _editorGroup.value.tabs.firstOrNull { it.id == tabId } ?: return@collect
                    if (current.isDirty != dirty) {
                        _editorGroup.value = _editorGroup.value.withTabUpdated(current.copy(isDirty = dirty))
                    }
                }
            }
            // Content edits that keep the tab dirty don't change the EditorGroup, so persist the unsaved
            // buffer on snapshot changes too (debounced) to capture in-progress typing before a kill.
            // The same signal drives the language server's didChange (debounced inside the controller).
            val hostPath = tab.filePath.path
            launch {
                state.snapshot.collect {
                    scheduleSessionSave()
                    lspController.documentChanged(hostPath)
                }
            }
        }
    }

    init {
        viewModelScope.launch {
            dev.blamspot.jcode.fs.FileMutations.changes.collect { change ->
                change.barrier?.let { it.complete(Unit);return@collect }
                val old=(change.from as? FsPath.Local)?.file?.absolutePath ?: return@collect
                val moved=(change.to as? FsPath.Local)?.file
                if(!change.restored) { javaQuickRun.sourceMoved(old);debugController.sourceMoved(old) }
                if(moved!=null) _breakpoints.update { bps -> bps.mapKeys { (path,_) -> if(path==old || path.startsWith(old+"/")) moved.absolutePath+path.removePrefix(old) else path } }
                val affected=_editorGroup.value.tabs.filter { !it.isPage && (it.filePath.absolutePath==old || it.filePath.absolutePath.startsWith(old+"/")) }
                affected.forEach { tab ->
                    lspController.documentClosed(tab.filePath.path)
                    if(moved==null) {
                        tab.editorState?.readOnly=true
                        emitMessage(nativePackages.uiText("message.bufferRetained", mapOf("name" to (tab.title).toString())))
                    } else {
                        val file=File(moved.absolutePath+tab.filePath.absolutePath.removePrefix(old))
                        val updated=tab.copy(filePath=file,title=file.name)
                        if(change.restored) tab.editorState?.readOnly=false
                        untrackDirty(tab.id)
                        _editorGroup.value=_editorGroup.value.withTabUpdated(updated)
                        diskSignatures.remove(tab.id)
                        trackDirty(updated)
                        lspController.documentOpened(file.path)
                        if(nativeSourceId==tab.id) nativePackages.setSource(file.path)
                    }
                }
                notifyWorkspaceFilesChanged()
            }
        }
    }

    private fun untrackDirty(tabId: String) {
        dirtyJobs.remove(tabId)?.cancel()
    }

    /**
     * A clean tab mirrors the file on disk, so when an external writer (e.g. an agent in the terminal)
     * changes the file we reload it. Detection is by a (lastModified, size) signature rather than
     * FileObserver: proot/terminal writes happen in another mount namespace and don't fire the app's
     * inotify, but [File.lastModified]/[File.length] still reflect the ext4 inode. The signature is
     * captured at open and after every save/discard, so our own writes never trigger a reload.
     */
    private val diskSignatures = ConcurrentHashMap<String, DiskSignature>()
    private val syncMutex = Mutex()
    private var lastReloadNoticeAt = 0L

    private fun File.diskSignatureOrNull(): DiskSignature? =
        if (exists() && isFile) DiskSignature(lastModified(), length()) else null

    /** Foreground re-sync trigger, driven by a RESUMED loop in JCodeApp and on tab switch. */
    fun requestSyncOpenFilesFromDisk() {
        viewModelScope.launch { syncOpenFilesFromDisk() }
    }

    /** Reload every clean, local, still-text tab whose file changed on disk since we last read it. */
    private suspend fun syncOpenFilesFromDisk() {
        if (!syncMutex.tryLock()) return // a sync is already running; the next tick re-sweeps everything
        try {
            val reloaded = mutableListOf<String>()
            val candidates = _editorGroup.value.tabs.filter { tab ->
                tab.editorState != null &&                // page tab
                    !tab.isDirty &&                       // fast skip; replaceAll re-checks atomically
                    tab.filePath.path.isNotBlank()        // SAF / non-file source
            }
            if (candidates.isEmpty()) return
            // Stat every candidate in ONE hop to IO. This tick runs every 1.5s for as long as the app
            // is foregrounded and its steady state is "nothing changed", so a withContext per tab was
            // a dispatch per open tab per tick for no work.
            val signatures = withContext(Dispatchers.IO) {
                candidates.mapNotNull { tab -> tab.filePath.diskSignatureOrNull()?.let { tab.id to it } }.toMap()
            }
            for (tab in candidates) {
                val state = tab.editorState ?: continue
                if (tab.isDirty) continue                 // re-check: a keystroke may have landed during the stat
                val file = tab.filePath
                val signature = signatures[tab.id]
                    ?: continue                           // deleted on disk: keep the open copy
                val known = diskSignatures[tab.id]
                if (known == null) {                      // first sight: establish a baseline
                    diskSignatures[tab.id] = signature
                    continue
                }
                if (known == signature) continue          // unchanged
                val bytes = withContext(Dispatchers.IO) {
                    runCatching { workspaceManager.fsFor(FsPath.Local(file)).read(FsPath.Local(file)) }.getOrNull()
                } ?: continue
                // If the file changed again while we were reading, defer: leave the known signature so the
                // next tick re-detects and loads the stabilized content (stored signature stays == buffer).
                val afterRead = withContext(Dispatchers.IO) { file.diskSignatureOrNull() }
                if (afterRead != signature) continue
                if (!bytes.isLikelyText()) {              // became binary/too large: keep the open copy
                    diskSignatures[tab.id] = signature    // but mark this version seen
                    continue
                }
                // replaceAll atomically re-checks dirty on the editor's single writer, so a keystroke that
                // landed during our read aborts the reload (returns false) instead of being clobbered.
                if (state.replaceAll(bytes.toString(Charsets.UTF_8), onlyIfClean = true)) {
                    diskSignatures[tab.id] = signature
                    reloaded += tab.title
                }
            }
            if (reloaded.isNotEmpty()) {
                val now = System.currentTimeMillis()
                if (now - lastReloadNoticeAt > RELOAD_NOTICE_THROTTLE_MS) {
                    lastReloadNoticeAt = now
                    emitMessage(
                        if (reloaded.size == 1) nativePackages.uiText("message.reloaded", mapOf("name" to (reloaded.first()).toString()))
                        else nativePackages.uiText("message.reloadedMany", mapOf("count" to (reloaded.size).toString()))
                    )
                }
            }
        } finally {
            syncMutex.unlock()
        }
    }

    /** Save the active editor tab's buffer to disk (Ctrl+S / top-bar Save). */
    fun saveActiveTab() {
        _editorGroup.value.activeTab?.let { saveTab(it) }
    }

    /** Save every open tab with unsaved changes (Save button long-press → Save all). */
    fun saveAllTabs() {
        val dirty = _editorGroup.value.tabs.filter { it.isDirty && it.editorState != null }
        if (dirty.isEmpty()) {
            viewModelScope.launch { emitMessage(nativePackages.uiText("message.Nounsavedchanges")) }
            return
        }
        dirty.forEach { saveTab(it) }
    }

    /** Undo the last edit in the active editor (Save button long-press → Undo). */
    fun undoActiveTab() {
        _editorGroup.value.activeTab?.editorState?.undoManager?.undo()
    }

    /** Redo the last undone edit in the active editor (Save button long-press → Redo). */
    fun redoActiveTab() {
        _editorGroup.value.activeTab?.editorState?.undoManager?.redo()
    }

    /** Reload the active tab from disk, throwing away its unsaved edits (Save long-press → Discard). */
    fun discardActiveTab() {
        val tab = _editorGroup.value.activeTab ?: return
        val state = tab.editorState ?: return
        if (!tab.isDirty) return
        if(state.readOnly) return
        val file=tab.filePath
        if (file.path.isBlank()) {
            viewModelScope.launch { emitMessage(nativePackages.uiText("message.cannotDiscard", mapOf("name" to (tab.title).toString()))) }
            return
        }
        viewModelScope.launch {
            val bytes = runCatching {
                withContext(Dispatchers.IO) { workspaceManager.fsFor(FsPath.Local(file)).read(FsPath.Local(file)) }
            }.getOrElse {
                emitMessage(nativePackages.uiText("message.discardFailed", mapOf("name" to (tab.title).toString(), "reason" to (it.message ?: "error").toString())))
                return@launch
            }
            state.replaceAll(bytes.toString(Charsets.UTF_8)) // force: discard intentionally drops edits
            withContext(Dispatchers.IO) { file.diskSignatureOrNull() }?.let { diskSignatures[tab.id] = it }
            emitMessage(nativePackages.uiText("message.discarded", mapOf("name" to (tab.title).toString())))
        }
    }

    /**
     * Format the active tab. A language server formats to the project's own rules (a prettier config,
     * gofmt, rustfmt), so it wins when one is running; the built-in formatter is the fallback.
     */
    fun formatActiveTab() {
        val tab = _editorGroup.value.activeTab ?: return
        val state = tab.editorState ?: run {
            viewModelScope.launch { emitMessage(nativePackages.uiText("message.Nothingtoformat")) }
            return
        }
        val name = tab.filePath.name
        val lang = activeLanguageExtensions.value.firstNotNullOfOrNull { ext -> ext.languageFor(name) }
        viewModelScope.launch {
            if (formatWithLanguageServer(tab)) {
                emitMessage(nativePackages.uiText("message.formatted", mapOf("name" to (tab.title).toString())))
                return@launch
            }
            val snap = state.snapshot.value
            val original = snap.readRangeAsUtf16(0, snap.byteLength)
            val formatted = dev.blamspot.jcode.editor.CodeFormatter.format(original, lang)
            if (formatted == original) {
                emitMessage(nativePackages.uiText("message.Alreadyformatted"))
                return@launch
            }
            state.applyEdit(EditTx.replace(0, snap.byteLength, formatted))
            val newLen = state.snapshot.value.byteLength
            val caret = (state.carets.value.firstOrNull()?.head ?: 0).coerceIn(0, newLen)
            state.setSelection(listOf(Caret(caret, caret)))
            emitMessage(nativePackages.uiText("message.formatted", mapOf("name" to (tab.title).toString())))
        }
    }

    /** Returns false when no ready server offers formatting, or it returns no edits. */
    private suspend fun formatWithLanguageServer(tab: EditorTab): Boolean {
        val state = tab.editorState ?: return false
        val path = tab.filePath.path
        if (path.isBlank() || !lspController.supports(path, LspFeature.Formatting)) return false
        val editor = effectiveConfig.value.editor
        val before=state.snapshot.value
        val edits = lspController.formatting(path, editor.tabSize, editor.insertSpaces)
        if (edits.isEmpty()) return false
        if(state.snapshot.value !== before) { emitMessage(nativePackages.uiText("message.Formattingreplydiscardedbecausethefilechanged"));return false }
        applyEditsToBuffer(state, edits)
        return true
    }

    /**
     * Format [tab] in place, saying nothing. Returns true if the buffer changed.
     *
     * The same server-then-built-in order the explicit command uses, minus the messages: on save
     * the user asked to save, not to be told about formatting, and a toast per write would be
     * noise. Caret position is preserved by offset — good enough for a reformat, and much better
     * than the alternative of dumping the user at the top of the file on every save.
     */
    private suspend fun formatTabQuietly(tab: EditorTab): Boolean {
        val state = tab.editorState ?: return false
        if (formatWithLanguageServer(tab)) return true
        val lang = activeLanguageExtensions.value
            .firstNotNullOfOrNull { ext -> ext.languageFor(tab.filePath.name) }
        val snap = state.snapshot.value
        val original = snap.readRangeAsUtf16(0, snap.byteLength)
        val formatted = dev.blamspot.jcode.editor.CodeFormatter.format(original, lang)
        if (formatted == original) return false
        val caret = state.carets.value.firstOrNull()?.head ?: 0
        state.applyEdit(EditTx.replace(0, snap.byteLength, formatted))
        val newLen = state.snapshot.value.byteLength
        val clamped = caret.coerceIn(0, newLen)
        state.setSelection(listOf(Caret(clamped, clamped)))
        return true
    }

    private fun saveTab(tab: EditorTab) {
        if (tab.editorState == null) return // page tab: nothing to persist
        viewModelScope.launch { if (saveTabAwait(tab)) emitMessage(nativePackages.uiText("message.saved", mapOf("name" to (tab.title).toString()))) }
    }

    /**
     * Write [tab] to disk, suspending until the write finishes; returns true if the tab is now clean.
     * Emits only on failure so callers can report success as a per-file toast or a batch summary.
     */
    private suspend fun saveTabAwait(tab: EditorTab): Boolean {
        val state = tab.editorState ?: return false // page tab: nothing to persist
        if(state.readOnly) { emitMessage(nativePackages.uiText("message.readOnly", mapOf("name" to (tab.title).toString())));return false }
        dev.blamspot.jcode.fs.FileMutations.awaitEditor()
        val file = _editorGroup.value.tabs.firstOrNull { it.id==tab.id }?.filePath ?: return false
        if(state.readOnly) { emitMessage(nativePackages.uiText("message.Restoretheremovedfilebeforesavingopenedits"));return false }
        if (file.path.isBlank()) {
            emitMessage(nativePackages.uiText("message.cannotSave", mapOf("name" to (tab.title).toString())))
            return false
        }
        // `editor.formatOnSave` — a documented .jcode key that until 1.6.2 parsed, merged and
        // serialised without anything ever reading it. Runs before the snapshot below is captured,
        // so what gets written is the formatted text rather than the next save's problem.
        //
        // Failure here must never cost the user their save: a formatter that throws, or a language
        // server that misbehaves, leaves the buffer as it was and the write goes ahead regardless.
        if (effectiveConfig.value.editor.formatOnSave) {
            runCatching { formatTabQuietly(tab) }
        }
        // Snapshots are immutable, so capturing the reference now lets us both write its bytes and
        // detect whether newer edits landed during the write (so we don't clear a stale dirty).
        val snapshot = state.snapshot.value
        return runCatching {
            withContext(Dispatchers.IO) {
                dev.blamspot.jcode.fs.FileMutations.mutex.withLock {
                    dev.blamspot.jcode.fs.FileMutations.awaitEditor()
                    check(!state.readOnly) { "File was removed during save; restore it first" }
                    val destination=_editorGroup.value.tabs.firstOrNull { it.id==tab.id }?.filePath ?: error("Tab closed during save")
                    val bytes = snapshot.readRange(0, snapshot.byteLength)
                    workspaceManager.fsFor(FsPath.Local(destination)).write(FsPath.Local(destination), bytes)
                }
            }
            // A keystroke landing mid-write mints a newer snapshot: the write succeeded but the tab is
            // dirty again, so don't clear dirty and report the tab as still-unsaved (not a false "Saved").
            val clean = state.snapshot.value === snapshot
            if (clean) state.markClean()
            withContext(Dispatchers.IO) { file.diskSignatureOrNull() }?.let { diskSignatures[tab.id] = it }
            queueSyntaxCheck(file)
            lspController.documentSaved(file.path)
            notifyWorkspaceFilesChanged()
            clean
        }.getOrElse {
            emitMessage(nativePackages.uiText("message.saveFailed", mapOf("name" to (tab.title).toString(), "reason" to (it.message ?: "error").toString())))
            false
        }
    }

    /**
     * Save every dirty tab and suspend until all writes finish — the close-guard uses this so a
     * workspace/project switch only proceeds once unsaved buffers are safely on disk. Returns true only
     * if every tab is now clean; false if any couldn't be saved (e.g. a SAF/blank-path tab) so the
     * caller can avoid discarding unsaved work.
     */
    suspend fun saveAllDirtyAwait(): Boolean {
        val dirty = _editorGroup.value.tabs.filter { it.isDirty && it.editorState != null }
        if (dirty.isEmpty()) return true
        var saved = 0
        dirty.forEach { if (saveTabAwait(it)) saved++ }
        if (saved > 0) emitMessage(if (saved == 1) nativePackages.uiText("message.Saved1file") else nativePackages.uiText("message.savedMany", mapOf("count" to (saved).toString())))
        return saved == dirty.size
    }

    private suspend fun openLocalFile(file: File, line: Int? = null, column: Int? = null) {
        val stableId = file.absolutePath
        val existing = _editorGroup.value.tabs.firstOrNull { it.id == stableId }
        if (existing != null) {
            _editorGroup.value = _editorGroup.value.withActiveTabChanged(existing.id)
            existing.editorState?.requestRevealAt(line, column)
            return
        }

        // Probe the file, read it, and build the buffer OFF the main thread — for a large file (or
        // a burst of restored tabs at launch) the read + piece-table build is the jank. The buffer
        // isn't shared until the tab is published below, so building it on IO is safe.
        val prep = withContext(Dispatchers.IO) {
            when {
                !file.exists() || !file.isFile -> OpenPrep.Missing
                // Images open in the built-in viewer. Checked before the text probe so .svg (which
                // is text) renders rather than opening as XML source.
                file.extension.lowercase() in IMAGE_EXTENSIONS -> OpenPrep.Image
                !file.isLikelyTextFile() -> OpenPrep.Binary
                else -> OpenPrep.Text(EditorTab.create(file,stableId).also { tab ->
                    if(file.canonicalPath.startsWith(File(appContext.cacheDir,"language-sources").canonicalPath+"/")) tab.editorState?.readOnly=true
                }, file.diskSignatureOrNull())
            }
        }
        when (prep) {
            OpenPrep.Missing -> emitMessage(nativePackages.uiText("message.fileGone", mapOf("name" to (file.name).toString())))
            OpenPrep.Image -> _editorGroup.value = _editorGroup.value.withTabAdded(
                EditorTab.page(stableId, file.name, EditorPageKind.ImageViewer),
            )
            OpenPrep.Binary -> emitMessage("Binary preview is not implemented yet for ${file.name}.")
            is OpenPrep.Text -> {
                val tab = prep.tab
                applyConfigToTab(tab, effectiveConfig.value)
                // Set the reveal before the tab is shown so the view applies it on attach.
                tab.editorState?.requestRevealAt(line, column)
                trackDirty(tab)
                prep.signature?.let { diskSignatures[stableId] = it }
                _editorGroup.value = _editorGroup.value
                    .withTabAdded(tab.copy(previewMode = opensInExtensionView(file)))
                queueSyntaxCheck(file)
                lspController.documentOpened(file.path)
            }
        }
    }

    /** Convert a 1-based (line, optional column) to the editor's 0-based reveal request. */
    private fun dev.blamspot.jcode.core.editor.EditorState.requestRevealAt(line: Int?, column: Int?) {
        if (line == null) return
        requestReveal((line - 1).coerceAtLeast(0), ((column ?: 1) - 1).coerceAtLeast(0))
    }

    private suspend fun openSafFile(node: FsNode) {
        val stableId = when (val path = node.path) {
            is FsPath.Local -> path.file.absolutePath
            is FsPath.Saf -> path.uri.toString()
        }
        val existing = _editorGroup.value.tabs.firstOrNull { it.id == stableId }
        if (existing != null) {
            _editorGroup.value = _editorGroup.value.withActiveTabChanged(existing.id)
            return
        }

        if (node.name.substringAfterLast('.', "").lowercase() in IMAGE_EXTENSIONS) {
            _editorGroup.value = _editorGroup.value.withTabAdded(
                EditorTab.page(stableId, node.name, EditorPageKind.ImageViewer),
            )
            return
        }

        val bytes = workspaceManager.fsFor(node.path).read(node.path)
        if (!bytes.isLikelyText()) {
            emitMessage("Binary preview is not implemented yet for ${node.name}.")
            return
        }

        val tab = EditorTab.createFromText(
            text = bytes.toString(Charsets.UTF_8),
            title = node.name,
            id = stableId,
        )
        applyConfigToTab(tab, effectiveConfig.value)
        trackDirty(tab)
        _editorGroup.value = _editorGroup.value.withTabAdded(tab)
    }

    // --- Session restore: reopen the last workspace/project + tabs (with unsaved edits) on launch. ---

    private suspend fun restoreSessionOnLaunch() {
        try {
            val enabled = uiPreferences.data.map { it[restoreLastSessionKey] ?: true }.first()
            if (!enabled) return
            val record = withContext(Dispatchers.IO) { sessionStore.load() } ?: return

            // Workspace: only switch if it still exists (a dangling id would blank the workbench).
            val targetWs = record.workspaceId
            if (targetWs != null && targetWs != currentWorkspace.value?.id &&
                workspaceManager.workspaceExists(targetWs)
            ) {
                workspaceManager.restoreWorkspace(targetWs)
            }
            // Wait for the workspace (and its project list) to load so the project selection sticks.
            val workspace = withTimeoutOrNull(4_000) {
                currentWorkspace.first { it != null && (targetWs == null || it.id == targetWs) }
            }

            // Project: only select if it still belongs to the restored workspace.
            val targetProj = record.projectId
            if (targetProj != null && workspace?.projects?.any { it.id == targetProj } == true) {
                _selectedProjectId.value = targetProj
            }

            // Tabs: open each surviving file; recover unsaved buffers where the file (or its folder) remains.
            for (t in record.tabs) {
                val file = File(t.filePath)
                if (t.dirty && t.bufferFileName != null) {
                    val text = withContext(Dispatchers.IO) { sessionStore.readBuffer(t.bufferFileName) }
                    val parentExists = file.parentFile?.isDirectory == true
                    if (text != null && (file.isFile || parentExists)) {
                        openRestoredDirtyTab(file, t.id, text)
                    }
                } else if (file.isFile) {
                    openLocalFile(file)
                }
                if (t.preview) {
                    val restored = _editorGroup.value.tabs.firstOrNull { it.id == t.id }
                    if (restored?.editorState != null && SyntaxHighlighter.isMarkdownFile(restored.filePath.name)) {
                        _editorGroup.value = _editorGroup.value.withTabUpdated(restored.copy(previewMode = true))
                    }
                }
                if (t.pinned) {
                    val restored = _editorGroup.value.tabs.firstOrNull { it.id == t.id }
                    if (restored != null) {
                        _editorGroup.value = _editorGroup.value.withTabUpdated(restored.copy(pinned = true))
                    }
                }
            }

            // Active tab (only if it survived as one of the restored tabs).
            record.activeTabId?.let { id ->
                if (_editorGroup.value.tabs.any { it.id == id }) {
                    _editorGroup.value = _editorGroup.value.withActiveTabChanged(id)
                }
            }
        } finally {
            sessionSaveEnabled = true
        }
    }

    /** Reopen a tab that had unsaved edits: load the file (or an empty buffer if it's gone) then re-apply
     *  the recovered text as an edit so the tab opens dirty and a save rewrites the file. */
    private suspend fun openRestoredDirtyTab(file: File, stableId: String, text: String) {
        if (_editorGroup.value.tabs.any { it.id == stableId }) return
        val tab = EditorTab.create(file, stableId)
        applyConfigToTab(tab, effectiveConfig.value)
        trackDirty(tab)
        file.diskSignatureOrNull()?.let { diskSignatures[stableId] = it }
        // Add to the group first so trackDirty's collector can mirror the dirty flag once we edit below.
        _editorGroup.value = _editorGroup.value.withTabAdded(tab)
        tab.editorState?.let { state ->
            state.applyEdit(EditTx.replace(0, state.snapshot.value.byteLength, text))
        }
        // After the recovered text is applied, so the server opens the unsaved buffer rather than the
        // stale file on disk. Clean restored tabs come through openLocalFile and are already covered.
        lspController.documentOpened(file.path)
    }

    /** Persist the current workbench (open workspace/project + file tabs + unsaved buffers). Debounced. */
    private suspend fun persistSession() {
        if (!sessionSaveEnabled) return
        val group = _editorGroup.value
        val fileTabs = group.tabs.filter {
            !it.isPage && it.editorState != null && it.filePath.path.isNotBlank()
        }
        val wsId = currentWorkspace.value?.id
        val projId = _selectedProjectId.value
        withContext(Dispatchers.IO) {
            val tabRecords = fileTabs.map { tab ->
                val state = tab.editorState!!
                if (tab.isDirty) {
                    val snap = state.snapshot.value
                    val name = sessionStore.writeBuffer(tab.id, snap.readRangeAsUtf16(0, snap.byteLength))
                    SessionTabRecord(
                        tab.id, tab.filePath.absolutePath,
                        dirty = true, bufferFileName = name, preview = tab.previewMode, pinned = tab.pinned,
                    )
                } else {
                    SessionTabRecord(
                        tab.id, tab.filePath.absolutePath,
                        dirty = false, bufferFileName = null, preview = tab.previewMode, pinned = tab.pinned,
                    )
                }
            }
            sessionStore.saveManifest(
                SessionRecord(
                    workspaceId = wsId,
                    projectId = projId,
                    activeTabId = group.activeTabId?.takeIf { id -> fileTabs.any { it.id == id } },
                    tabs = tabRecords,
                )
            )
            sessionStore.pruneBuffers(tabRecords.mapNotNull { it.bufferFileName }.toSet())
        }
    }

    /** Best-effort synchronous-ish flush from the Activity's onStop (covers graceful backgrounding). */
    fun flushSessionNow() {
        viewModelScope.launch { persistSession() }
    }

    private suspend fun emitMessage(message: String) {
        _messages.emit(message)
        // Persist transient toasts in the Output channel too (errors flagged for coloring).
        val isError = message.contains("Failed", ignoreCase = true) ||
            message.contains("Can't", ignoreCase = true) ||
            message.contains("error", ignoreCase = true)
        OutputLog.append(message, if (isError) OutputKind.Error else OutputKind.Info)
    }

    private fun File.isLikelyTextFile(): Boolean {
        val probe = inputStream().use { stream ->
            stream.readNBytes(2_048)
        }
        return probe.isLikelyText()
    }

    private fun ByteArray.isLikelyText(): Boolean {
        if (isEmpty()) return true
        if (any { it == 0.toByte() }) return false

        val suspicious = count { byte ->
            val value = byte.toInt() and 0xFF
            value < 0x09 || (value in 0x0E..0x1F)
        }
        return suspicious <= size / 8
    }

    private suspend fun ensureScopeAvailable(scope: ConfigScope): Boolean {
        if (scope == ConfigScope.Workspace) return true
        val project = selectedProject.value
        val hasLocalProject = project?.fsPath is FsPath.Local
        if (!hasLocalProject) {
            emitMessage(nativePackages.uiText("message.Projectoverridesrequirealocalprojectroot"))
        }
        return hasLocalProject
    }

    private fun applyEffectiveConfigToOpenTabs(config: EffectiveConfig) {
        _editorGroup.value.tabs.forEach { tab ->
            applyConfigToTab(tab, config)
        }
    }

    private fun applyConfigToTab(tab: EditorTab, config: EffectiveConfig) {
        val editorState = tab.editorState ?: return
        editorState.updateRenderConfig { current ->
            current.copy(
                fontSizeSp = config.editor.fontSize,
                tabWidth = config.editor.tabSize,
                ligatures = config.editor.ligatures,
                wordWrap = config.editor.wordWrap,
            )
        }
    }

    private fun runSdkCatalogAction(
        entryId: String,
        action: SdkCatalogAction,
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val session = SessionRegistry.registerSession(
                context = getApplication(),
                kind = BackendSessionKind.JOB,
                name = "sdk:${action.name.lowercase()}:$entryId",
            )
            try {
                distroService.runSdkCatalogAction(entryId, action)
            } finally {
                session.close()
            }
        }
    }

    private fun runLspCatalogAction(
        entryId: String,
        action: LspCatalogAction,
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val session = SessionRegistry.registerSession(
                context = getApplication(),
                kind = BackendSessionKind.JOB,
                name = "lsp:${action.name.lowercase()}:$entryId",
            )
            try {
                distroService.runLspCatalogAction(entryId, action)
            } finally {
                session.close()
            }
        }
    }

    private fun runDebugCatalogAction(
        entryId: String,
        action: DebugEngineAction,
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val session = SessionRegistry.registerSession(
                context = getApplication(),
                kind = BackendSessionKind.JOB,
                name = "debug:${action.name.lowercase()}:$entryId",
            )
            try {
                distroService.runDebugEngineCatalogAction(entryId, action)
            } finally {
                session.close()
            }
        }
    }

    companion object {
        /** Popup ceiling for server completions — a member list on a bare `.` runs to thousands. */
        private const val MAX_LSP_COMPLETIONS = 200

        /** Source-line preview length in the reference picker. */
        private const val PREVIEW_MAX_CHARS = 120

        /** How long to keep asking `adb devices` after a reconnect: the client is spawned, so the
         *  connection lands a moment later — `adb keygen` on a cold runtime is the slow case. */
        private const val VIRTUAL_DEVICE_ATTACH_ATTEMPTS = 12
        private const val VIRTUAL_DEVICE_ATTACH_POLL_MS = 1_000L

        /** Free space to leave on app storage after importing an off-ext4 folder into /sources. */
        private const val IMPORT_FREE_SPACE_HEADROOM_BYTES = 64L * 1024 * 1024

        /** DataStore key + a synchronous mirror of "close app on swipe-away", so [BackendService]
         *  can decide in onTaskRemoved without a blocking DataStore read. */
        const val EXIT_ON_SWIPE_AWAY_KEY = "exit_on_swipe_away"

        @Volatile
        var exitOnSwipeAwayEnabled: Boolean = true

        /** Runtime teardown (destroy proot run/VM/LSP/DAP service procs) invoked on a swipe-away exit;
         *  set by the live ViewModel. Terminals are reaped separately via [TerminalSessionHost]. */
        @Volatile
        var runtimeTeardown: (() -> Unit)? = null

        /** Blocking session persist invoked right before the process is killed on a swipe-away / "Stop &
         *  close" exit, so unsaved editor buffers reach disk before [android.os.Process.killProcess]
         *  races the async [flushSessionNow]. Set by the live ViewModel; no-op if the UI never started. */
        @Volatile
        var sessionFlushBlocking: (() -> Unit)? = null

        private const val RELOAD_NOTICE_THROTTLE_MS = 4_000L
        const val SETTINGS_TAB_ID = "jcode://settings"
        const val TRASH_TAB_ID = "jcode://trash"
        const val ENVIRONMENT_TAB_ID = "jcode://environment"
        const val SDK_DETAIL_PREFIX = "jcode://sdk/"
        const val LSP_DETAIL_PREFIX = "jcode://lsp/"
        const val DEBUG_ENGINE_DETAIL_PREFIX = "jcode://debug-engine/"
        const val EXT_DETAIL_PREFIX = "jcode://ext/"
        const val EXT_APP_PREFIX = "jcode://ext-app/"
        const val VSIX_PANEL_PREFIX = "jcode://vsix-panel/"
        const val EXT_PERMISSIONS_TAB_ID = "jcode://ext-permissions"
        const val EXT_SOURCES_TAB_ID = "jcode://ext-sources"
        /** Prefix of the stand-in id a custom source lists under while its real one is unknown. */
        const val SOURCE_EXTENSION_ID_PREFIX = "source:"
        const val RUN_CONFIG_PREFIX = "jcode://run-config/"
        const val BUILD_CONFIG_PREFIX = "jcode://build-config/"
        /** Stable id of the single built-in browser editor tab (see [openBrowserPage]). */
        const val BROWSER_TAB_ID = "jcode://browser"
        /** Stable id of the single Android device (adb pairing) editor tab. */
        const val ANDROID_DEVICE_TAB_ID = "jcode://android-device"
        /** Stable id of the single device sandbox editor tab — the container owns one `:guest` process. */
        const val APP_SANDBOX_TAB_ID = "jcode://app-sandbox"

        /** The Android Dev Pack setting that says where its device opens — see [virtualDeviceSurface]. */
        private const val DEVICE_SURFACE_KEY = "deviceSurface"

        /** The pack setting behind [runInVirtualDevice]. */
        private const val RUN_IN_DEVICE_KEY = "runInVirtualDevice"

        /** The one value of [DEVICE_SURFACE_KEY] that means the drawer; anything else is a tab. */
        private const val DEVICE_SURFACE_DRAWER = "drawer"
        /** Stable id of the virtual device's hardware bench, which the device shares with its tab. */
        const val VIRTUAL_HARDWARE_TAB_ID = "jcode://virtual-hardware"
        /** `adb pair` is one round trip to adbd; anything past this is a wrong port or a closed dialog. */
        private const val ADB_PAIR_TIMEOUT_MS = 60_000L

        /** How long a stopped extension gets to go away before what is left is treated as leaked. */
        private const val SWEEP_DELAY_MS = 4_000L
        /** host:port, with nothing a shell could read as anything but a literal. */
        private val ADB_TARGET_RE = Regex("""[A-Za-z0-9._\[\]:-]+:\d{1,5}""")
        /** Extensions routed to the built-in image viewer instead of the text editor. */
        val IMAGE_EXTENSIONS = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "ico")
    }
}
