package dev.blamspot.jcode.workbench

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import dev.blamspot.jcode.design.AlertDialog
import dev.blamspot.jcode.design.CompactFilledButton
import dev.blamspot.jcode.design.CompactOutlinedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.blamspot.jcode.design.CompactContextMenu
import dev.blamspot.jcode.design.ContextAction
import dev.blamspot.jcode.design.FileTypeIcon
import dev.blamspot.jcode.design.IconSize
import dev.blamspot.jcode.design.JCodeIcon
import dev.blamspot.jcode.design.JcTooltip
import dev.blamspot.jcode.design.Radius
import dev.blamspot.jcode.design.Space
import dev.blamspot.jcode.design.jcIcon
import dev.blamspot.jcode.fs.Project
import dev.blamspot.jcode.fs.Workspace
import dev.blamspot.jcode.fs.WorkspaceNodeType

/**
 * Workspace-scoped panel pieces (empty state, project roster, welcome card) peeled out of
 * JCodeShell. Stateless / param-driven; the chrome buttons they use live in WorkbenchChrome.kt
 * (same package).
 */

/**
 * The left drawer with no project open: what this workspace is, and where to start.
 *
 * Deliberately without buttons. The drawer's own header sits directly above it carrying the same two
 * commands — `+` is [onCreateProject] and the folder icon is [onOpenExternalFolder], the very
 * callbacks this panel used to duplicate — and behind the drawer the editor shows the project picker
 * with those two plus Clone, Remote Repo and the recent list. Three copies of one pair of actions in
 * a single view; the panel keeps the sentence and points at the pair that was always there.
 */
@Composable
internal fun WorkspaceEmptyState(workspace: Workspace?) {
    val strings = dev.blamspot.jcode.design.LocalUiTranslations.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(Space.xl),
        verticalArrangement = Arrangement.spacedBy(Space.md, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .background(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(Radius.xxxl),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = jcIcon(JCodeIcon.Files),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = strings.text("files.internal"),
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = strings.text("ui.noProjectYetAddOneWithAboveOrOpen"),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
internal fun ProjectRoster(
    projects: List<Project>,
    selectedProjectId: Long,
    onOpenProject: (Project) -> Unit,
    onRenameProject: (Long, String) -> Unit,
    onRemoveProject: (Long) -> Unit,
    onOpenProjectSettings: (Long) -> Unit,
    onExportProject: (Project) -> Unit,
) {
    val strings = dev.blamspot.jcode.design.LocalUiTranslations.current

    val trashProject=LocalProjectTrash.current
    var trashTarget by remember { mutableStateOf<Project?>(null) }
    var renameTarget by remember { mutableStateOf<Project?>(null) }
    var openMenuId by remember { mutableStateOf<Long?>(null) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = Space.ms, vertical = Space.xs),
        verticalArrangement = Arrangement.spacedBy(Space.xs),
    ) {
        Text(
            text = strings.text("ui.pROJECTS"),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Column(verticalArrangement = Arrangement.spacedBy(Space.xs)) {
            projects.forEach { project ->
                val selected = project.id == selectedProjectId
                val isWorkspace = project.nodeType == WorkspaceNodeType.Workspace
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Radius.lg))
                        .clickable { onOpenProject(project) },
                    color = if (selected) {
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.16f)
                    },
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = Space.sm, top = Space.xs, bottom = Space.xs),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(Space.sm),
                    ) {
                        Surface(
                            modifier = Modifier.size(24.dp),
                            shape = RoundedCornerShape(Radius.lg),
                            color = if (selected) {
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            },
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                FileTypeIcon(
                                    name = project.name,
                                    isDirectory = true,
                                    size = IconSize.sm,
                                    // A workspace root and a project inside one are both folders, so
                                    // a pack that names neither still tells them apart by glyph.
                                    fallback = if (isWorkspace) JCodeIcon.Files else JCodeIcon.Code,
                                    tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        Text(
                            text = project.name,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier.weight(1f),
                        )
                        Box {
                            JcTooltip(strings.text("ui.projectActions")) {
                                IconButton(onClick = { openMenuId = project.id }, modifier = Modifier.size(32.dp)) {
                                    Icon(
                                        painter = jcIcon(JCodeIcon.MoreVert),
                                        contentDescription = strings.text("ui.projectActions"),
                                        modifier = Modifier.size(IconSize.md),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                            CompactContextMenu(
                                expanded = openMenuId == project.id,
                                onDismissRequest = { openMenuId = null },
                                quickActions = listOf(
                                    ContextAction(JCodeIcon.Rename, strings.text("ui.rename")) { renameTarget = project },
                                    ContextAction(JCodeIcon.Close, strings.text("ui.removeFromListKeepFiles")) { onRemoveProject(project.id) },
                                    ContextAction(JCodeIcon.Trash, strings.text("ui.deleteProjectFilesToTrash"), destructive=true) { trashTarget=project },
                                ),
                                listActions = listOf(
                                    ContextAction(JCodeIcon.Open, if (isWorkspace) strings.text("ui.openSavedProjectGroup") else strings.text("ui.open")) { onOpenProject(project) },
                                    ContextAction(JCodeIcon.Settings, strings.text("ui.projectSettings")) { onOpenProjectSettings(project.id) },
                                    ContextAction(JCodeIcon.Save, strings.text("ui.exportToStorage")) { onExportProject(project) },
                                ),
                            )
                        }
                    }
                }
            }
        }
    }

    trashTarget?.let { target ->
        AlertDialog(onDismissRequest={trashTarget=null},title={Text(strings.text("ui.deleteProjectFiles"))},text={Text(strings.text("project.deleteDescription", mapOf("name" to (target.name).toString(), "path" to (target.location).toString())))},confirmButton={CompactFilledButton(text=strings.text("ui.moveProjectToTrash"),onClick={trashTarget=null;trashProject(target)})},dismissButton={CompactOutlinedButton(text=strings.text("ui.cancel"),onClick={trashTarget=null})})
    }
    renameTarget?.let { target ->
        var newName by remember(target.id) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(strings.text("ui.rename")) },
            text = {
                TextField(
                    value = newName,
                    onValueChange = { newName = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(strings.text("ui.name")) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                )
            },
            confirmButton = {
                CompactFilledButton(
                    text = strings.text("ui.rename"),
                    onClick = { onRenameProject(target.id, newName); renameTarget = null },
                    enabled = newName.isNotBlank() && newName.trim() != target.name,
                )
            },
            dismissButton = {
                CompactOutlinedButton(text = strings.text("ui.cancel"), onClick = { renameTarget = null })
            },
        )
    }
}
