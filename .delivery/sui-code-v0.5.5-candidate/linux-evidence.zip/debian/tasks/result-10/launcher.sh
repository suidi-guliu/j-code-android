            #!/bin/bash
            set +e
            trap ':' INT
            for attempt in {1..750}; do [ ! -r '/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready' ] && [ ! -r '/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.cancel' ] || break; sleep .02;done
            if [ -r '/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.cancel' ]; then result=143
            elif [ -r '/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready' ]; then
                JCODE_EXT_ID='sui-quickrun:96b0d7f5-3d73-4271-afd1-3a31b735d472/task' /bin/bash --noprofile --norc -c 'printf '\''%s\n'\'' "$$" > '\''/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.pid.tmp'\''
mv -f -- '\''/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.pid.tmp'\'' '\''/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.pid'\''
for attempt in {1..750}; do [ ! -r '\''/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.go'\'' ] && [ ! -r '\''/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.cancel'\'' ] || break; sleep .02; done
[ ! -r '\''/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.cancel'\'' ] || exit 143
[ -r '\''/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.go'\'' ] || exit 70
exec /bin/bash '\''/tmp/sui-native-task-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh'\''' <&0 &
                child=$!
                wait "$child";result=$?
                while kill -0 "$child" 2>/dev/null; do wait "$child";result=$?;[ "$result" -ne 127 ] || break;done
            else result=70; printf '%s\n' 'Task launch acknowledgement missing' >&2
            fi
            rm -f -- '/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready' '/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.cancel' '/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.go' '/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.pid' '/tmp/sui-task-launch-96b0d7f5-3d73-4271-afd1-3a31b735d472.sh.ready.pid.tmp'
            printf '\033]7713;native-96b0d7f5-3d73-4271-afd1-3a31b735d472;%s\007' "$result"
            printf '\n[Task exit %s]\n' "$result"
            exec /bin/bash --noprofile --norc -i