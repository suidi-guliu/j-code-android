            #!/bin/bash
            set +e
            trap ':' INT
            for attempt in {1..750}; do [ ! -r '/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready' ] && [ ! -r '/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.cancel' ] || break; sleep .02;done
            if [ -r '/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.cancel' ]; then result=143
            elif [ -r '/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready' ]; then
                JCODE_EXT_ID='sui-quickrun:7bfc1fbd-8002-4324-9a7f-910c758df63d/task' /bin/bash --noprofile --norc -c 'printf '\''%s\n'\'' "$$" > '\''/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.pid.tmp'\''
mv -f -- '\''/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.pid.tmp'\'' '\''/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.pid'\''
for attempt in {1..750}; do [ ! -r '\''/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.go'\'' ] && [ ! -r '\''/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.cancel'\'' ] || break; sleep .02; done
[ ! -r '\''/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.cancel'\'' ] || exit 143
[ -r '\''/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.go'\'' ] || exit 70
exec /bin/bash '\''/tmp/sui-native-task-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh'\''' <&0 &
                child=$!
                wait "$child";result=$?
                while kill -0 "$child" 2>/dev/null; do wait "$child";result=$?;[ "$result" -ne 127 ] || break;done
            else result=70; printf '%s\n' 'Task launch acknowledgement missing' >&2
            fi
            rm -f -- '/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready' '/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.cancel' '/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.go' '/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.pid' '/tmp/sui-task-launch-7bfc1fbd-8002-4324-9a7f-910c758df63d.sh.ready.pid.tmp'
            printf '\033]7713;native-7bfc1fbd-8002-4324-9a7f-910c758df63d;%s\007' "$result"
            printf '\n[Task exit %s]\n' "$result"
            exec /bin/bash --noprofile --norc -i