            #!/bin/bash
            set +e
            trap ':' INT
            for attempt in {1..750}; do [ ! -r '/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready' ] && [ ! -r '/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.cancel' ] || break; sleep .02;done
            if [ -r '/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.cancel' ]; then result=143
            elif [ -r '/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready' ]; then
                JCODE_EXT_ID='sui-quickrun:e1e43257-b097-4162-86d9-6a29e5945426/task' /bin/bash --noprofile --norc -c 'printf '\''%s\n'\'' "$$" > '\''/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.pid.tmp'\''
mv -f -- '\''/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.pid.tmp'\'' '\''/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.pid'\''
for attempt in {1..750}; do [ ! -r '\''/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.go'\'' ] && [ ! -r '\''/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.cancel'\'' ] || break; sleep .02; done
[ ! -r '\''/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.cancel'\'' ] || exit 143
[ -r '\''/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.go'\'' ] || exit 70
exec /bin/bash '\''/tmp/sui-native-task-e1e43257-b097-4162-86d9-6a29e5945426.sh'\''' <&0 &
                child=$!
                wait "$child";result=$?
                while kill -0 "$child" 2>/dev/null; do wait "$child";result=$?;[ "$result" -ne 127 ] || break;done
            else result=70; printf '%s\n' 'Task launch acknowledgement missing' >&2
            fi
            rm -f -- '/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready' '/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.cancel' '/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.go' '/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.pid' '/tmp/sui-task-launch-e1e43257-b097-4162-86d9-6a29e5945426.sh.ready.pid.tmp'
            printf '\033]7713;native-e1e43257-b097-4162-86d9-6a29e5945426;%s\007' "$result"
            printf '\n[Task exit %s]\n' "$result"
            exec /bin/bash --noprofile --norc -i